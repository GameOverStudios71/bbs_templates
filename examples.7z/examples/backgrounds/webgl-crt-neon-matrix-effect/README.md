# WebGL CRT Neon Matrix Effect

A Pen created on CodePen.

Original URL: [https://codepen.io/unframework/pen/pqorjJ](https://codepen.io/unframework/pen/pqorjJ).

WebGL CRT monitor effect demo with a tiny surprise. Uses offscreen 2D canvas as buffer source.

Libraries and sources:

- ReGL (WebGL helper): http://regl.party/
- glMatrix (math): http://glmatrix.net/
- onecolor (RGB conversion): https://github.com/One-com/one-color
- Google Fonts Inconsolata
- Renminbi by Fengquan Li from the Noun Project
- Skull by Jordan Alfarishy from the Noun Project
- bunny by Smalllike from the Noun Project
- dollar by Oksana Latysheva from the Noun Project
