# cyberpunk retro crt style display

A Pen created on CodePen.

Original URL: [https://codepen.io/somethingformed/pen/raWJXV](https://codepen.io/somethingformed/pen/raWJXV).

Fiddling around with the aesthetic of oldshool CRT displays. Some elements to give a good dirty cyberpunk aesthetic: a simple flickering animation intended to be ambient but not too annoying, scanlines and an unapologetically imprecise pixel font... all in a nice responsive container that should fit pretty much any screen form factor. Could be especially fun as a theme for a text adventure game.

Published in the public domain under the CC0 license http://creativecommons.org/publicdomain/zero/1.0/"