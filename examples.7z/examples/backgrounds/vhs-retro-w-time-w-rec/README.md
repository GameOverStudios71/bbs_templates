# VHS Retro w/Time w/Rec

A Pen created on CodePen.

Original URL: [https://codepen.io/pbitos/pen/zypwVr](https://codepen.io/pbitos/pen/zypwVr).

VHS retro camera with time & counter