# Matrix Rain

A Pen created on CodePen.

Original URL: [https://codepen.io/StarKnightt/pen/WNVrBrG](https://codepen.io/StarKnightt/pen/WNVrBrG).

A matrix rain effect using JavaScript and CSS.

The droplets are randomize words and letters and some CSS color effects.