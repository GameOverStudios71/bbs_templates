# Retro Palm

A Pen created on CodePen.

Original URL: [https://codepen.io/pavlovsk/pen/NwXmKg](https://codepen.io/pavlovsk/pen/NwXmKg).

Remake of:

![Palm GIF](https://78.media.tumblr.com/a58bcef5668713531a7e45282069cda3/tumblr_inline_oqbgwwnC2D1unag2i_540.gif)