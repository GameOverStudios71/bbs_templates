# Neon bubbles

A Pen created on CodePen.

Original URL: [https://codepen.io/giana/pen/LVvaNQ](https://codepen.io/giana/pen/LVvaNQ).

Click to add new bubble. Right click a bubble to pop. Click and hold to attract.

Performance is my bane.