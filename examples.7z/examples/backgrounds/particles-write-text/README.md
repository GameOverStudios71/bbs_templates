# Particles write text

A Pen created on CodePen.

Original URL: [https://codepen.io/plasm/pen/zwjMPy](https://codepen.io/plasm/pen/zwjMPy).

