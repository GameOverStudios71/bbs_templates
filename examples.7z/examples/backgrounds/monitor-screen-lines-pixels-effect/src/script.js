window.addEventListener("DOMContentLoaded", () => {

    const textOutput = document.querySelector('p'),
          phrases = ['checking systems', 'deleting hard drive', 'whoops'],
          delay = [2000, 4000, 6000];

    phrases.forEach((phrase, i) => setTimeout(() => textOutput.textContent = phrase, delay[i]));

});
