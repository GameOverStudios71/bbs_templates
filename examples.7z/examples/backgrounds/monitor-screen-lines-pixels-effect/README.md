# Monitor Screen Lines/Pixels Effect

A Pen created on CodePen.

Original URL: [https://codepen.io/GeorgePark/pen/xaLXLg](https://codepen.io/GeorgePark/pen/xaLXLg).

This pen shows how pure CSS can be used to create a retro monitor screen lines/pixels effect.