// ******************************************************************************
//														DATA DECLARATION

"use strict";
const toolBar = document.querySelector("#toolBarContainer");
const densityValueDiv = document.querySelector("#densityValue");
const velocityValueDiv = document.querySelector("#velocityValue");
const resolutionValueDiv = document.querySelector("#resolutionValue");
const thumbnail = document.querySelector("#thumbnail");

const c = document.querySelector("#myCanvas");
const MINUTE = 1000; //a second in milliseconds
const FPS = 60; // Frames per Second
const autoCloseTime = 7000; //seven seconds in millisecs
const canvasWidth = 600; // canvas dimensions in pixels
const canvasHeight = 800;

var autoCloseActive = Boolean(true);

var ctx = c.getContext("2d");
var c2 = new Object();
var ctx2 = new Object();
var matrix = new Object();
var menuAutoClose = new Number();
var densityDisplay = new Number(3);
var resolutionDisplay = new Number(4);
var velocitydisplay = new Number(3);
var toolBarState = Boolean(false); //closed
var currentChars = new Array();
var matrixScale = new Number(2.5);
var matrixSpeed = new Number(4);
var matrixOpacityBase = new Number(0.0078);
var HUE = new Object();

var imgData = new Object();
var images = new Array();
var numberOfImages = new Number(8);
var currentImageIndex = new Number(1);

var specialChars = "qwertyuioplkjhgfdsazxcvbnm<>?/:;[]{}!@#$%^&*()_-=+";
var numChars = "1234567890";
var mathChars = "¼µ¶±¿ÇÐØĦƔƢȡȹɊҖӁ‰＠ξζω□∮※∏√№↑↓→←↘↙Ψ※㊣々♀♂∞①ㄨ≡╬";
var chineseChars = [
  "人",
  "力",
  "ス",
  "步",
  "っ",
  "及",
  "ち",
  "子",
  "己",
  "ち",
  "ゃ",
  "っ",
  "子"
];
var binary = ["0", "1"];
var block = ["█"];

var charSet = new Array();
charSet[0] = chineseChars;
charSet[1] = specialChars.split("");
charSet[2] = numChars.split("");
charSet[3] = mathChars.split("");
charSet[4] = binary;
charSet[5] = block;

window.addEventListener("resize", resize, false);

function M(scaleFactor, speedValue, opacityValue) {
  //a matrix
  this.imageScaleFactor = scaleFactor;
  this.imageColumns = new Number(120); //width of the image in pixels
  this.imageRows = new Number(160);
  this.height = new Number(canvasHeight); // actual canvas dimensions in pixels
  this.width = new Number(canvasWidth);
  this.opacityDecrementBaseMod = 0.0013;
  this.opacityDecrementBase = opacityValue; //0.0065
  this.opacityDecrement = this.opacityDecrementBase * this.imageScaleFactor;
  this.cols = this.imageColumns / this.imageScaleFactor; // numberof colums and rows
  this.rows = this.imageRows / this.imageScaleFactor;
  this.charHeight = this.height / this.rows;
  this.charWidth = this.width / this.cols;
  this.fontSize = this.charHeight;
  this.colorSaturation = new Number(100);
  this.speed = speedValue; //in seconds
  this.resolutionDisplay = new Number(4);
  this.columns = new Array();
}
M.prototype.stop = function() {
  for (let k = 0; k < this.cols; ++k) this.columns[k].kill();
};

function HUEcycle(start, end) {
  (this.val = start), (this.end = end);

  this.HUEtween = TweenMax.to(this, 3, {
    val: end,
    yoyo: true,
    repeat: -1
  });
}

HUEcycle.prototype.kill = function() {
  this.HUEtween.kill();
};

function setChar(index) {
  currentChars = charSet[index];
  populateChars();
  clearTimeout(menuAutoClose);
  menuAutoClose = setTimeout(menuClose, autoCloseTime);
}
function init() {
  matrix = new M(matrixScale, matrixSpeed, matrixOpacityBase);
  c.width = canvasWidth;
  c.height = canvasHeight;
  resize();
  populate_matrix();
}
window.onload = function() {
  currentChars = charSet[4]; // binary charset to start
  HUE = new HUEcycle(110, 130); //green hue values to start
  init();

  setupImages().then(function(result) {
    requestAnimationFrame(animation);
  });
};

//image loaders
function setupImages() {
  return new Promise(function(resolve, reject) {
    let loaded = 0;
    for (let i = 0; i < numberOfImages; i++) {
      let img = new Image();
      img.crossOrigin = "Anonymous";
      let url =
        "https://s3-us-west-2.amazonaws.com/s.cdpn.io/680570/mrrobotmatrix_0" +
        i +
        ".png";

      img.src = url;
      img.setAttribute("imageIndex", i);

      img.onload = function(e) {
        let image = e.target;
        c2 = document.createElement("canvas");
        ctx2 = c2.getContext("2d");
        c2.width = 120;
        c2.height = 160;
        ctx2.drawImage(image, 0, 0, 120, 160);

        imgData = ctx2.getImageData(0, 0, 120, 160);
        images[image.getAttribute("imageIndex")] = imgData;
        loaded++;
        if (loaded == numberOfImages) {
          resolve("loaded the pix");
        }
      }; //event
    } //for
  }); //promise
}
// Modifier functions
// **********************************************************

function populate_matrix() {
  matrix.columns = new Array();
  for (let cols = 0; cols < matrix.cols; ++cols) {
    matrix.columns.push(new column(cols, 0, Math.random()));
    for (let m = 0; m < matrix.rows; ++m)
      matrix.columns[cols].chars.push(getRandChar());
  } //for
}

function populateChars() {
  for (let cols = 0; cols < matrix.cols; ++cols) {
    matrix.columns[cols].chars = new Array();
    for (let m = 0; m < matrix.rows; ++m)
      matrix.columns[cols].chars.push(getRandChar());
  }
}

function resize() {
  c.style.height = window.innerHeight + "px";
  ctx.font = "lighter " + matrix.fontSize + "px Asap";
}

function resetAutoClose() {
  if (autoCloseActive === true) {
    clearTimeout(menuAutoClose);
    menuAutoClose = setTimeout(menuClose, autoCloseTime);
  }
}
function menuToogle() {
  if (toolBarState === false) {
    //if it is closed
    toolBar.classList.add("open");
    toolBarState = true;
    if (autoCloseActive === true)
      menuAutoClose = setTimeout(menuClose, autoCloseTime);
  } else {
    // if it is open
    toolBar.classList.remove("open");
    toolBarState = false;
    if (autoCloseActive === true) clearTimeout(menuAutoClose);
  }
}

function menuClose() {
  if (toolBarState === true) {
    //if open
    if (autoCloseActive === true) clearTimeout(menuAutoClose);
    toolBar.classList.remove("open");
    toolBarState = false;
  }
}

function increaseResolution() {
  if (matrixScale > 1.5) {
    matrix.stop();
    resolutionDisplay += 1;
    resolutionValueDiv.innerText = resolutionDisplay;
    matrixOpacityBase = matrix.opacityDecrementBase;
    matrixScale += -0.5;
    init();
  }
  resetAutoClose();
}

function decreaseResolution() {
  if (matrixScale < 4) {
    matrix.stop();
    resolutionDisplay += -1;
    resolutionValueDiv.innerText = resolutionDisplay;
    matrixOpacityBase = matrix.opacityDecrementBase;
    matrixScale += 0.5;
    init();
  }
  resetAutoClose();
}

function decreaseVelocity() {
  if (velocitydisplay > 1) {
    matrix.stop();
    velocitydisplay += -1;
    velocityValueDiv.innerText = velocitydisplay;
    matrixOpacityBase = matrix.opacityDecrementBase;
    matrixSpeed += 1.0;
    init();
  }
  resetAutoClose();
}

function increaseVelocity() {
  if (velocitydisplay < 6) {
    matrix.stop();
    velocitydisplay += 1;
    velocityValueDiv.innerText = velocitydisplay;
    matrixOpacityBase = matrix.opacityDecrementBase;
    matrixSpeed += -1.0;
    init();
  }
  resetAutoClose();
}

function increasePic() {
  if (currentImageIndex < numberOfImages - 1) currentImageIndex++;
  else currentImageIndex = 0;
  thumbnail.src =
    "https://s3-us-west-2.amazonaws.com/s.cdpn.io/680570/robotthumb_0" +
    currentImageIndex +
    ".png";
  resetAutoClose();
}
function decreasePic() {
  if (currentImageIndex > 0) currentImageIndex--;
  else currentImageIndex = numberOfImages - 1;
  thumbnail.src =
    "https://s3-us-west-2.amazonaws.com/s.cdpn.io/680570/robotthumb_0" +
    currentImageIndex +
    ".png";
  resetAutoClose();
}
function decreaseDensity() {
  if (densityDisplay > 1) {
    matrix.opacityDecrementBase += matrix.opacityDecrementBaseMod;
    densityDisplay += -1;
    densityValueDiv.innerText = densityDisplay;
    matrix.opacityDecrement =
      matrix.opacityDecrementBase * matrix.imageScaleFactor;
  }
  resetAutoClose();
}

function increaseDensity() {
  if (densityDisplay < 6) {
    matrix.opacityDecrementBase += -matrix.opacityDecrementBaseMod;
    densityDisplay += 1;
    densityValueDiv.innerText = densityDisplay;
    matrix.opacityDecrement =
      matrix.opacityDecrementBase * matrix.imageScaleFactor;
  }
  resetAutoClose();
}

function changeColor(start, end) {
  HUE.kill();
  HUE = new HUEcycle(start, end);
  resetAutoClose();
}

//			PRIMITIVE FUNCTIONS
//********************************************************************
function getLinearIndex(col, row) {
  //converts (x,y) coords into a linear index
  let index = 0;
  let scaleFactor = matrix.imageScaleFactor;
  let rows = Math.floor(row * scaleFactor);
  let cols = Math.floor(col * scaleFactor);

  index = rows * (120 * 4);
  index += cols * 4;
  return index;
}

function getRandChar() {
  let x = Math.floor(Math.random() * currentChars.length);
  return currentChars[x];
}

function writeChar(R, G, B, opacity, col, row, symbol) {
  ctx.fillStyle = "rgba(" + R + "," + G + "," + B + "," + opacity + ")";
  ctx.fillText(symbol, col, row);
}

function writeCharHSL(H, S, L, A, col, row, symbol) {
  ctx.fillStyle = "hsla(" + H + "," + S + "%," + L + "%," + A + ")";
  ctx.fillText(symbol, col, row);
}

function eraseMatrix(opacity) {
  ctx.rect(0, 0, matrix.width, matrix.height);
  ctx.fillStyle = "rgba(0, 0, 0, " + opacity + ")";
  ctx.fill();
}

// *******************************************************************************************
//																CLASSES
// column miniclass
function column(col, row, progresss) {
  this.progress = Math.random();
  this.col = col;
  this.row = row;
  this.dropLen = matrix.rows * (Math.random() * 0.3);

  this.chars = new Array();
  //column position
  this.rowTween = TweenMax.to(this, matrix.speed + Math.random() * 3, {
    row: 800,
    ease: Power1.easeIn,
    yoyo: false,
    repeat: -1
  });
  this.rowTween.progress(this.progress);
}

column.prototype.draw = function() {
  let charUpdate = 0;
  let tempIndex = 0;
  let opacityOffset =
    Math.floor(this.row) / matrix.charHeight * matrix.opacityDecrement;

  for (
    // top part
    let n = 0;
    n < Math.floor(this.row / matrix.charHeight) - this.dropLen + 1;
    ++n
  ) {
    tempIndex = getLinearIndex(this.col, n);
    writeCharHSL(
      HUE.val,
      matrix.colorSaturation,
      images[currentImageIndex].data[tempIndex] / 2.55, // 255/2.55 = 100 pixel to luminosity
      1 - opacityOffset,
      this.col * matrix.charWidth, //in pixels
      matrix.charHeight * n,
      this.chars[n]
    );
    opacityOffset -= matrix.opacityDecrement;
  } //for

  opacityOffset = matrix.rows * matrix.opacityDecrement;
  for (let n = Math.floor(this.row / matrix.charHeight); n < matrix.rows; ++n) {
    //bottom part
    tempIndex = getLinearIndex(this.col, n);
    writeCharHSL(
      HUE.val,
      matrix.colorSaturation,
      images[currentImageIndex].data[tempIndex] / 2.55 - 30, // 255/2.55 = 100 pixel to luminosity
      1 - opacityOffset,
      this.col * matrix.charWidth,
      matrix.charHeight * n,
      this.chars[n]
    );
    opacityOffset -= matrix.opacityDecrement;
  } //for

  let dropLuminosity = 95; //luminosity of the first drop
  let luminosityDec = 75 / this.dropLen;

  for (let q = 0; q < this.dropLen; ++q) {
    // shinny drop
    tempIndex = getLinearIndex(
      this.col,
      Math.floor(this.row / matrix.charHeight) - q
    );
    if (images[currentImageIndex].data[tempIndex] / 2.55 > 20)
      // 255/2.55 = 100 pixel to luminosity
      writeCharHSL(
        HUE.val,
        100,
        dropLuminosity,
        1,
        this.col * matrix.charWidth,
        Math.floor(this.row / matrix.charHeight) * matrix.charHeight -
          q * matrix.charHeight,
        this.chars[Math.floor(this.row / matrix.charHeight) - q]
      );
    dropLuminosity -= luminosityDec;
  } //for

  charUpdate = Math.floor(Math.random() * matrix.rows);
  this.chars[charUpdate] = getRandChar();
  charUpdate = Math.floor(Math.random() * matrix.rows);
  this.chars[charUpdate] = getRandChar();
}; //draw ---------------------------------------------------------------

column.prototype.kill = function() {
  this.rowTween.kill();
};

function animation() {
  setTimeout(function() {
    requestAnimationFrame(animation);
    eraseMatrix(1);
    for (let i = 0; i < matrix.columns.length; i += 1) {
      matrix.columns[Math.floor(i)].draw();
    }
  }, MINUTE / FPS);
}
