# Interactive Mesh BG with Glassmorphism Card

A Pen created on CodePen.

Original URL: [https://codepen.io/frontendcharm/pen/gONjpya](https://codepen.io/frontendcharm/pen/gONjpya).

