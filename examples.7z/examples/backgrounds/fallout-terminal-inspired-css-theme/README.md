# Fallout Terminal Inspired CSS Theme

A Pen created on CodePen.

Original URL: [https://codepen.io/macktropolis/pen/vNMRpK](https://codepen.io/macktropolis/pen/vNMRpK).

A retro theme mimicking the terminal designs in the Fallout video game franchise. It uses CSS animation for a screen flicker effect and a simple scroll (I'm working on a better line by line scroll).