# CPChallenge: Wall of Text - Matrix Text Rain

A Pen created on CodePen.

Original URL: [https://codepen.io/tommyho/pen/YzmmazG](https://codepen.io/tommyho/pen/YzmmazG).

Customizable Matrix Rain