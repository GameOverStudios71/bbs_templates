# Faces SVG retro animation

A Pen created on CodePen.

Original URL: [https://codepen.io/ScavengerFrontend/pen/aJExoe](https://codepen.io/ScavengerFrontend/pen/aJExoe).

Creating SVGs dynamically via CreateElementNS