# Retro Text Effect (Pure CSS)

A Pen created on CodePen.

Original URL: [https://codepen.io/ykadosh/pen/zYNxVKr](https://codepen.io/ykadosh/pen/zYNxVKr).

I've always loved the 80s design trends, and I wanted to try and recreate this trend using some of the newer CSS properties.

I'm using mask-image, text-stroke, and background-clip CSS properties in this pen, so this may not work properly on some older browsers.