

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from './domElements';
import * as state from './state';
import { applyStylesToDroppedControl, applyStylesToAnsiArtViewer } from './styleUpdater';
import { updatePanelForNoSelection, handleControlSelection as selectControlInPanel } from './selectionManager';
import { updatePlaceholderVisibility, generateUniqueId, combineHexAndAlphaToRGBA } from './utils';
import { renderTextColorsComponent } from './textColorsComponent';
import { applyCustomHtmlCode, DEFAULT_HTML_CONTENT, DEFAULT_CSS_CONTENT, DEFAULT_JS_CONTENT } from './htmlControlController';
import { 
    DEFAULT_TEXTCOLORS_TEXT_CONTENT,
    DEFAULT_TEXTCOLORS_COLOR1,
    DEFAULT_TEXTCOLORS_COLOR2,
    DEFAULT_TEXTCOLORS_GRADIENT_MODE,
    DEFAULT_TEXTCOLORS_COLOR1_FILL,
    DEFAULT_TEXTCOLORS_GRADIENT_ANGLE,
    DEFAULT_TEXTCOLORS_COLOR2_START,
    DEFAULT_TEXTCOLORS_FONT_FAMILY,
    DEFAULT_TEXTCOLORS_FONT_SIZE,
    DEFAULT_TEXTCOLORS_FONT_WEIGHT,
    DEFAULT_TEXTCOLORS_FONT_STYLE,
    DEFAULT_TEXTCOLORS_DECORATION_UNDERLINE,
    DEFAULT_TEXTCOLORS_DECORATION_OVERLINE,
    DEFAULT_TEXTCOLORS_DECORATION_LINETHROUGH,
    DEFAULT_TEXTCOLORS_TEXT_TRANSFORM,
    DEFAULT_TEXTCOLORS_LINE_HEIGHT,
    DEFAULT_TEXTCOLORS_LETTER_SPACING,
    DEFAULT_TEXTCOLORS_WORD_SPACING,
    DEFAULT_TEXTCOLORS_TEXT_ALIGN,
    DEFAULT_TEXTCOLORS_FONT_VARIANT
 } from './constants';
import type { ControlPaletteItemType } from './types';


export function deleteSelectedControl() {
    if (!state.selectedDroppedControl) return;

    const parent = state.selectedDroppedControl.parentElement;
    if (parent) {
        parent.removeChild(state.selectedDroppedControl);
    }
    state.setSelectedDroppedControl(null);
    if (state.lastSelectedDroppedControl) {
        state.lastSelectedDroppedControl.classList.remove('selected-dropped-control-highlight');
        state.setLastSelectedDroppedControl(null);
    }
    updatePanelForNoSelection();
    
    if (parent) {
        if (parent.id === 'layer-2') {
            updatePlaceholderVisibility(parent, '.layer2-empty-placeholder');
        } else if (parent.classList.contains('decorative-element')) {
            updatePlaceholderVisibility(parent, '.decorative-element-empty-placeholder');
        } else if (parent.classList.contains('dropped-row-container') || parent.classList.contains('dropped-column-container')) {
           updatePlaceholderVisibility(parent, '.container-empty-placeholder');
        }
    }
}

export function setupDroppedControlPanelListeners() {
    if (!dom.droppedControlVisibleInput || !dom.droppedControlTextContentInput || !dom.droppedControlPlaceholderInput ||
        !dom.droppedControlImageSrcInput || !dom.droppedControlWidthInput || !dom.droppedControlHeightInput ||
        !dom.droppedControlBgColorInput || !dom.droppedControlBgColorAlphaSlider || !dom.droppedControlBgColorAlphaValueDisplay ||
        !dom.droppedControlTextColorInput || !dom.droppedControlTextColorAlphaSlider || !dom.droppedControlTextColorAlphaValueDisplay ||
        !dom.droppedControlOpacityInput || !dom.droppedControlOpacityValueDisplay ||
        !dom.droppedControlBorderRadiusInput || !dom.droppedControlBorderWidthInput || !dom.droppedControlBorderStyleSelect || 
        !dom.droppedControlBorderColorInput || !dom.droppedControlBorderColorAlphaSlider || !dom.droppedControlBorderColorAlphaValueDisplay ||
        !dom.droppedControlBoxShadowXInput || !dom.droppedControlBoxShadowYInput || !dom.droppedControlBoxShadowBlurInput || 
        !dom.droppedControlBoxShadowColorInput || !dom.droppedControlBoxShadowColorAlphaSlider || !dom.droppedControlBoxShadowColorAlphaValueDisplay ||
        !dom.droppedControlFontFamilyInput || !dom.droppedControlFontSizeInput || !dom.droppedControlFontWeightSelect ||
        !dom.droppedControlFontStyleSelect || !dom.droppedControlLineHeightInput || !dom.droppedControlLetterSpacingInput ||
        !dom.droppedControlTextTransformSelect || !dom.droppedControlTextDecorationSelect ||
        !dom.droppedControlTextShadowXInput || !dom.droppedControlTextShadowYInput || !dom.droppedControlTextShadowBlurInput || 
        !dom.droppedControlTextShadowColorInput || !dom.droppedControlTextShadowColorAlphaSlider || !dom.droppedControlTextShadowColorAlphaValueDisplay ||
        !dom.deleteControlBtn || !dom.textAlignHorizontalSelect || !dom.textAlignVerticalSelect || !dom.containerAlignItemsSelect || !dom.containerJustifyContentSelect ) return;

    const updateFn = () => { if (state.selectedDroppedControl) applyStylesToDroppedControl(); };

    dom.droppedControlVisibleInput.addEventListener('change', updateFn);
    dom.droppedControlTextContentInput.addEventListener('input', updateFn);
    dom.droppedControlPlaceholderInput.addEventListener('input', updateFn);
    dom.droppedControlImageSrcInput.addEventListener('change', updateFn);
    dom.droppedControlWidthInput.addEventListener('input', updateFn);
    dom.droppedControlHeightInput.addEventListener('input', updateFn);
    
    dom.droppedControlBgColorInput.addEventListener('input', updateFn);
    dom.droppedControlBgColorAlphaSlider.addEventListener('input', (e) => {
        if(dom.droppedControlBgColorAlphaValueDisplay) dom.droppedControlBgColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
        updateFn();
    });
    
    dom.droppedControlTextColorInput.addEventListener('input', updateFn);
    dom.droppedControlTextColorAlphaSlider.addEventListener('input', (e) => {
        if(dom.droppedControlTextColorAlphaValueDisplay) dom.droppedControlTextColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
        updateFn();
    });
    
    dom.droppedControlOpacityInput.addEventListener('input', (e) => { if (dom.droppedControlOpacityValueDisplay) { dom.droppedControlOpacityValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2); } updateFn(); });
    dom.droppedControlBorderRadiusInput.addEventListener('input', updateFn);
    dom.droppedControlBorderWidthInput.addEventListener('input', updateFn);
    dom.droppedControlBorderStyleSelect.addEventListener('change', updateFn);
    
    dom.droppedControlBorderColorInput.addEventListener('input', updateFn);
    dom.droppedControlBorderColorAlphaSlider.addEventListener('input', (e) => {
        if(dom.droppedControlBorderColorAlphaValueDisplay) dom.droppedControlBorderColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
        updateFn();
    });

    dom.droppedControlBoxShadowXInput.addEventListener('input', updateFn);
    dom.droppedControlBoxShadowYInput.addEventListener('input', updateFn);
    dom.droppedControlBoxShadowBlurInput.addEventListener('input', updateFn);
    dom.droppedControlBoxShadowColorInput.addEventListener('input', updateFn);
    dom.droppedControlBoxShadowColorAlphaSlider.addEventListener('input', (e) => {
        if(dom.droppedControlBoxShadowColorAlphaValueDisplay) dom.droppedControlBoxShadowColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
        updateFn();
    });


    dom.droppedControlFontFamilyInput.addEventListener('input', updateFn);
    dom.droppedControlFontSizeInput.addEventListener('input', updateFn);
    dom.droppedControlFontWeightSelect.addEventListener('change', updateFn);
    dom.droppedControlFontStyleSelect.addEventListener('change', updateFn);
    dom.droppedControlLineHeightInput.addEventListener('input', updateFn);
    dom.droppedControlLetterSpacingInput.addEventListener('input', updateFn);
    dom.droppedControlTextTransformSelect.addEventListener('change', updateFn);
    dom.droppedControlTextDecorationSelect.addEventListener('change', updateFn);

    dom.droppedControlTextShadowXInput.addEventListener('input', updateFn);
    dom.droppedControlTextShadowYInput.addEventListener('input', updateFn);
    dom.droppedControlTextShadowBlurInput.addEventListener('input', updateFn);
    dom.droppedControlTextShadowColorInput.addEventListener('input', updateFn);
    dom.droppedControlTextShadowColorAlphaSlider.addEventListener('input', (e) => {
        if(dom.droppedControlTextShadowColorAlphaValueDisplay) dom.droppedControlTextShadowColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
        updateFn();
    });

    dom.deleteControlBtn.addEventListener('click', deleteSelectedControl);

    dom.textAlignHorizontalSelect.addEventListener('change', updateFn);
    dom.textAlignVerticalSelect.addEventListener('change', updateFn);
    dom.containerAlignItemsSelect.addEventListener('change', updateFn);
    dom.containerJustifyContentSelect.addEventListener('change', updateFn);
}

export function setupAnsiArtPanelListeners() {
    if (!dom.ansiArtVisibleInput || !dom.ansiArtContentInput || !dom.ansiArtWidthInput || !dom.ansiArtHeightInput ||
        !dom.ansiArtBgColorInput || !dom.ansiArtBgColorAlphaSlider || !dom.ansiArtBgColorAlphaValueDisplay ||
        !dom.ansiArtTextColorInput || !dom.ansiArtTextColorAlphaSlider || !dom.ansiArtTextColorAlphaValueDisplay ||
        !dom.ansiArtOpacityInput || !dom.ansiArtOpacityValueDisplay ||
        !dom.ansiArtBorderRadiusInput || !dom.ansiArtBorderWidthInput || !dom.ansiArtBorderStyleSelect || 
        !dom.ansiArtBorderColorInput || !dom.ansiArtBorderColorAlphaSlider || !dom.ansiArtBorderColorAlphaValueDisplay ||
        !dom.ansiArtBoxShadowXInput || !dom.ansiArtBoxShadowYInput || !dom.ansiArtBoxShadowBlurInput || 
        !dom.ansiArtBoxShadowColorInput || !dom.ansiArtBoxShadowColorAlphaSlider || !dom.ansiArtBoxShadowColorAlphaValueDisplay ||
        !dom.deleteAnsiArtBtn) return;

    const updateFn = () => { if (state.selectedDroppedControl) applyStylesToAnsiArtViewer(); };

    dom.ansiArtVisibleInput.addEventListener('change', updateFn);
    dom.ansiArtContentInput.addEventListener('input', updateFn);
    dom.ansiArtWidthInput.addEventListener('input', updateFn);
    dom.ansiArtHeightInput.addEventListener('input', updateFn);

    dom.ansiArtBgColorInput.addEventListener('input', updateFn);
    dom.ansiArtBgColorAlphaSlider.addEventListener('input', (e) => {
        if(dom.ansiArtBgColorAlphaValueDisplay) dom.ansiArtBgColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
        updateFn();
    });

    dom.ansiArtTextColorInput.addEventListener('input', updateFn);
    dom.ansiArtTextColorAlphaSlider.addEventListener('input', (e) => {
        if(dom.ansiArtTextColorAlphaValueDisplay) dom.ansiArtTextColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
        updateFn();
    });
    
    dom.ansiArtOpacityInput.addEventListener('input', (e) => { if (dom.ansiArtOpacityValueDisplay) { dom.ansiArtOpacityValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2); } updateFn(); });
    dom.ansiArtBorderRadiusInput.addEventListener('input', updateFn);
    dom.ansiArtBorderWidthInput.addEventListener('input', updateFn);
    dom.ansiArtBorderStyleSelect.addEventListener('change', updateFn);

    dom.ansiArtBorderColorInput.addEventListener('input', updateFn);
    dom.ansiArtBorderColorAlphaSlider.addEventListener('input', (e) => {
        if(dom.ansiArtBorderColorAlphaValueDisplay) dom.ansiArtBorderColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
        updateFn();
    });
    
    dom.ansiArtBoxShadowXInput.addEventListener('input', updateFn);
    dom.ansiArtBoxShadowYInput.addEventListener('input', updateFn);
    dom.ansiArtBoxShadowBlurInput.addEventListener('input', updateFn);
    dom.ansiArtBoxShadowColorInput.addEventListener('input', updateFn);
    dom.ansiArtBoxShadowColorAlphaSlider.addEventListener('input', (e) => {
        if(dom.ansiArtBoxShadowColorAlphaValueDisplay) dom.ansiArtBoxShadowColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
        updateFn();
    });

    dom.deleteAnsiArtBtn.addEventListener('click', deleteSelectedControl);
}


export function handlePaletteItemDragStart(event: DragEvent) {
    const target = event.target as HTMLElement;
    const controlType = target.dataset.controlType;
    if (controlType && event.dataTransfer) {
        event.dataTransfer.setData('text/plain', controlType); 
        event.dataTransfer.effectAllowed = 'copy';
    }
}

export function handleDroppedControlDragStart(event: DragEvent) {
    const target = event.target as HTMLElement;
    if (target.dataset.droppedControlId && event.dataTransfer) {
        event.dataTransfer.setData('application/tesseract-dropped-control-id', target.dataset.droppedControlId);
        event.dataTransfer.effectAllowed = 'move';
        target.classList.add('dragging-control');
        target.style.opacity = '0.3'; 
    }
}

export function handleDroppedControlDragEnd(event: DragEvent) {
    const target = event.target as HTMLElement;
    target.classList.remove('dragging-control');
    target.style.opacity = ''; 
}

export function handleDragEnter(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    const target = event.currentTarget as HTMLElement;
    target.classList.add('drag-over-active');
    if (event.dataTransfer) {
        if (event.dataTransfer.types.includes('application/tesseract-dropped-control-id')) {
            event.dataTransfer.dropEffect = 'move';
        } else {
            event.dataTransfer.dropEffect = 'copy';
        }
    }
}

export function handleDragOver(event: DragEvent) {
    event.preventDefault(); 
    event.stopPropagation();
    if (event.dataTransfer) {
        if (event.dataTransfer.types.includes('application/tesseract-dropped-control-id')) {
            event.dataTransfer.dropEffect = 'move';
        } else {
            event.dataTransfer.dropEffect = 'copy';
        }
    }
}

export function handleDragLeave(event: DragEvent) {
    event.preventDefault(); 
    event.stopPropagation();
    const target = event.currentTarget as HTMLElement;
    target.classList.remove('drag-over-active');
}


export function handleDrop(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation(); 
    const dropTarget = event.currentTarget as HTMLElement;
    dropTarget.classList.remove('drag-over-active');

    if (!event.dataTransfer) return;

    const droppedControlId = event.dataTransfer.getData('application/tesseract-dropped-control-id');

    if (droppedControlId) { 
        const controlToMove = document.querySelector(`[data-dropped-control-id="${droppedControlId}"]`) as HTMLElement;
        if (controlToMove && controlToMove.parentElement !== dropTarget) { 
            const oldParent = controlToMove.parentElement;
            if (oldParent) {
                oldParent.removeChild(controlToMove);
                if (oldParent.id === 'layer-2') updatePlaceholderVisibility(oldParent, '.layer2-empty-placeholder');
                else if (oldParent.classList.contains('decorative-element')) updatePlaceholderVisibility(oldParent, '.decorative-element-empty-placeholder');
                else if (oldParent.classList.contains('dropped-row-container') || oldParent.classList.contains('dropped-column-container')) updatePlaceholderVisibility(oldParent, '.container-empty-placeholder');
            }
            dropTarget.appendChild(controlToMove);
             // Explicitly select the moved control
            selectControlInPanel(controlToMove as HTMLElement);


            if (dropTarget.id === 'layer-2') updatePlaceholderVisibility(dropTarget, '.layer2-empty-placeholder');
            else if (dropTarget.classList.contains('decorative-element')) updatePlaceholderVisibility(dropTarget, '.decorative-element-empty-placeholder');
            else if (dropTarget.classList.contains('dropped-row-container') || dropTarget.classList.contains('dropped-column-container')) updatePlaceholderVisibility(dropTarget, '.container-empty-placeholder');
            
            return;
        } else if (controlToMove && controlToMove.parentElement === dropTarget) {
            return; 
        }
    } else { 
        const controlType = event.dataTransfer.getData('text/plain') as ControlPaletteItemType;
        let newControl: HTMLElement | null = null;

        switch (controlType) {
            case 'button':
                newControl = document.createElement('button');
                newControl.className = 'dropped-control dropped-button bg-blue-500 text-white p-2 rounded';
                newControl.textContent = 'Button';
                newControl.style.display = 'flex';
                newControl.style.alignItems = 'center'; 
                newControl.style.justifyContent = 'center'; 
                newControl.style.textAlign = 'center';
                break;
            case 'text-input':
                newControl = document.createElement('input');
                const textInput = newControl as HTMLInputElement;
                textInput.type = 'text';
                textInput.placeholder = 'Text Input';
                newControl.className = 'dropped-control dropped-input p-2 border border-gray-400 rounded bg-white text-gray-800';
                newControl.style.textAlign = 'left';
                break;
            case 'row-container':
                newControl = document.createElement('div');
                newControl.className = 'dropped-control dropped-row-container flex flex-row border border-dashed border-gray-500 p-2 min-h-[50px] space-x-2 items-start w-full';
                newControl.dataset.droppableType = 'container';
                newControl.innerHTML = '<span class="container-empty-placeholder text-xs text-gray-400 italic p-1 self-center pointer-events-none">Row</span>';
                newControl.style.alignItems = 'flex-start';
                newControl.style.justifyContent = 'flex-start';
                setupDroppable(newControl); 
                break;
            case 'column-container':
                newControl = document.createElement('div');
                newControl.className = 'dropped-control dropped-column-container flex flex-col border border-dashed border-gray-500 p-2 min-h-[50px] space-y-2 items-start w-full';
                newControl.dataset.droppableType = 'container';
                newControl.innerHTML = '<span class="container-empty-placeholder text-xs text-gray-400 italic p-1 self-center pointer-events-none">Col</span>';
                newControl.style.alignItems = 'flex-start'; 
                newControl.style.justifyContent = 'flex-start'; 
                setupDroppable(newControl); 
                break;
            case 'text-block':
                newControl = document.createElement('p');
                newControl.className = 'dropped-control dropped-text-block text-gray-200 p-1';
                newControl.textContent = 'Some text content...';
                newControl.style.display = 'flex';
                newControl.style.alignItems = 'flex-start'; 
                newControl.style.textAlign = 'left';
                break;
            case 'image-element':
                newControl = document.createElement('div');
                newControl.className = 'dropped-control dropped-image-element w-24 h-24 bg-gray-600 bg-cover bg-center flex items-center justify-center text-gray-400 italic';
                newControl.textContent = 'Image';
                break;
            case 'text-colors': // Advanced TextColors Component
                newControl = document.createElement('div');
                newControl.className = 'dropped-control dropped-text-colors-component'; // Add specific class
                newControl.dataset.textContent = DEFAULT_TEXTCOLORS_TEXT_CONTENT;
                newControl.dataset.color1 = DEFAULT_TEXTCOLORS_COLOR1;
                newControl.dataset.color2 = DEFAULT_TEXTCOLORS_COLOR2;
                newControl.dataset.gradientMode = DEFAULT_TEXTCOLORS_GRADIENT_MODE;
                newControl.dataset.color1Fill = DEFAULT_TEXTCOLORS_COLOR1_FILL.toString();
                newControl.dataset.gradientAngle = DEFAULT_TEXTCOLORS_GRADIENT_ANGLE.toString();
                newControl.dataset.color2Start = DEFAULT_TEXTCOLORS_COLOR2_START.toString();
                newControl.dataset.fontFamily = DEFAULT_TEXTCOLORS_FONT_FAMILY;
                newControl.dataset.fontSize = DEFAULT_TEXTCOLORS_FONT_SIZE.toString();
                newControl.dataset.fontWeight = DEFAULT_TEXTCOLORS_FONT_WEIGHT;
                newControl.dataset.fontStyle = DEFAULT_TEXTCOLORS_FONT_STYLE;
                newControl.dataset.decorationUnderline = DEFAULT_TEXTCOLORS_DECORATION_UNDERLINE.toString();
                newControl.dataset.decorationOverline = DEFAULT_TEXTCOLORS_DECORATION_OVERLINE.toString();
                newControl.dataset.decorationLinethrough = DEFAULT_TEXTCOLORS_DECORATION_LINETHROUGH.toString();
                newControl.dataset.textTransform = DEFAULT_TEXTCOLORS_TEXT_TRANSFORM;
                newControl.dataset.lineHeight = DEFAULT_TEXTCOLORS_LINE_HEIGHT.toString();
                newControl.dataset.letterSpacing = DEFAULT_TEXTCOLORS_LETTER_SPACING.toString();
                newControl.dataset.wordSpacing = DEFAULT_TEXTCOLORS_WORD_SPACING.toString();
                newControl.dataset.textAlign = DEFAULT_TEXTCOLORS_TEXT_ALIGN;
                newControl.dataset.fontVariant = DEFAULT_TEXTCOLORS_FONT_VARIANT;
                break;
            case 'ansi-art-viewer':
                newControl = document.createElement('div');
                newControl.className = 'dropped-control dropped-ansi-art-viewer';
                newControl.dataset.ansiContent = ''; 
                newControl.innerHTML = `
                    <div class="ansi-art-content-wrapper">
                        <span class="ansi-art-placeholder">Paste ANSI/ASCII art here</span>
                    </div>`;
                break;
            case 'html-control':
                newControl = document.createElement('div');
                newControl.className = 'dropped-control dropped-html-control w-full h-48 bg-slate-700/30 border border-slate-600 rounded';
                newControl.style.minHeight = '100px'; // Ensure it has some initial size
                newControl.dataset.htmlContent = DEFAULT_HTML_CONTENT;
                newControl.dataset.cssContent = DEFAULT_CSS_CONTENT;
                newControl.dataset.jsContent = DEFAULT_JS_CONTENT;
                newControl.innerHTML = `<iframe class="html-control-render-iframe w-full h-full border-0 pointer-events-none" sandbox="allow-scripts allow-same-origin"></iframe>`;
                break;
        }

        if (newControl) {
            newControl.dataset.controlType = controlType;
            newControl.dataset.droppedControlId = generateUniqueId('dc');
            newControl.draggable = true; 
            newControl.addEventListener('dragstart', handleDroppedControlDragStart);
            newControl.addEventListener('dragend', handleDroppedControlDragEnd);
            newControl.addEventListener('click', (e) => selectControlInPanel(newControl as HTMLElement, e));
            
            dropTarget.appendChild(newControl);
            
            selectControlInPanel(newControl as HTMLElement);
           
            if (dropTarget.id === 'layer-2') updatePlaceholderVisibility(dropTarget, '.layer2-empty-placeholder');
            else if (dropTarget.classList.contains('decorative-element')) updatePlaceholderVisibility(dropTarget, '.decorative-element-empty-placeholder');
            else if (dropTarget.classList.contains('dropped-row-container') || dropTarget.classList.contains('dropped-column-container')) updatePlaceholderVisibility(dropTarget, '.container-empty-placeholder');
            
            if (controlType === 'text-colors') {
                 renderTextColorsComponent(newControl);
            } else if (controlType === 'ansi-art-viewer') {
                applyStylesToAnsiArtViewer(newControl); 
            } else if (controlType === 'html-control') {
                // Use setTimeout to ensure the element is in the DOM and iframe is accessible
                setTimeout(() => applyCustomHtmlCode(newControl!), 0);
            }
        }
    }
}

export function setupDroppable(element: HTMLElement) {
    element.addEventListener('dragenter', handleDragEnter);
    element.addEventListener('dragover', handleDragOver);
    element.addEventListener('dragleave', handleDragLeave);
    element.addEventListener('drop', handleDrop);

    let placeholderSelector = '';
    let placeholderText = 'Drop here';
    let placeholderClass = '';

    if (element.id === 'layer-2') {
        placeholderSelector = '.layer2-empty-placeholder';
        placeholderClass = 'layer2-empty-placeholder text-slate-500 italic text-center w-full p-10 pointer-events-none';
        placeholderText = 'Drop controls here';
    } else if (element.classList.contains('decorative-element')) {
        placeholderSelector = '.decorative-element-empty-placeholder';
        placeholderClass = 'decorative-element-empty-placeholder text-slate-500 italic text-center w-full p-2 pointer-events-none text-xs';
    } else if (element.classList.contains('dropped-row-container') || element.classList.contains('dropped-column-container')) {
        // Placeholder is already part of the HTML structure for these containers.
        // We only need to manage its visibility.
        placeholderSelector = '.container-empty-placeholder';
    }


    if (placeholderSelector && !element.querySelector(placeholderSelector) && placeholderClass) {
        const placeholder = document.createElement('span');
        placeholder.className = placeholderClass;
        placeholder.textContent = placeholderText;
        element.appendChild(placeholder); 
    }
    
    if(placeholderSelector) {
        updatePlaceholderVisibility(element, placeholderSelector);
    }
}

// Renaming the import from selectionManager to avoid conflict if this file also needs to export a function named handleControlSelection internally.
// The one from selectionManager is used for updating the panel when a control is selected.
export { selectControlInPanel as handleControlSelection };