

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from './domElements';
import * as state from './state';
import { applyStylesToLayer2 } from './styleUpdater';
import { REM_TO_PX_RATIO, SHADOW_CLASSES, BACKDROP_BLUR_CLASSES } from './constants';
import { combineHexAndAlphaToRGBA, splitColorToHexAndAlpha } from './utils';
import type { Layer2Config, ElementBorderStyle, BackgroundSizeType, BackgroundRepeatType } from './types';

export function initializeLayer2Config() {
    if (!dom.layer2Element) { 
        console.warn("Layer 2 element not found during initialization, using default config from state.");
        return; 
    }
    const computedStyle = getComputedStyle(dom.layer2Element);

    let widthPercent = state.layer2Config.widthPercent; 
    if (dom.layer2Element.style.width && dom.layer2Element.style.width.endsWith('%')) {
        widthPercent = parseFloat(dom.layer2Element.style.width);
    } else if (dom.layer2Element.classList.contains('w-4/5')) { 
        widthPercent = 80;
    } else if (dom.layer2Element.classList.contains('w-1/2')) { 
        widthPercent = 50;
    }
   
    let heightPercent = state.layer2Config.heightPercent; 
    if (dom.layer2Element.style.height && dom.layer2Element.style.height.endsWith('%')) {
        heightPercent = parseFloat(dom.layer2Element.style.height);
    } else if (dom.layer2Element.classList.contains('h-4/5')) { 
        heightPercent = 80;
    } else if (dom.layer2Element.classList.contains('h-1/2')) { 
        heightPercent = 50;
    }
    
    let paddingPx = state.layer2Config.paddingPx; 
    if (dom.layer2Element.style.padding) { 
        paddingPx = parseFloat(dom.layer2Element.style.padding);
    } else { 
        const paddingClass = Array.from(dom.layer2Element.classList).find(c => c.startsWith('p-'));
        if (paddingClass === 'p-6') paddingPx = 1.5 * REM_TO_PX_RATIO; // Example: p-6 in Tailwind is 1.5rem
    }

    let borderWidthPx = state.layer2Config.borderWidthPx; 
    if (dom.layer2Element.style.borderWidth) {
        borderWidthPx = parseFloat(dom.layer2Element.style.borderWidth);
    } else {
         const borderClass = Array.from(dom.layer2Element.classList).find(c => c.startsWith('border-['));
         if (borderClass) {
            const match = borderClass.match(/border-\[(\d+)px\]/);
            if (match && match[1]) borderWidthPx = parseInt(match[1]);
         }
    }
    
    const newLayer2Config: Layer2Config = {
        isVisible: computedStyle.display !== 'none',
        widthPercent: widthPercent,
        heightPercent: heightPercent,
        paddingPx: paddingPx,
        bgColor: computedStyle.backgroundColor || state.layer2Config.bgColor,
        opacity: parseFloat(computedStyle.opacity) || state.layer2Config.opacity || 1,
        imageUrl: state.layer2Config.imageUrl || '', // No direct way to get this from computedStyle or class usually
        backgroundSize: state.layer2Config.backgroundSize || 'cover',
        bgRepeat: state.layer2Config.bgRepeat || 'no-repeat',
        bgPosition: state.layer2Config.bgPosition || 'center center',
        borderWidthPx: borderWidthPx,
        borderColor: computedStyle.borderColor || state.layer2Config.borderColor, 
        borderStyle: (computedStyle.borderStyle as ElementBorderStyle) || state.layer2Config.borderStyle || 'solid',
        borderRadiusPx: parseFloat(computedStyle.borderRadius) || state.layer2Config.borderRadiusPx || 0,
        shadowClass: Array.from(dom.layer2Element.classList).find(cls => SHADOW_CLASSES.includes(cls)) || state.layer2Config.shadowClass,
        backdropBlurClass: Array.from(dom.layer2Element.classList).find(cls => BACKDROP_BLUR_CLASSES.includes(cls) && cls !== '') || state.layer2Config.backdropBlurClass || 'backdrop-blur-md',
    };
    state.setLayer2Config(newLayer2Config);
}


export function updateLayer2PanelInputs() {
    if (!dom.layer2VisibleInput || !dom.layer2WidthInput || !dom.layer2HeightInput || !dom.layer2PaddingInput ||
        !dom.layer2BgColorInput || !dom.layer2BgColorAlphaSlider || !dom.layer2BgColorAlphaValueDisplay ||
        !dom.layer2BorderWidthInput || !dom.layer2BorderColorInput || !dom.layer2BorderColorAlphaSlider || !dom.layer2BorderColorAlphaValueDisplay ||
        !dom.layer2ShadowSelect || !dom.layer2BackdropBlurSelect || !state.layer2Config) return;

    dom.layer2VisibleInput.checked = state.layer2Config.isVisible;
    dom.layer2WidthInput.value = state.layer2Config.widthPercent.toString();
    dom.layer2HeightInput.value = state.layer2Config.heightPercent.toString();
    dom.layer2PaddingInput.value = state.layer2Config.paddingPx.toString();

    const bgColorParsed = splitColorToHexAndAlpha(state.layer2Config.bgColor);
    dom.layer2BgColorInput.value = bgColorParsed.hexRGB;
    dom.layer2BgColorAlphaSlider.value = bgColorParsed.alpha.toString();
    dom.layer2BgColorAlphaValueDisplay.textContent = bgColorParsed.alpha.toFixed(2);

    dom.layer2BorderWidthInput.value = state.layer2Config.borderWidthPx.toString();
    const borderColorParsed = splitColorToHexAndAlpha(state.layer2Config.borderColor);
    dom.layer2BorderColorInput.value = borderColorParsed.hexRGB;
    dom.layer2BorderColorAlphaSlider.value = borderColorParsed.alpha.toString();
    dom.layer2BorderColorAlphaValueDisplay.textContent = borderColorParsed.alpha.toFixed(2);

    dom.layer2ShadowSelect.value = state.layer2Config.shadowClass;
    dom.layer2BackdropBlurSelect.value = state.layer2Config.backdropBlurClass;

    // Panel inputs for new properties (opacity, imageUrl, etc.) are not added in this update.
    // If they were, they would be updated here.
    // e.g., if dom.layer2OpacitySlider exists:
    // if (dom.layer2OpacitySlider && state.layer2Config.opacity !== undefined) {
    //    dom.layer2OpacitySlider.value = state.layer2Config.opacity.toString();
    // }
}


export function setupLayer2PanelListeners() {
    if (!dom.layer2VisibleInput || !dom.layer2WidthInput || !dom.layer2HeightInput || !dom.layer2PaddingInput || 
        !dom.layer2BgColorInput || !dom.layer2BgColorAlphaSlider || !dom.layer2BgColorAlphaValueDisplay ||
        !dom.layer2BorderWidthInput || !dom.layer2BorderColorInput || !dom.layer2BorderColorAlphaSlider || !dom.layer2BorderColorAlphaValueDisplay ||
        !dom.layer2ShadowSelect || !dom.layer2BackdropBlurSelect) return;

    const updateBgColor = () => {
        if (!dom.layer2BgColorInput || !dom.layer2BgColorAlphaSlider) return;
        const newBgColor = combineHexAndAlphaToRGBA(dom.layer2BgColorInput.value, parseFloat(dom.layer2BgColorAlphaSlider.value));
        state.updateLayer2Config({ bgColor: newBgColor });
        applyStylesToLayer2();
    };

    const updateBorderColor = () => {
        if (!dom.layer2BorderColorInput || !dom.layer2BorderColorAlphaSlider) return;
        const newBorderColor = combineHexAndAlphaToRGBA(dom.layer2BorderColorInput.value, parseFloat(dom.layer2BorderColorAlphaSlider.value));
        state.updateLayer2Config({ borderColor: newBorderColor });
        applyStylesToLayer2();
    };


    dom.layer2VisibleInput.addEventListener('change', (e) => {
        state.updateLayer2Config({ isVisible: (e.target as HTMLInputElement).checked });
        applyStylesToLayer2();
    });
    dom.layer2WidthInput.addEventListener('input', (e) => {
        state.updateLayer2Config({ widthPercent: parseFloat((e.target as HTMLInputElement).value) || 80 }); 
        applyStylesToLayer2();
    });
    dom.layer2HeightInput.addEventListener('input', (e) => {
        state.updateLayer2Config({ heightPercent: parseFloat((e.target as HTMLInputElement).value) || 80 });
        applyStylesToLayer2();
    });
    dom.layer2PaddingInput.addEventListener('input', (e) => {
        state.updateLayer2Config({ paddingPx: parseFloat((e.target as HTMLInputElement).value) || 0 });
        applyStylesToLayer2();
    });

    dom.layer2BgColorInput.addEventListener('input', updateBgColor);
    dom.layer2BgColorAlphaSlider.addEventListener('input', (e) => {
        if(dom.layer2BgColorAlphaValueDisplay) dom.layer2BgColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
        updateBgColor();
    });

    dom.layer2BorderWidthInput.addEventListener('input', (e) => {
        state.updateLayer2Config({ borderWidthPx: parseFloat((e.target as HTMLInputElement).value) || 0 });
        applyStylesToLayer2();
    });

    dom.layer2BorderColorInput.addEventListener('input', updateBorderColor);
    dom.layer2BorderColorAlphaSlider.addEventListener('input', (e) => {
        if(dom.layer2BorderColorAlphaValueDisplay) dom.layer2BorderColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
        updateBorderColor();
    });

    dom.layer2ShadowSelect.addEventListener('change', (e) => {
        state.updateLayer2Config({ shadowClass: (e.target as HTMLSelectElement).value });
        applyStylesToLayer2();
    });
    dom.layer2BackdropBlurSelect.addEventListener('change', (e) => {
        state.updateLayer2Config({ backdropBlurClass: (e.target as HTMLSelectElement).value });
        applyStylesToLayer2();
    });

    // Listeners for new properties (opacity, imageUrl, etc.) are not added here
    // as their panel inputs are omitted for this update.
}