/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from './domElements';
import * as state from './state';
import { 
    DEFAULT_TEXTCOLORS_TEXT_CONTENT,
    DEFAULT_TEXTCOLORS_COLOR1,
    DEFAULT_TEXTCOLORS_COLOR2,
    DEFAULT_TEXTCOLORS_GRADIENT_MODE,
    DEFAULT_TEXTCOLORS_COLOR1_FILL,
    DEFAULT_TEXTCOLORS_GRADIENT_ANGLE,
    DEFAULT_TEXTCOLORS_COLOR2_START,
    DEFAULT_TEXTCOLORS_FONT_FAMILY,
    DEFAULT_TEXTCOLORS_FONT_SIZE,
    DEFAULT_TEXTCOLORS_FONT_WEIGHT,
    DEFAULT_TEXTCOLORS_FONT_STYLE,
    DEFAULT_TEXTCOLORS_DECORATION_UNDERLINE,
    DEFAULT_TEXTCOLORS_DECORATION_OVERLINE,
    DEFAULT_TEXTCOLORS_DECORATION_LINETHROUGH,
    DEFAULT_TEXTCOLORS_TEXT_TRANSFORM,
    DEFAULT_TEXTCOLORS_LINE_HEIGHT,
    DEFAULT_TEXTCOLORS_LETTER_SPACING,
    DEFAULT_TEXTCOLORS_WORD_SPACING,
    DEFAULT_TEXTCOLORS_TEXT_ALIGN,
    DEFAULT_TEXTCOLORS_FONT_VARIANT
} from './constants';
import type { TextColorAdvancedGradientMode } from './types';
import { deleteSelectedControl } from './droppedControlController';
import { escapeHtml, combineHexAndAlphaToRGBA } from './utils';


export function renderTextColorsComponent(element: HTMLElement) {
    const textContent = element.dataset.textContent || DEFAULT_TEXTCOLORS_TEXT_CONTENT;
    
    // Color 1 with alpha
    const color1Hex = element.dataset.color1 || DEFAULT_TEXTCOLORS_COLOR1;
    const color1Alpha = parseFloat(element.dataset.color1Alpha || "1");
    const color1 = combineHexAndAlphaToRGBA(color1Hex, color1Alpha);

    // Color 2 with alpha
    const color2Hex = element.dataset.color2 || DEFAULT_TEXTCOLORS_COLOR2;
    const color2Alpha = parseFloat(element.dataset.color2Alpha || "1");
    const color2 = combineHexAndAlphaToRGBA(color2Hex, color2Alpha);

    const gradientMode = (element.dataset.gradientMode || DEFAULT_TEXTCOLORS_GRADIENT_MODE) as TextColorAdvancedGradientMode;
    const color1Fill = element.dataset.color1Fill || DEFAULT_TEXTCOLORS_COLOR1_FILL;
    const gradientAngle = element.dataset.gradientAngle || DEFAULT_TEXTCOLORS_GRADIENT_ANGLE;
    const color2Start = element.dataset.color2Start || DEFAULT_TEXTCOLORS_COLOR2_START;

    const fontFamily = element.dataset.fontFamily || DEFAULT_TEXTCOLORS_FONT_FAMILY;
    const fontSize = element.dataset.fontSize || DEFAULT_TEXTCOLORS_FONT_SIZE;
    const fontWeight = element.dataset.fontWeight || DEFAULT_TEXTCOLORS_FONT_WEIGHT;
    const fontStyle = element.dataset.fontStyle || DEFAULT_TEXTCOLORS_FONT_STYLE;
    const decorationUnderline = (element.dataset.decorationUnderline || DEFAULT_TEXTCOLORS_DECORATION_UNDERLINE.toString()) === 'true';
    const decorationOverline = (element.dataset.decorationOverline || DEFAULT_TEXTCOLORS_DECORATION_OVERLINE.toString()) === 'true';
    const decorationLinethrough = (element.dataset.decorationLinethrough || DEFAULT_TEXTCOLORS_DECORATION_LINETHROUGH.toString()) === 'true';
    const textTransform = element.dataset.textTransform || DEFAULT_TEXTCOLORS_TEXT_TRANSFORM;
    const lineHeight = element.dataset.lineHeight || DEFAULT_TEXTCOLORS_LINE_HEIGHT;
    const letterSpacing = element.dataset.letterSpacing || DEFAULT_TEXTCOLORS_LETTER_SPACING;
    const wordSpacing = element.dataset.wordSpacing || DEFAULT_TEXTCOLORS_WORD_SPACING;
    const textAlign = element.dataset.textAlign || DEFAULT_TEXTCOLORS_TEXT_ALIGN;
    const fontVariant = element.dataset.fontVariant || DEFAULT_TEXTCOLORS_FONT_VARIANT;

    element.innerHTML = ''; // Clear previous content

    element.style.textAlign = textAlign;
    element.style.lineHeight = lineHeight;
    if (gradientMode === 'word') {
        element.style.wordSpacing = `${wordSpacing}px`; 
    } else {
        element.style.wordSpacing = 'normal'; 
    }

    let DANGEROUS_generatedHtml = '';
    const escapedText = escapeHtml(textContent);

    const textDecorations: string[] = [];
    if (decorationUnderline) textDecorations.push('underline');
    if (decorationOverline) textDecorations.push('overline');
    if (decorationLinethrough) textDecorations.push('line-through');
    
    let fontSpecificStyles = `font-family: ${fontFamily}; font-size: ${fontSize}px; font-weight: ${fontWeight}; font-style: ${fontStyle}; text-decoration: ${textDecorations.join(' ') || 'none'}; text-transform: ${textTransform}; letter-spacing: ${letterSpacing}px; font-variant: ${fontVariant};`;
    
    if (gradientMode === 'phrase') {
        fontSpecificStyles += ` word-spacing: ${wordSpacing}px;`;
    }

    const gradientStyleBase = `background-image: linear-gradient(${gradientAngle}deg, ${color1} ${color1Fill}%, ${color2} ${color2Start}%); color: transparent; -webkit-background-clip: text; background-clip: text;`;
    const combinedStyleForSpans = `${fontSpecificStyles} ${gradientStyleBase}`;

    if (gradientMode === 'word') {
        const parts = escapedText.split(/(\s+)/); 
        DANGEROUS_generatedHtml = parts.map(part => {
            if (part.match(/\S+/)) { 
                return `<span style="${combinedStyleForSpans} display: inline-block;">${part}</span>`;
            }
            return part.replace(/\n/g, '<br>');
        }).join('');
    } else { 
        DANGEROUS_generatedHtml = `<span style="${combinedStyleForSpans}">${escapedText.replace(/\n/g, '<br>')}</span>`;
    }
    
    element.innerHTML = DANGEROUS_generatedHtml;
}


export function setupTextColorsComponentPanelListeners() {
    const inputs = [
        dom.textColorsContentInput, 
        dom.textColorsColor1Picker, dom.textColorsColor1AlphaSlider, 
        dom.textColorsColor2Picker, dom.textColorsColor2AlphaSlider,
        dom.textColorsGradientModeSelect, dom.textColorsColor1FillSlider, dom.textColorsGradientAngleSlider,
        dom.textColorsColor2StartSlider, dom.textColorsFontFamilySelect, dom.textColorsFontSizeInput,
        dom.textColorsFontWeightSelect, dom.textColorsFontStyleSelect, dom.textColorsDecorationUnderline,
        dom.textColorsDecorationOverline, dom.textColorsDecorationLinethrough, dom.textColorsTextTransformSelect,
        dom.textColorsLineHeightInput, dom.textColorsLetterSpacingInput, dom.textColorsWordSpacingInput,
        dom.textColorsTextAlignSelect, dom.textColorsFontVariantSelect, dom.deleteTextColorsControlBtn
    ];
    if (inputs.some(input => !input)) {
        console.warn("One or more TextColors panel inputs are missing. Listeners not fully set up.");
        return;
    }

    const updateAndRender = () => {
        if (state.selectedDroppedControl && state.selectedDroppedControl.dataset.controlType === 'text-colors') {
            const el = state.selectedDroppedControl;
            if (dom.textColorsContentInput) el.dataset.textContent = dom.textColorsContentInput.value;
            
            if (dom.textColorsColor1Picker) el.dataset.color1 = dom.textColorsColor1Picker.value;
            if (dom.textColorsColor1AlphaSlider) el.dataset.color1Alpha = dom.textColorsColor1AlphaSlider.value;
            
            if (dom.textColorsColor2Picker) el.dataset.color2 = dom.textColorsColor2Picker.value;
            if (dom.textColorsColor2AlphaSlider) el.dataset.color2Alpha = dom.textColorsColor2AlphaSlider.value;

            if (dom.textColorsGradientModeSelect) el.dataset.gradientMode = dom.textColorsGradientModeSelect.value;
            if (dom.textColorsColor1FillSlider) el.dataset.color1Fill = dom.textColorsColor1FillSlider.value;
            if (dom.textColorsGradientAngleSlider) el.dataset.gradientAngle = dom.textColorsGradientAngleSlider.value;
            if (dom.textColorsColor2StartSlider) el.dataset.color2Start = dom.textColorsColor2StartSlider.value;
            
            if (dom.textColorsFontFamilySelect) el.dataset.fontFamily = dom.textColorsFontFamilySelect.value;
            if (dom.textColorsFontSizeInput) el.dataset.fontSize = dom.textColorsFontSizeInput.value;
            if (dom.textColorsFontWeightSelect) el.dataset.fontWeight = dom.textColorsFontWeightSelect.value;
            if (dom.textColorsFontStyleSelect) el.dataset.fontStyle = dom.textColorsFontStyleSelect.value;
            if (dom.textColorsDecorationUnderline) el.dataset.decorationUnderline = String(dom.textColorsDecorationUnderline.checked);
            if (dom.textColorsDecorationOverline) el.dataset.decorationOverline = String(dom.textColorsDecorationOverline.checked);
            if (dom.textColorsDecorationLinethrough) el.dataset.decorationLinethrough = String(dom.textColorsDecorationLinethrough.checked);
            if (dom.textColorsTextTransformSelect) el.dataset.textTransform = dom.textColorsTextTransformSelect.value;
            if (dom.textColorsLineHeightInput) el.dataset.lineHeight = dom.textColorsLineHeightInput.value;
            if (dom.textColorsLetterSpacingInput) el.dataset.letterSpacing = dom.textColorsLetterSpacingInput.value;
            if (dom.textColorsWordSpacingInput) el.dataset.wordSpacing = dom.textColorsWordSpacingInput.value;
            if (dom.textColorsTextAlignSelect) el.dataset.textAlign = dom.textColorsTextAlignSelect.value;
            if (dom.textColorsFontVariantSelect) el.dataset.fontVariant = dom.textColorsFontVariantSelect.value;
            
            renderTextColorsComponent(el);
        }
    };

    const updateSliderValueDisplay = (slider: HTMLInputElement | null, display: HTMLSpanElement | null, suffix: string = '') => {
        if (slider && display) {
            display.textContent = `${parseFloat(slider.value).toFixed(2)}${suffix}`;
        }
    };
    const updatePercentSliderValueDisplay = (slider: HTMLInputElement | null, display: HTMLSpanElement | null) => {
        if (slider && display) {
            display.textContent = `${slider.value}%`;
        }
    };
     const updateDegreeSliderValueDisplay = (slider: HTMLInputElement | null, display: HTMLSpanElement | null) => {
        if (slider && display) {
            display.textContent = `${slider.value}°`;
        }
    };


    dom.textColorsContentInput?.addEventListener('input', updateAndRender);
    dom.textColorsColor1Picker?.addEventListener('input', updateAndRender);
    dom.textColorsColor1AlphaSlider?.addEventListener('input', () => {
        updateSliderValueDisplay(dom.textColorsColor1AlphaSlider, dom.textColorsColor1AlphaValueDisplay);
        updateAndRender();
    });
    dom.textColorsColor2Picker?.addEventListener('input', updateAndRender);
    dom.textColorsColor2AlphaSlider?.addEventListener('input', () => {
        updateSliderValueDisplay(dom.textColorsColor2AlphaSlider, dom.textColorsColor2AlphaValueDisplay);
        updateAndRender();
    });

    dom.textColorsGradientModeSelect?.addEventListener('change', updateAndRender);
    
    dom.textColorsColor1FillSlider?.addEventListener('input', () => {
        updatePercentSliderValueDisplay(dom.textColorsColor1FillSlider, dom.textColorsColor1FillValue);
        updateAndRender();
    });
    dom.textColorsGradientAngleSlider?.addEventListener('input', () => {
        updateDegreeSliderValueDisplay(dom.textColorsGradientAngleSlider, dom.textColorsGradientAngleValue);
        updateAndRender();
    });
    dom.textColorsColor2StartSlider?.addEventListener('input', () => {
        updatePercentSliderValueDisplay(dom.textColorsColor2StartSlider, dom.textColorsColor2StartValue);
        updateAndRender();
    });

    dom.textColorsFontFamilySelect?.addEventListener('change', updateAndRender);
    dom.textColorsFontSizeInput?.addEventListener('input', updateAndRender);
    dom.textColorsFontWeightSelect?.addEventListener('change', updateAndRender);
    dom.textColorsFontStyleSelect?.addEventListener('change', updateAndRender);
    dom.textColorsDecorationUnderline?.addEventListener('change', updateAndRender);
    dom.textColorsDecorationOverline?.addEventListener('change', updateAndRender);
    dom.textColorsDecorationLinethrough?.addEventListener('change', updateAndRender);
    dom.textColorsTextTransformSelect?.addEventListener('change', updateAndRender);
    dom.textColorsLineHeightInput?.addEventListener('input', updateAndRender);
    dom.textColorsLetterSpacingInput?.addEventListener('input', updateAndRender);
    dom.textColorsWordSpacingInput?.addEventListener('input', updateAndRender);
    dom.textColorsTextAlignSelect?.addEventListener('change', updateAndRender);
    dom.textColorsFontVariantSelect?.addEventListener('change', updateAndRender);

    dom.deleteTextColorsControlBtn?.addEventListener('click', deleteSelectedControl); 
}