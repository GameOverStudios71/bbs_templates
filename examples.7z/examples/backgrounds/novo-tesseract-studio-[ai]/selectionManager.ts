

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from './domElements';
import * as state from './state';
import { splitColorToHexAndAlpha, combineHexAndAlphaToRGBA } from './utils';
import { switchTab } from './configPanelManager';
import { updateElementHoverAnimationListeners } from './animationController';
import { 
    DEFAULT_TEXTCOLORS_TEXT_CONTENT,
    DEFAULT_TEXTCOLORS_COLOR1,
    DEFAULT_TEXTCOLORS_COLOR2,
    DEFAULT_TEXTCOLORS_GRADIENT_MODE,
    DEFAULT_TEXTCOLORS_COLOR1_FILL,
    DEFAULT_TEXTCOLORS_GRADIENT_ANGLE,
    DEFAULT_TEXTCOLORS_COLOR2_START,
    DEFAULT_TEXTCOLORS_FONT_FAMILY,
    DEFAULT_TEXTCOLORS_FONT_SIZE,
    DEFAULT_TEXTCOLORS_FONT_WEIGHT,
    DEFAULT_TEXTCOLORS_FONT_STYLE,
    DEFAULT_TEXTCOLORS_DECORATION_UNDERLINE,
    DEFAULT_TEXTCOLORS_DECORATION_OVERLINE,
    DEFAULT_TEXTCOLORS_DECORATION_LINETHROUGH,
    DEFAULT_TEXTCOLORS_TEXT_TRANSFORM,
    DEFAULT_TEXTCOLORS_LINE_HEIGHT,
    DEFAULT_TEXTCOLORS_LETTER_SPACING,
    DEFAULT_TEXTCOLORS_WORD_SPACING,
    DEFAULT_TEXTCOLORS_TEXT_ALIGN,
    DEFAULT_TEXTCOLORS_FONT_VARIANT
} from './constants';
import { DEFAULT_HTML_CONTENT, DEFAULT_CSS_CONTENT, DEFAULT_JS_CONTENT } from './htmlControlController';
import type { ElementConfig, FontStyleType, TextTransformType, TextDecorationType, TextAlignmentHorizontal, TextAlignmentVertical, FlexAlignItems, FlexJustifyContent, TextColorAdvancedGradientMode } from './types';


export function selectElement(id: string | null, switchTabToElement: boolean = true) {
  // Deselect previously selected decorative element
  if (state.lastSelectedElement && state.lastSelectedElement.dataset.elementId && state.elementsConfig[state.lastSelectedElement.dataset.elementId]) {
    state.lastSelectedElement.classList.remove('selected-element-highlight');
    updateElementHoverAnimationListeners(state.lastSelectedElement.dataset.elementId, true); 
  }

  // Deselect previously selected dropped control
  if (state.lastSelectedDroppedControl) {
      state.lastSelectedDroppedControl.classList.remove('selected-dropped-control-highlight');
  }
  state.setSelectedDroppedControl(null); // Clear selected dropped control state
  state.setLastSelectedDroppedControl(null);
  
  state.setSelectedElementId(id);

  if (id && state.elementsConfig[id]) { // A decorative element is selected
    const config = state.elementsConfig[id];
    state.setLastSelectedElement(config.element);
    config.element.classList.add('selected-element-highlight');
    
    updatePanelForSelectedDecorativeElement(config);
    updateElementHoverAnimationListeners(id); 

    if (switchTabToElement && state.activeTabId !== 'animations' && state.activeTabId !== 'presets' && state.activeTabId !== 'ai') { 
        switchTab('element'); 
    }
  } else { // No decorative element selected (or deselected)
    state.setLastSelectedElement(null);
    if (!state.selectedDroppedControl) { 
        updatePanelForNoSelection();
    }
  }
}


export function handleControlSelection(controlElement: HTMLElement, event?: MouseEvent) {
    if (event) {
        event.stopPropagation();
    }

    selectElement(null, false); 

    if (state.lastSelectedDroppedControl && state.lastSelectedDroppedControl !== controlElement) {
        state.lastSelectedDroppedControl.classList.remove('selected-dropped-control-highlight');
    }

    state.setSelectedDroppedControl(controlElement);
    state.setLastSelectedDroppedControl(controlElement);
    state.selectedDroppedControl.classList.add('selected-dropped-control-highlight');

    updatePanelForSelectedControl(controlElement); 
    if (state.activeTabId !== 'ai') { // Don't switch if AI is making the selection
        switchTab('controls');
    }
}


export function updatePanelForSelectedDecorativeElement(config: ElementConfig) {
    if (!dom.decorativeElementPropsSection || !dom.noElementSelectedMsg ||
        !dom.animationControlsContainer || !dom.noElementSelectedAnimationMsg || !dom.selectedElementNameDisplay ||
        !dom.animationSelectedElementNameDisplay || !dom.decorativeElementVisibilityControls ||
        !dom.controlPropertiesContainer || !dom.noControlSelectedMsgControlsTab ||
        !dom.droppedControlPropsSection || !dom.textColorsPropsSection || !dom.ansiArtPropsSection || !dom.htmlControlPropsSection
        ) return;

    dom.decorativeElementVisibilityControls.classList.remove('hidden');
    dom.decorativeElementPropsSection.classList.remove('hidden');
    dom.noElementSelectedMsg.classList.add('hidden');
    dom.selectedElementNameDisplay.textContent = `Element: ${config.id}`;
    
    if (dom.animationSelectedElementNameDisplay) dom.animationSelectedElementNameDisplay.textContent = `Element: ${config.id}`;
    dom.animationControlsContainer.style.display = 'block';
    dom.noElementSelectedAnimationMsg.style.display = 'none';
    
    if (dom.selectedControlNameControlsTabDisplay) dom.selectedControlNameControlsTabDisplay.textContent = 'None';
    dom.controlPropertiesContainer.classList.remove('hidden'); 
    dom.noControlSelectedMsgControlsTab.classList.remove('hidden'); // Show the message area
    dom.noControlSelectedMsgControlsTab.textContent = "Select a dropped control to see its properties, or drag one from the palette."; // Default message
    dom.droppedControlPropsSection.classList.add('hidden');
    dom.textColorsPropsSection.classList.add('hidden');
    dom.ansiArtPropsSection.classList.add('hidden');
    dom.htmlControlPropsSection.classList.add('hidden');
    
    updateDecorativeElementInputs(config);
}

export function updatePanelForSelectedControl(controlElement: HTMLElement) {
    if (!dom.decorativeElementPropsSection || !dom.noElementSelectedMsg ||
        !dom.animationControlsContainer || !dom.noElementSelectedAnimationMsg || !dom.selectedElementNameDisplay ||
        !dom.animationSelectedElementNameDisplay || !dom.decorativeElementVisibilityControls ||
        !dom.controlPropertiesContainer || !dom.noControlSelectedMsgControlsTab || !dom.selectedControlNameControlsTabDisplay ||
        !dom.droppedControlPropsSection || !dom.textColorsPropsSection || !dom.ansiArtPropsSection || !dom.htmlControlPropsSection ||
        !dom.textAlignmentControlsContainer || !dom.containerAlignmentControlsContainer || !dom.droppedControlTypographySection
        ) return;
    
    const controlType = controlElement.dataset.controlType || controlElement.tagName.toLowerCase();
    const controlId = controlElement.dataset.droppedControlId || 'N/A';

    dom.decorativeElementVisibilityControls.classList.remove('hidden'); 
    dom.decorativeElementPropsSection.classList.add('hidden');
    dom.noElementSelectedMsg.classList.remove('hidden');
    dom.noElementSelectedMsg.textContent = "Control selected. Properties are in the 'Controls' tab."
    dom.selectedElementNameDisplay.textContent = 'None (Control Selected)';
    
    if (dom.animationSelectedElementNameDisplay) dom.animationSelectedElementNameDisplay.textContent = 'N/A (Dropped Control)'; 
    dom.animationControlsContainer.style.display = 'none';
    dom.noElementSelectedAnimationMsg.style.display = 'block';
    dom.noElementSelectedAnimationMsg.textContent = 'Animation controls apply to Decorative Elements only.';

    dom.controlPropertiesContainer.classList.remove('hidden');
    dom.noControlSelectedMsgControlsTab.classList.add('hidden');
    dom.selectedControlNameControlsTabDisplay.textContent = `Type: ${controlType} (ID: ${controlId})`;

    // Hide all specific control property sections initially
    dom.droppedControlPropsSection.classList.add('hidden');
    dom.textColorsPropsSection.classList.add('hidden');
    dom.ansiArtPropsSection.classList.add('hidden');
    dom.htmlControlPropsSection.classList.add('hidden');
    dom.droppedControlTypographySection.classList.add('hidden'); 
    dom.textAlignmentControlsContainer.classList.add('hidden');
    dom.containerAlignmentControlsContainer.classList.add('hidden');


    if (controlType === 'text-colors') {
        dom.textColorsPropsSection.classList.remove('hidden');
        updateTextColorsComponentInputs(controlElement);
    } else if (controlType === 'ansi-art-viewer') {
        dom.ansiArtPropsSection.classList.remove('hidden');
        updateAnsiArtViewerInputs(controlElement);
    } else if (controlType === 'html-control') {
        dom.droppedControlPropsSection.classList.remove('hidden'); // Show generic container styles
        dom.htmlControlPropsSection.classList.remove('hidden');    // Show HTML/CSS/JS inputs
        updateDroppedControlInputs(controlElement); // For container: width, height, border, etc.
        updateHtmlControlInputs(controlElement);    // For code content
    } else { 
        dom.droppedControlPropsSection.classList.remove('hidden');
        updateDroppedControlInputs(controlElement);
        
        const isTextualControl = ['button', 'text-block', 'text-input'].includes(controlType);
        const isContainerControl = ['row-container', 'column-container'].includes(controlType);

        dom.droppedControlTypographySection.classList.toggle('hidden', !isTextualControl);
        dom.textAlignmentControlsContainer.classList.toggle('hidden', !isTextualControl);
        if(dom.textAlignVerticalSelect && controlType === 'text-input') {
            dom.textAlignVerticalSelect.disabled = true; 
        } else if (dom.textAlignVerticalSelect) {
            dom.textAlignVerticalSelect.disabled = false;
        }
        dom.containerAlignmentControlsContainer.classList.toggle('hidden', !isContainerControl);
    }
}

export function updatePanelForNoSelection() {
    if (!dom.decorativeElementPropsSection || !dom.noElementSelectedMsg ||
        !dom.animationControlsContainer || !dom.noElementSelectedAnimationMsg || !dom.selectedElementNameDisplay ||
        !dom.animationSelectedElementNameDisplay || !dom.decorativeElementVisibilityControls ||
        !dom.controlPropertiesContainer || !dom.noControlSelectedMsgControlsTab || !dom.selectedControlNameControlsTabDisplay ||
        !dom.droppedControlPropsSection || !dom.textColorsPropsSection || !dom.ansiArtPropsSection || !dom.htmlControlPropsSection
        ) return;

    dom.decorativeElementVisibilityControls.classList.remove('hidden');
    dom.decorativeElementPropsSection.classList.add('hidden');
    dom.noElementSelectedMsg.classList.remove('hidden');
    dom.noElementSelectedMsg.textContent = "Select a Decorative Element on the canvas or Layer 2 in the Globals tab to see its properties."
    dom.selectedElementNameDisplay.textContent = 'None';
    
    if (dom.animationSelectedElementNameDisplay) dom.animationSelectedElementNameDisplay.textContent = 'None';
    dom.animationControlsContainer.style.display = 'none';
    dom.noElementSelectedAnimationMsg.style.display = 'block';
    dom.noElementSelectedAnimationMsg.textContent = 'Select a Decorative Element to configure animations.';

    if(dom.selectedControlNameControlsTabDisplay) dom.selectedControlNameControlsTabDisplay.textContent = 'None';
    dom.controlPropertiesContainer.classList.remove('hidden'); 
    dom.noControlSelectedMsgControlsTab.classList.remove('hidden');
    dom.noControlSelectedMsgControlsTab.textContent = "Select a dropped control to see its properties, or drag one from the palette.";
    dom.droppedControlPropsSection.classList.add('hidden');
    dom.textColorsPropsSection.classList.add('hidden');
    dom.ansiArtPropsSection.classList.add('hidden');
    dom.htmlControlPropsSection.classList.add('hidden');
}


export function updateDecorativeElementInputs(config: ElementConfig) {
  if (!dom.visibleInput || !dom.elDisplaySelect || !dom.elZIndexInput || !dom.elOverflowXSelect || !dom.elOverflowYSelect ||
      !dom.widthInput || !dom.heightInput || 
      !dom.bgColorInput || !dom.bgColorAlphaSlider || !dom.bgColorAlphaValueDisplay ||
      !dom.shadowSelect ||
      !dom.marginTopInput || !dom.marginRightInput || !dom.marginBottomInput || !dom.marginLeftInput ||
      !dom.imageUrlInput || !dom.bgSizeSelect || !dom.elBgRepeatSelect || !dom.elBgPositionInput ||
      !dom.opacityInput || !dom.opacityValueDisplay || !dom.elBlurInput || !dom.elBlurValueDisplay ||
      !dom.elBrightnessInput || !dom.elBrightnessValueDisplay || !dom.elContrastInput || !dom.elContrastValueDisplay ||
      !dom.elSaturateInput || !dom.elSaturateValueDisplay || !dom.elGrayscaleInput || !dom.elGrayscaleValueDisplay ||
      !dom.elSepiaInput || !dom.elSepiaValueDisplay || !dom.elInvertInput || !dom.elInvertValueDisplay ||
      !dom.elHueRotateInput || !dom.elHueRotateValueDisplay ||
      !dom.elBorderWidthInput || !dom.elBorderStyleSelect || 
      !dom.elBorderColorInput || !dom.elBorderColorAlphaSlider || !dom.elBorderColorAlphaValueDisplay ||
      !dom.elBorderRadiusInput || 
      !dom.elRotationInput || !dom.elRotationValueDisplay || !dom.elScaleInput || !dom.elScaleValueDisplay ||
      !dom.elTranslateXInput || !dom.elTranslateYInput || !dom.elSkewXInput || !dom.elSkewYInput ||
      !dom.animationNameSelect || !dom.animationIterationSelect || !dom.animationDelaySelect || 
      !dom.animationSpeedSelect || !dom.animationOnHoverCheckbox ) return;
  
  dom.visibleInput.checked = config.isVisible;
  dom.elDisplaySelect.value = config.display;
  dom.elZIndexInput.value = config.zIndex.toString();
  dom.elOverflowXSelect.value = config.overflowX;
  dom.elOverflowYSelect.value = config.overflowY;
  dom.widthInput.value = config.widthVmin.toString();
  dom.heightInput.value = config.heightVmin.toString();
  dom.marginTopInput.value = config.marginTopVmin.toString();
  dom.marginRightInput.value = config.marginRightVmin.toString();
  dom.marginBottomInput.value = config.marginBottomVmin.toString();
  dom.marginLeftInput.value = config.marginLeftVmin.toString();
  
  const bgColorParsed = splitColorToHexAndAlpha(config.bgColor);
  dom.bgColorInput.value = bgColorParsed.hexRGB;
  dom.bgColorAlphaSlider.value = bgColorParsed.alpha.toString();
  dom.bgColorAlphaValueDisplay.textContent = bgColorParsed.alpha.toFixed(2);

  dom.imageUrlInput.value = config.imageUrl;
  dom.bgSizeSelect.value = config.backgroundSize;
  dom.elBgRepeatSelect.value = config.bgRepeat;
  dom.elBgPositionInput.value = config.bgPosition;
  dom.shadowSelect.value = config.shadowClass;
  dom.opacityInput.value = config.opacity.toString();
  dom.opacityValueDisplay.textContent = config.opacity.toFixed(2);
  dom.elBlurInput.value = config.filterBlur.toString();
  dom.elBlurValueDisplay.textContent = config.filterBlur.toString();
  dom.elBrightnessInput.value = config.filterBrightness.toString();
  dom.elBrightnessValueDisplay.textContent = config.filterBrightness.toFixed(2);
  dom.elContrastInput.value = config.filterContrast.toString();
  dom.elContrastValueDisplay.textContent = config.filterContrast.toFixed(2);
  dom.elSaturateInput.value = config.filterSaturate.toString();
  dom.elSaturateValueDisplay.textContent = config.filterSaturate.toFixed(2);
  dom.elGrayscaleInput.value = config.filterGrayscale.toString();
  dom.elGrayscaleValueDisplay.textContent = config.filterGrayscale.toFixed(2);
  dom.elSepiaInput.value = config.filterSepia.toString();
  dom.elSepiaValueDisplay.textContent = config.filterSepia.toFixed(2);
  dom.elInvertInput.value = config.filterInvert.toString();
  dom.elInvertValueDisplay.textContent = config.filterInvert.toFixed(2);
  dom.elHueRotateInput.value = config.filterHueRotate.toString();
  dom.elHueRotateValueDisplay.textContent = config.filterHueRotate.toString();
  dom.elBorderWidthInput.value = config.borderWidthVmin.toString();
  dom.elBorderStyleSelect.value = config.borderStyle;

  const borderColorParsed = splitColorToHexAndAlpha(config.borderColor);
  dom.elBorderColorInput.value = borderColorParsed.hexRGB;
  dom.elBorderColorAlphaSlider.value = borderColorParsed.alpha.toString();
  dom.elBorderColorAlphaValueDisplay.textContent = borderColorParsed.alpha.toFixed(2);

  dom.elBorderRadiusInput.value = config.borderRadiusVmin.toString();
  dom.elRotationInput.value = config.rotationDeg.toString();
  dom.elRotationValueDisplay.textContent = config.rotationDeg.toString();
  dom.elScaleInput.value = config.transformScale.toString();
  dom.elScaleValueDisplay.textContent = config.transformScale.toFixed(2);
  dom.elTranslateXInput.value = config.transformTranslateX.toString();
  dom.elTranslateYInput.value = config.transformTranslateY.toString();
  dom.elSkewXInput.value = config.transformSkewX.toString();
  dom.elSkewYInput.value = config.transformSkewY.toString();

  dom.animationNameSelect.value = config.animationName;
  dom.animationIterationSelect.value = config.animationIterationClass;
  dom.animationDelaySelect.value = config.animationDelayClass;
  dom.animationSpeedSelect.value = config.animationSpeedClass;
  dom.animationOnHoverCheckbox.checked = config.animationOnHover;
}

export function updateDroppedControlInputs(control: HTMLElement) {
    if (!dom.droppedControlVisibleInput || !dom.droppedControlTextContentInput || !dom.droppedControlPlaceholderInput ||
        !dom.droppedControlImageSrcInput || !dom.droppedControlWidthInput || !dom.droppedControlHeightInput ||
        !dom.droppedControlBgColorInput || !dom.droppedControlBgColorAlphaSlider || !dom.droppedControlBgColorAlphaValueDisplay ||
        !dom.droppedControlTextColorInput || !dom.droppedControlTextColorAlphaSlider || !dom.droppedControlTextColorAlphaValueDisplay ||
        !dom.droppedControlOpacityInput || !dom.droppedControlOpacityValueDisplay ||
        !dom.droppedControlBorderRadiusInput || !dom.droppedControlBorderWidthInput || !dom.droppedControlBorderStyleSelect || 
        !dom.droppedControlBorderColorInput || !dom.droppedControlBorderColorAlphaSlider || !dom.droppedControlBorderColorAlphaValueDisplay ||
        !dom.droppedControlBoxShadowXInput || !dom.droppedControlBoxShadowYInput || !dom.droppedControlBoxShadowBlurInput || 
        !dom.droppedControlBoxShadowColorInput || !dom.droppedControlBoxShadowColorAlphaSlider || !dom.droppedControlBoxShadowColorAlphaValueDisplay ||
        !dom.droppedControlFontFamilyInput || !dom.droppedControlFontSizeInput || !dom.droppedControlFontWeightSelect ||
        !dom.droppedControlFontStyleSelect || !dom.droppedControlLineHeightInput || !dom.droppedControlLetterSpacingInput ||
        !dom.droppedControlTextTransformSelect || !dom.droppedControlTextDecorationSelect ||
        !dom.droppedControlTextShadowXInput || !dom.droppedControlTextShadowYInput || !dom.droppedControlTextShadowBlurInput || 
        !dom.droppedControlTextShadowColorInput || !dom.droppedControlTextShadowColorAlphaSlider || !dom.droppedControlTextShadowColorAlphaValueDisplay ||
        !dom.textAlignHorizontalSelect || !dom.textAlignVerticalSelect || !dom.containerAlignItemsSelect || !dom.containerJustifyContentSelect
    ) return;

    const controlType = control.dataset.controlType || control.tagName.toLowerCase();
    const computedStyle = getComputedStyle(control);

    dom.droppedControlVisibleInput.checked = computedStyle.display !== 'none';

    if (control.tagName === 'INPUT' || control.tagName === 'TEXTAREA') {
        dom.droppedControlTextContentInput.value = (control as HTMLInputElement | HTMLTextAreaElement).value;
        dom.droppedControlPlaceholderInput.value = (control as HTMLInputElement | HTMLTextAreaElement).placeholder;
    } else {
        dom.droppedControlTextContentInput.value = control.textContent || '';
    }

    if (control.tagName === 'IMG') {
        dom.droppedControlImageSrcInput.value = (control as HTMLImageElement).src;
    } else if (controlType === 'image-element') {
        const bgImage = computedStyle.backgroundImage;
        if (bgImage && bgImage !== 'none') {
            const urlMatch = bgImage.match(/url\("?([^"]+)"?\)/);
            dom.droppedControlImageSrcInput.value = urlMatch ? urlMatch[1] : '';
        } else {
            dom.droppedControlImageSrcInput.value = '';
        }
    }


    dom.droppedControlWidthInput.value = control.style.width || '';
    dom.droppedControlHeightInput.value = control.style.height || '';
    
    const bgColorParsed = splitColorToHexAndAlpha(computedStyle.backgroundColor);
    dom.droppedControlBgColorInput.value = bgColorParsed.hexRGB;
    dom.droppedControlBgColorAlphaSlider.value = bgColorParsed.alpha.toString();
    if(dom.droppedControlBgColorAlphaValueDisplay) dom.droppedControlBgColorAlphaValueDisplay.textContent = bgColorParsed.alpha.toFixed(2);

    const textColorParsed = splitColorToHexAndAlpha(computedStyle.color);
    dom.droppedControlTextColorInput.value = textColorParsed.hexRGB;
    dom.droppedControlTextColorAlphaSlider.value = textColorParsed.alpha.toString();
    if(dom.droppedControlTextColorAlphaValueDisplay) dom.droppedControlTextColorAlphaValueDisplay.textContent = textColorParsed.alpha.toFixed(2);
    
    dom.droppedControlOpacityInput.value = computedStyle.opacity;
    if(dom.droppedControlOpacityValueDisplay) dom.droppedControlOpacityValueDisplay.textContent = parseFloat(computedStyle.opacity).toFixed(2);
    
    dom.droppedControlBorderRadiusInput.value = parseFloat(computedStyle.borderRadius).toString() || '0';
    dom.droppedControlBorderWidthInput.value = parseFloat(computedStyle.borderWidth).toString() || '0';
    dom.droppedControlBorderStyleSelect.value = computedStyle.borderStyle;

    const borderColorParsed = splitColorToHexAndAlpha(computedStyle.borderColor);
    dom.droppedControlBorderColorInput.value = borderColorParsed.hexRGB;
    dom.droppedControlBorderColorAlphaSlider.value = borderColorParsed.alpha.toString();
    if(dom.droppedControlBorderColorAlphaValueDisplay) dom.droppedControlBorderColorAlphaValueDisplay.textContent = borderColorParsed.alpha.toFixed(2);

    const boxShadow = computedStyle.boxShadow;
    if (boxShadow && boxShadow !== 'none') {
        // More robust parsing needed here if non-RGB/Hex colors are used in boxShadow
        const parts = boxShadow.match(/rgba?\(.+\)|#[0-9a-fA-F]+|\S+/g) || [];
        // Assuming format: color offsetX offsetY blurRadius (spreadRadius is optional)
        // Simplistic parsing:
        const colorPart = parts.find(p => p.startsWith('rgb') || p.startsWith('#'));
        const numericParts = parts.filter(p => p.endsWith('px')).map(p => parseFloat(p));
        
        dom.droppedControlBoxShadowColorInput.value = colorPart ? splitColorToHexAndAlpha(colorPart).hexRGB : '#000000';
        dom.droppedControlBoxShadowColorAlphaSlider.value = colorPart ? splitColorToHexAndAlpha(colorPart).alpha.toString() : '1';
        if(dom.droppedControlBoxShadowColorAlphaValueDisplay) dom.droppedControlBoxShadowColorAlphaValueDisplay.textContent = colorPart ? splitColorToHexAndAlpha(colorPart).alpha.toFixed(2) : '1.00';

        dom.droppedControlBoxShadowXInput.value = (numericParts[0] || 0).toString();
        dom.droppedControlBoxShadowYInput.value = (numericParts[1] || 0).toString();
        dom.droppedControlBoxShadowBlurInput.value = (numericParts[2] || 0).toString();
    } else {
        dom.droppedControlBoxShadowColorInput.value = '#000000';
        dom.droppedControlBoxShadowColorAlphaSlider.value = '1';
        if(dom.droppedControlBoxShadowColorAlphaValueDisplay) dom.droppedControlBoxShadowColorAlphaValueDisplay.textContent = '1.00';
        dom.droppedControlBoxShadowXInput.value = '0';
        dom.droppedControlBoxShadowYInput.value = '0';
        dom.droppedControlBoxShadowBlurInput.value = '0';
    }


    // Typography
    dom.droppedControlFontFamilyInput.value = computedStyle.fontFamily.split(',')[0].replace(/"/g, '').trim() || 'sans-serif';
    dom.droppedControlFontSizeInput.value = computedStyle.fontSize || '16px';
    dom.droppedControlFontWeightSelect.value = computedStyle.fontWeight;
    dom.droppedControlFontStyleSelect.value = computedStyle.fontStyle as FontStyleType;
    dom.droppedControlLineHeightInput.value = computedStyle.lineHeight;
    dom.droppedControlLetterSpacingInput.value = computedStyle.letterSpacing;
    dom.droppedControlTextTransformSelect.value = computedStyle.textTransform as TextTransformType;
    dom.droppedControlTextDecorationSelect.value = computedStyle.textDecorationLine as TextDecorationType; // textDecorationLine is more specific

    const textShadow = computedStyle.textShadow;
     if (textShadow && textShadow !== 'none') {
        const parts = textShadow.match(/rgba?\(.+\)|#[0-9a-fA-F]+|\S+/g) || [];
        const colorPart = parts.find(p => p.startsWith('rgb') || p.startsWith('#'));
        const numericParts = parts.filter(p => p.endsWith('px')).map(p => parseFloat(p));

        dom.droppedControlTextShadowColorInput.value = colorPart ? splitColorToHexAndAlpha(colorPart).hexRGB : '#000000';
        dom.droppedControlTextShadowColorAlphaSlider.value = colorPart ? splitColorToHexAndAlpha(colorPart).alpha.toString() : '1';
        if(dom.droppedControlTextShadowColorAlphaValueDisplay) dom.droppedControlTextShadowColorAlphaValueDisplay.textContent = colorPart ? splitColorToHexAndAlpha(colorPart).alpha.toFixed(2) : '1.00';
        dom.droppedControlTextShadowXInput.value = (numericParts[0] || 0).toString();
        dom.droppedControlTextShadowYInput.value = (numericParts[1] || 0).toString();
        dom.droppedControlTextShadowBlurInput.value = (numericParts[2] || 0).toString();
    } else {
        dom.droppedControlTextShadowColorInput.value = '#000000';
        dom.droppedControlTextShadowColorAlphaSlider.value = '1';
        if(dom.droppedControlTextShadowColorAlphaValueDisplay) dom.droppedControlTextShadowColorAlphaValueDisplay.textContent = '1.00';
        dom.droppedControlTextShadowXInput.value = '0';
        dom.droppedControlTextShadowYInput.value = '0';
        dom.droppedControlTextShadowBlurInput.value = '0';
    }
    
    // Alignment
    if (['button', 'text-block', 'text-input'].includes(controlType)) {
        dom.textAlignHorizontalSelect.value = computedStyle.textAlign as TextAlignmentHorizontal;
        if (controlType !== 'text-input') { // Vertical alignment typically for block/flex items
            control.style.display = 'flex'; // Ensure flex for vertical alignment
            control.style.alignItems = computedStyle.alignItems as FlexAlignItems; 
            // For buttons, also set justify-content if you want text centered horizontally within the button via flex
            if(controlType === 'button') control.style.justifyContent = 'center';
        }
    }
    if (['row-container', 'column-container'].includes(controlType)) {
        dom.containerAlignItemsSelect.value = computedStyle.alignItems as FlexAlignItems;
        dom.containerJustifyContentSelect.value = computedStyle.justifyContent as FlexJustifyContent;
    }
}


export function updateTextColorsComponentInputs(controlElement: HTMLElement) {
    if (!dom.textColorsContentInput || !dom.textColorsColor1Picker || !dom.textColorsColor1AlphaSlider || !dom.textColorsColor1AlphaValueDisplay ||
        !dom.textColorsColor2Picker || !dom.textColorsColor2AlphaSlider || !dom.textColorsColor2AlphaValueDisplay ||
        !dom.textColorsGradientModeSelect || !dom.textColorsColor1FillSlider || !dom.textColorsColor1FillValue ||
        !dom.textColorsGradientAngleSlider || !dom.textColorsGradientAngleValue || !dom.textColorsColor2StartSlider || !dom.textColorsColor2StartValue ||
        !dom.textColorsFontFamilySelect || !dom.textColorsFontSizeInput || !dom.textColorsFontWeightSelect || !dom.textColorsFontStyleSelect ||
        !dom.textColorsDecorationUnderline || !dom.textColorsDecorationOverline || !dom.textColorsDecorationLinethrough ||
        !dom.textColorsTextTransformSelect || !dom.textColorsLineHeightInput || !dom.textColorsLetterSpacingInput || !dom.textColorsWordSpacingInput ||
        !dom.textColorsTextAlignSelect || !dom.textColorsFontVariantSelect
    ) return;

    dom.textColorsContentInput.value = controlElement.dataset.textContent || DEFAULT_TEXTCOLORS_TEXT_CONTENT;
    
    const color1Hex = controlElement.dataset.color1 || DEFAULT_TEXTCOLORS_COLOR1;
    const color1Alpha = parseFloat(controlElement.dataset.color1Alpha || "1");
    dom.textColorsColor1Picker.value = color1Hex;
    dom.textColorsColor1AlphaSlider.value = color1Alpha.toString();
    dom.textColorsColor1AlphaValueDisplay.textContent = color1Alpha.toFixed(2);

    const color2Hex = controlElement.dataset.color2 || DEFAULT_TEXTCOLORS_COLOR2;
    const color2Alpha = parseFloat(controlElement.dataset.color2Alpha || "1");
    dom.textColorsColor2Picker.value = color2Hex;
    dom.textColorsColor2AlphaSlider.value = color2Alpha.toString();
    dom.textColorsColor2AlphaValueDisplay.textContent = color2Alpha.toFixed(2);

    dom.textColorsGradientModeSelect.value = (controlElement.dataset.gradientMode || DEFAULT_TEXTCOLORS_GRADIENT_MODE) as TextColorAdvancedGradientMode;
    
    const color1Fill = controlElement.dataset.color1Fill || DEFAULT_TEXTCOLORS_COLOR1_FILL;
    dom.textColorsColor1FillSlider.value = color1Fill;
    if(dom.textColorsColor1FillValue) dom.textColorsColor1FillValue.textContent = `${color1Fill}%`;

    const gradientAngle = controlElement.dataset.gradientAngle || DEFAULT_TEXTCOLORS_GRADIENT_ANGLE;
    dom.textColorsGradientAngleSlider.value = gradientAngle;
    if(dom.textColorsGradientAngleValue) dom.textColorsGradientAngleValue.textContent = `${gradientAngle}°`;
    
    const color2Start = controlElement.dataset.color2Start || DEFAULT_TEXTCOLORS_COLOR2_START;
    dom.textColorsColor2StartSlider.value = color2Start;
    if(dom.textColorsColor2StartValue) dom.textColorsColor2StartValue.textContent = `${color2Start}%`;

    dom.textColorsFontFamilySelect.value = controlElement.dataset.fontFamily || DEFAULT_TEXTCOLORS_FONT_FAMILY;
    dom.textColorsFontSizeInput.value = controlElement.dataset.fontSize || DEFAULT_TEXTCOLORS_FONT_SIZE;
    dom.textColorsFontWeightSelect.value = controlElement.dataset.fontWeight || DEFAULT_TEXTCOLORS_FONT_WEIGHT;
    dom.textColorsFontStyleSelect.value = controlElement.dataset.fontStyle || DEFAULT_TEXTCOLORS_FONT_STYLE;
    
    dom.textColorsDecorationUnderline.checked = (controlElement.dataset.decorationUnderline || DEFAULT_TEXTCOLORS_DECORATION_UNDERLINE.toString()) === 'true';
    dom.textColorsDecorationOverline.checked = (controlElement.dataset.decorationOverline || DEFAULT_TEXTCOLORS_DECORATION_OVERLINE.toString()) === 'true';
    dom.textColorsDecorationLinethrough.checked = (controlElement.dataset.decorationLinethrough || DEFAULT_TEXTCOLORS_DECORATION_LINETHROUGH.toString()) === 'true';
    
    dom.textColorsTextTransformSelect.value = controlElement.dataset.textTransform || DEFAULT_TEXTCOLORS_TEXT_TRANSFORM;
    dom.textColorsLineHeightInput.value = controlElement.dataset.lineHeight || DEFAULT_TEXTCOLORS_LINE_HEIGHT;
    dom.textColorsLetterSpacingInput.value = controlElement.dataset.letterSpacing || DEFAULT_TEXTCOLORS_LETTER_SPACING;
    dom.textColorsWordSpacingInput.value = controlElement.dataset.wordSpacing || DEFAULT_TEXTCOLORS_WORD_SPACING;
    dom.textColorsTextAlignSelect.value = controlElement.dataset.textAlign || DEFAULT_TEXTCOLORS_TEXT_ALIGN;
    dom.textColorsFontVariantSelect.value = controlElement.dataset.fontVariant || DEFAULT_TEXTCOLORS_FONT_VARIANT;
}

export function updateAnsiArtViewerInputs(controlElement: HTMLElement) {
    if (!dom.ansiArtVisibleInput || !dom.ansiArtContentInput || !dom.ansiArtWidthInput || !dom.ansiArtHeightInput ||
        !dom.ansiArtBgColorInput || !dom.ansiArtBgColorAlphaSlider || !dom.ansiArtBgColorAlphaValueDisplay ||
        !dom.ansiArtTextColorInput || !dom.ansiArtTextColorAlphaSlider || !dom.ansiArtTextColorAlphaValueDisplay ||
        !dom.ansiArtOpacityInput || !dom.ansiArtOpacityValueDisplay ||
        !dom.ansiArtBorderRadiusInput || !dom.ansiArtBorderWidthInput || !dom.ansiArtBorderStyleSelect || 
        !dom.ansiArtBorderColorInput || !dom.ansiArtBorderColorAlphaSlider || !dom.ansiArtBorderColorAlphaValueDisplay ||
        !dom.ansiArtBoxShadowXInput || !dom.ansiArtBoxShadowYInput || !dom.ansiArtBoxShadowBlurInput || 
        !dom.ansiArtBoxShadowColorInput || !dom.ansiArtBoxShadowColorAlphaSlider || !dom.ansiArtBoxShadowColorAlphaValueDisplay
    ) return;

    const computedStyle = getComputedStyle(controlElement);
    const contentWrapper = controlElement.querySelector('.ansi-art-content-wrapper') as HTMLElement;
    const contentWrapperStyle = contentWrapper ? getComputedStyle(contentWrapper) : null;

    dom.ansiArtVisibleInput.checked = computedStyle.display !== 'none';
    dom.ansiArtContentInput.value = controlElement.dataset.ansiContent || '';
    dom.ansiArtWidthInput.value = controlElement.style.width || '100%';
    dom.ansiArtHeightInput.value = controlElement.style.height || 'auto';
    
    dom.ansiArtOpacityInput.value = computedStyle.opacity;
    if(dom.ansiArtOpacityValueDisplay) dom.ansiArtOpacityValueDisplay.textContent = parseFloat(computedStyle.opacity).toFixed(2);

    if (contentWrapperStyle) {
        const bgColorParsed = splitColorToHexAndAlpha(contentWrapperStyle.backgroundColor);
        dom.ansiArtBgColorInput.value = bgColorParsed.hexRGB;
        dom.ansiArtBgColorAlphaSlider.value = bgColorParsed.alpha.toString();
        if(dom.ansiArtBgColorAlphaValueDisplay) dom.ansiArtBgColorAlphaValueDisplay.textContent = bgColorParsed.alpha.toFixed(2);

        const textColorParsed = splitColorToHexAndAlpha(contentWrapperStyle.color);
        dom.ansiArtTextColorInput.value = textColorParsed.hexRGB;
        dom.ansiArtTextColorAlphaSlider.value = textColorParsed.alpha.toString();
        if(dom.ansiArtTextColorAlphaValueDisplay) dom.ansiArtTextColorAlphaValueDisplay.textContent = textColorParsed.alpha.toFixed(2);
    } else { // Fallback if contentWrapper not found (should not happen)
        dom.ansiArtBgColorInput.value = '#000000';
        dom.ansiArtBgColorAlphaSlider.value = '1';
        if(dom.ansiArtBgColorAlphaValueDisplay) dom.ansiArtBgColorAlphaValueDisplay.textContent = '1.00';
        dom.ansiArtTextColorInput.value = '#FFFFFF';
        dom.ansiArtTextColorAlphaSlider.value = '1';
        if(dom.ansiArtTextColorAlphaValueDisplay) dom.ansiArtTextColorAlphaValueDisplay.textContent = '1.00';
    }
    
    dom.ansiArtBorderRadiusInput.value = parseFloat(computedStyle.borderRadius).toString() || '0';
    dom.ansiArtBorderWidthInput.value = parseFloat(computedStyle.borderWidth).toString() || '0';
    dom.ansiArtBorderStyleSelect.value = computedStyle.borderStyle;

    const borderColorParsed = splitColorToHexAndAlpha(computedStyle.borderColor);
    dom.ansiArtBorderColorInput.value = borderColorParsed.hexRGB;
    dom.ansiArtBorderColorAlphaSlider.value = borderColorParsed.alpha.toString();
    if(dom.ansiArtBorderColorAlphaValueDisplay) dom.ansiArtBorderColorAlphaValueDisplay.textContent = borderColorParsed.alpha.toFixed(2);

    const boxShadow = computedStyle.boxShadow;
    if (boxShadow && boxShadow !== 'none') {
        const parts = boxShadow.match(/rgba?\(.+\)|#[0-9a-fA-F]+|\S+/g) || [];
        const colorPart = parts.find(p => p.startsWith('rgb') || p.startsWith('#'));
        const numericParts = parts.filter(p => p.endsWith('px')).map(p => parseFloat(p));
        
        const shadowColorParsed = colorPart ? splitColorToHexAndAlpha(colorPart) : { hexRGB: '#000000', alpha: 0 };
        dom.ansiArtBoxShadowColorInput.value = shadowColorParsed.hexRGB;
        dom.ansiArtBoxShadowColorAlphaSlider.value = shadowColorParsed.alpha.toString();
        if(dom.ansiArtBoxShadowColorAlphaValueDisplay) dom.ansiArtBoxShadowColorAlphaValueDisplay.textContent = shadowColorParsed.alpha.toFixed(2);

        dom.ansiArtBoxShadowXInput.value = (numericParts[0] || 0).toString();
        dom.ansiArtBoxShadowYInput.value = (numericParts[1] || 0).toString();
        dom.ansiArtBoxShadowBlurInput.value = (numericParts[2] || 0).toString();
    } else {
        dom.ansiArtBoxShadowColorInput.value = '#000000';
        dom.ansiArtBoxShadowColorAlphaSlider.value = '0'; // Default to transparent shadow if none
        if(dom.ansiArtBoxShadowColorAlphaValueDisplay) dom.ansiArtBoxShadowColorAlphaValueDisplay.textContent = '0.00';
        dom.ansiArtBoxShadowXInput.value = '0';
        dom.ansiArtBoxShadowYInput.value = '0';
        dom.ansiArtBoxShadowBlurInput.value = '0';
    }
}

export function updateHtmlControlInputs(controlElement: HTMLElement) {
    if (!dom.htmlControlHtmlContentInput || !dom.htmlControlCssContentInput || !dom.htmlControlJsContentInput) return;

    dom.htmlControlHtmlContentInput.value = controlElement.dataset.htmlContent || DEFAULT_HTML_CONTENT;
    dom.htmlControlCssContentInput.value = controlElement.dataset.cssContent || DEFAULT_CSS_CONTENT;
    dom.htmlControlJsContentInput.value = controlElement.dataset.jsContent || DEFAULT_JS_CONTENT;
}