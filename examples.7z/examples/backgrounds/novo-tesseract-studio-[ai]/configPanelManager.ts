

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from './domElements';
import * as state from './state';
import type { TabId } from './types';

const TAB_NAV_WIDTH_PX = 64; // w-16
const MIN_TAB_CONTENT_WIDTH_PX = 200; // Minimum width for the tab content area
const MIN_PANEL_HEIGHT_PX = 120; // Minimum height for the panel (header + some space)


export function toggleConfigPanel(show?: boolean) {
    console.log('[Tesseract Studio] toggleConfigPanel called. show:', show);
    if (!dom.configPanel) {
        console.error('[Tesseract Studio] Config panel DOM element (dom.configPanel) not found in toggleConfigPanel!');
        return;
    }
    const isCurrentlyHidden = dom.configPanel.classList.contains('hidden');
    console.log('[Tesseract Studio] Panel isCurrentlyHidden:', isCurrentlyHidden);

    if (typeof show === 'boolean') {
        if (show) {
            console.log('[Tesseract Studio] Explicitly showing panel (removing "hidden" class).');
            dom.configPanel.classList.remove('hidden');
        } else {
            console.log('[Tesseract Studio] Explicitly hiding panel (adding "hidden" class).');
            dom.configPanel.classList.add('hidden');
        }
    } else {
        // Standard toggle behavior
        if (isCurrentlyHidden) {
            console.log('[Tesseract Studio] Toggling to show panel (removing "hidden" class).');
            dom.configPanel.classList.remove('hidden');
        } else {
            console.log('[Tesseract Studio] Toggling to hide panel (adding "hidden" class).');
            dom.configPanel.classList.add('hidden');
        }
    }
    console.log('[Tesseract Studio] Panel "hidden" class after toggle:', dom.configPanel.classList.contains('hidden'));
}

export function toggleCollapsePanel() {
    if (!dom.configPanel || !dom.configPanelBody || !dom.configPanelCollapseButton || !dom.configPanelResizeHandle) return;
    
    const isCollapsing = !dom.configPanel.classList.contains('collapsed');
    dom.configPanel.classList.toggle('collapsed');
    
    const tabNav = dom.configPanel.querySelector('nav[aria-label="Tabs"]');
    const tabContentArea = dom.tabContentAreaContainer; // Use the specific DOM element
    
    if (tabNav) (tabNav as HTMLElement).classList.toggle('hidden', isCollapsing);
    if (tabContentArea) (tabContentArea as HTMLElement).classList.toggle('hidden', isCollapsing);
    dom.configPanelResizeHandle.classList.toggle('hidden', isCollapsing);


    const expandIcon = dom.configPanelCollapseButton.querySelector('.panel-icon-expand');
    const collapseIcon = dom.configPanelCollapseButton.querySelector('.panel-icon-collapse');
    
    if (expandIcon) expandIcon.classList.toggle('hidden', !isCollapsing); 
    if (collapseIcon) collapseIcon.classList.toggle('hidden', isCollapsing);
}

export function dragMouseDown(e: MouseEvent) {
    if (!dom.configPanel || !(e.target as HTMLElement).closest('#config-panel-header')) return;
    state.setIsDragging(true);
    dom.configPanel.style.transition = 'none'; 
    state.setDragOffset(e.clientX - dom.configPanel.offsetLeft, e.clientY - dom.configPanel.offsetTop);
    document.addEventListener('mousemove', dragMouseMove);
    document.addEventListener('mouseup', dragMouseUp);
}

export function dragMouseMove(e: MouseEvent) {
    if (!state.isDragging || !dom.configPanel) return;
    e.preventDefault(); 
    let newLeft = e.clientX - state.dragOffsetX;
    let newTop = e.clientY - state.dragOffsetY;

    const panelWidth = dom.configPanel.offsetWidth;
    const panelHeight = dom.configPanel.offsetHeight;
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    newLeft = Math.max(0, Math.min(newLeft, viewportWidth - panelWidth));
    newTop = Math.max(0, Math.min(newTop, viewportHeight - panelHeight));
    
    dom.configPanel.style.left = newLeft + 'px';
    dom.configPanel.style.top = newTop + 'px';
}

export function dragMouseUp() {
    if (!state.isDragging || !dom.configPanel) return;
    state.setIsDragging(false);
    if (dom.configPanel) dom.configPanel.style.transition = ''; 
    document.removeEventListener('mousemove', dragMouseMove);
    document.removeEventListener('mouseup', dragMouseUp);
}


export function panelResizeMouseDown(e: MouseEvent) {
    if (!dom.configPanel || !dom.tabContentAreaContainer) return;
    e.preventDefault();
    state.setIsResizingPanel(true);
    dom.configPanel.style.transition = 'none'; 

    // Use state values as the source of truth for current dimensions
    // as offsetWidth/Height might not be immediately reflective of
    // dimensions set via CSS variables or after state changes, preventing size "jumps".
    const currentContentWidth = state.configPanelTabContentWidth;
    const currentPanelHeight = state.configPanelHeight;

    state.setPanelResizeInitialCoords({
        mouseX: e.clientX,
        mouseY: e.clientY,
        initialContentWidth: currentContentWidth,
        initialPanelHeight: currentPanelHeight
    });
    document.addEventListener('mousemove', panelResizeMouseMove);
    document.addEventListener('mouseup', panelResizeMouseUp);
}

export function panelResizeMouseMove(e: MouseEvent) {
    if (!state.isResizingPanel || !state.panelResizeInitialCoords || !dom.configPanel) return;
    e.preventDefault();

    const dx = e.clientX - state.panelResizeInitialCoords.mouseX;
    const dy = e.clientY - state.panelResizeInitialCoords.mouseY;

    let newContentWidth = state.panelResizeInitialCoords.initialContentWidth + dx;
    let newPanelHeight = state.panelResizeInitialCoords.initialPanelHeight + dy;

    newContentWidth = Math.max(MIN_TAB_CONTENT_WIDTH_PX, newContentWidth);
    // Max width: ensure panel doesn't exceed viewport width minus some margin
    const maxPanelWidth = window.innerWidth - (dom.configPanel.offsetLeft || 0) - 20; // 20px margin
    const maxContentWidth = maxPanelWidth - TAB_NAV_WIDTH_PX; // Approximation
    newContentWidth = Math.min(newContentWidth, maxContentWidth > MIN_TAB_CONTENT_WIDTH_PX ? maxContentWidth : MIN_TAB_CONTENT_WIDTH_PX);


    newPanelHeight = Math.max(MIN_PANEL_HEIGHT_PX, newPanelHeight);
    // Max height: ensure panel doesn't exceed viewport height minus some margin
    const maxPanelHeight = window.innerHeight - (dom.configPanel.offsetTop || 0) - 20; // 20px margin
    newPanelHeight = Math.min(newPanelHeight, maxPanelHeight > MIN_PANEL_HEIGHT_PX ? maxPanelHeight : MIN_PANEL_HEIGHT_PX);


    state.setConfigPanelTabContentWidth(newContentWidth);
    state.setConfigPanelHeight(newPanelHeight);
    
    dom.configPanel.style.setProperty('--config-panel-tab-content-width', `${newContentWidth}px`);
    dom.configPanel.style.height = `${newPanelHeight}px`;
}

export function panelResizeMouseUp() {
    if (!state.isResizingPanel || !dom.configPanel) return;
    state.setIsResizingPanel(false);
    state.setPanelResizeInitialCoords(null);
    if (dom.configPanel) dom.configPanel.style.transition = '';
    document.removeEventListener('mousemove', panelResizeMouseMove);
    document.removeEventListener('mouseup', panelResizeMouseUp);
}


export function switchTab(tabId: TabId) {
    state.setActiveTabId(tabId);
    const tabButtons = [dom.tabButtonGlobals, dom.tabButtonElement, dom.tabButtonControls, dom.tabButtonAnimations, dom.tabButtonPresets, dom.tabButtonAi];
    const tabContents = [dom.tabContentGlobals, dom.tabContentElement, dom.tabContentControls, dom.tabContentAnimations, dom.tabContentPresets, dom.tabContentAi];
    const tabIds: TabId[] = ['globals', 'element', 'controls', 'animations', 'presets', 'ai'];

    tabButtons.forEach((button, index) => {
        if (button) {
            button.classList.toggle('active-tab', tabIds[index] === tabId);
        }
    });

    tabContents.forEach((content, index) => {
        if (content) {
            content.classList.toggle('hidden', tabIds[index] !== tabId);
        }
    });
}

export function setupConfigPanelInteractionListeners() {
    if (dom.configPanelToggleButton) {
        dom.configPanelToggleButton.addEventListener('click', () => {
            console.log('[Tesseract Studio] Config panel toggle button clicked!');
            toggleConfigPanel();
        });
    } else {
        console.error('[Tesseract Studio] Config panel toggle button (dom.configPanelToggleButton) not found during listener setup!');
    }
    if (dom.configPanelCloseButton) {
        dom.configPanelCloseButton.addEventListener('click', () => toggleConfigPanel(false));
    }
    if (dom.configPanelCollapseButton && dom.configPanel && dom.configPanelResizeHandle) {
        const isCollapsed = dom.configPanel.classList.contains('collapsed');
        const expandIcon = dom.configPanelCollapseButton.querySelector('.panel-icon-expand');
        const collapseIcon = dom.configPanelCollapseButton.querySelector('.panel-icon-collapse');
        if(expandIcon) expandIcon.classList.toggle('hidden', !isCollapsed);
        if(collapseIcon) collapseIcon.classList.toggle('hidden', isCollapsed);
        dom.configPanelCollapseButton.addEventListener('click', toggleCollapsePanel);
        dom.configPanelResizeHandle.classList.toggle('hidden', isCollapsed); // Show/hide resize handle
    }
    if (dom.configPanelHeader) {
        dom.configPanelHeader.addEventListener('mousedown', dragMouseDown);
    }
    if (dom.configPanelResizeHandle) {
        dom.configPanelResizeHandle.addEventListener('mousedown', panelResizeMouseDown);
    }


    if (dom.tabButtonGlobals) dom.tabButtonGlobals.addEventListener('click', () => switchTab('globals'));
    if (dom.tabButtonElement) dom.tabButtonElement.addEventListener('click', () => switchTab('element'));
    if (dom.tabButtonControls) dom.tabButtonControls.addEventListener('click', () => switchTab('controls'));
    if (dom.tabButtonAnimations) dom.tabButtonAnimations.addEventListener('click', () => switchTab('animations'));
    // if (dom.tabButtonComponents) dom.tabButtonComponents.addEventListener('click', () => switchTab('components')); // Removed
    if (dom.tabButtonPresets) dom.tabButtonPresets.addEventListener('click', () => switchTab('presets'));
    if (dom.tabButtonAi) dom.tabButtonAi.addEventListener('click', () => switchTab('ai')); // New

    // Initial tab state if needed, or rely on default activeTabId from state.ts
    // switchTab(state.activeTabId); 

    // Set initial panel dimensions from state
    if (dom.configPanel) {
        dom.configPanel.style.setProperty('--config-panel-tab-content-width', `${state.configPanelTabContentWidth}px`);
        dom.configPanel.style.height = `${state.configPanelHeight}px`;
    }
}