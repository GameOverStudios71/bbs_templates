
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from './domElements';
import * as state from './state';
import { deleteSelectedControl } from './droppedControlController';

const DEFAULT_HTML_CONTENT = '<!-- HTML goes here -->\n<div style="padding:10px;">\n  <h2>Hello from Custom HTML!</h2>\n  <p>You can edit this content.</p>\n  <button onclick="alert(\'Button clicked!\')">Click Me</button>\n</div>';
const DEFAULT_CSS_CONTENT = '/* CSS goes here */\nbody {\n  background-color: #f0f0f0;\n  color: #333;\n  font-family: Arial, sans-serif;\n}\nh2 { color: navy; }';
const DEFAULT_JS_CONTENT = '// JavaScript goes here\n// console.log("Custom JS loaded!");\n\nfunction_call_does_not_exist_testing_error();';


export function applyCustomHtmlCode(controlElement: HTMLElement) {
    const iframe = controlElement.querySelector('.html-control-render-iframe') as HTMLIFrameElement;
    if (!iframe || !iframe.contentWindow || !iframe.contentWindow.document) {
        console.warn('HTML Control iframe not found or not ready.');
        return;
    }

    const htmlContent = controlElement.dataset.htmlContent || '';
    const cssContent = controlElement.dataset.cssContent || '';
    const jsContent = controlElement.dataset.jsContent || '';

    const doc = iframe.contentWindow.document;
    doc.open();
    doc.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                /* Basic reset/defaults for iframe */
                body { margin: 0; padding: 0; box-sizing: border-box; }
                ${cssContent}
            </style>
        </head>
        <body>
            ${htmlContent}
            <script>
                (function() {
                    try {
                        ${jsContent}
                    } catch (e) {
                        console.error('Error in custom HTML Control JavaScript:', e);
                        const errorDisplay = document.createElement('div');
                        errorDisplay.style.position = 'absolute';
                        errorDisplay.style.bottom = '5px';
                        errorDisplay.style.left = '5px';
                        errorDisplay.style.right = '5px';
                        errorDisplay.style.padding = '5px';
                        errorDisplay.style.background = 'rgba(255,0,0,0.8)';
                        errorDisplay.style.color = 'white';
                        errorDisplay.style.fontSize = '12px';
                        errorDisplay.style.fontFamily = 'monospace';
                        errorDisplay.style.whiteSpace = 'pre-wrap';
                        errorDisplay.style.zIndex = '9999';
                        errorDisplay.textContent = 'JS Error: ' + e.name + ' - ' + e.message;
                        if (document.body) {
                           document.body.appendChild(errorDisplay);
                        } else {
                           // Fallback if body isn't ready, though it should be
                           setTimeout(() => { if(document.body) document.body.appendChild(errorDisplay); }, 0);
                        }
                    }
                })();
            <\/script>
        </body>
        </html>
    `);
    doc.close();
}


export function setupHtmlControlPanelListeners() {
    if (!dom.applyHtmlControlCodeBtn || !dom.deleteHtmlControlBtn || 
        !dom.htmlControlHtmlContentInput || !dom.htmlControlCssContentInput || !dom.htmlControlJsContentInput) {
        console.warn("HTML Control panel elements not found. Listeners not set up.");
        return;
    }

    dom.applyHtmlControlCodeBtn.addEventListener('click', () => {
        if (state.selectedDroppedControl && state.selectedDroppedControl.dataset.controlType === 'html-control') {
            if (dom.htmlControlHtmlContentInput) state.selectedDroppedControl.dataset.htmlContent = dom.htmlControlHtmlContentInput.value;
            if (dom.htmlControlCssContentInput) state.selectedDroppedControl.dataset.cssContent = dom.htmlControlCssContentInput.value;
            if (dom.htmlControlJsContentInput) state.selectedDroppedControl.dataset.jsContent = dom.htmlControlJsContentInput.value;
            applyCustomHtmlCode(state.selectedDroppedControl);
        }
    });

    dom.deleteHtmlControlBtn.addEventListener('click', deleteSelectedControl);
}

// Helper to get default content for new HTML controls
export { DEFAULT_HTML_CONTENT, DEFAULT_CSS_CONTENT, DEFAULT_JS_CONTENT };
