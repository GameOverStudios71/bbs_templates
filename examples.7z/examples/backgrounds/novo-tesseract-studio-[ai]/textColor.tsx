/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Gradient controls
let textareaElement: HTMLTextAreaElement;
let displayDivElement: HTMLDivElement;
let colorPicker1Element: HTMLInputElement;
let colorPicker2Element: HTMLInputElement;
let modeSelectElement: HTMLSelectElement;
let color1FillSliderElement: HTMLInputElement;
let color1FillValueElement: HTMLSpanElement;
let gradientAngleSliderElement: HTMLInputElement;
let gradientAngleValueElement: HTMLSpanElement;
let color2StartSliderElement: HTMLInputElement;
let color2StartValueElement: HTMLSpanElement;

// Font controls
let fontFamilySelectElement: HTMLSelectElement;
let fontSizeInputElement: HTMLInputElement;
let fontWeightSelectElement: HTMLSelectElement;
let fontStyleSelectElement: HTMLSelectElement;
let textDecorationUnderlineCheckbox: HTMLInputElement;
let textDecorationOverlineCheckbox: HTMLInputElement;
let textDecorationLinethroughCheckbox: HTMLInputElement;
let textTransformSelectElement: HTMLSelectElement;
let lineHeightInputElement: HTMLInputElement;
let letterSpacingInputElement: HTMLInputElement;
let wordSpacingInputElement: HTMLInputElement;
let textAlignSelectElement: HTMLSelectElement;
let fontVariantSelectElement: HTMLSelectElement;


/**
 * Escapes HTML special characters to prevent XSS.
 * @param unsafe The string to escape.
 * @returns The escaped string.
 */
function escapeHtml(unsafe: string): string {
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}

/**
 * Updates the display div with the text from the textarea,
 * applying all selected styles.
 */
function updateDisplay() {
    if (!textareaElement || !displayDivElement || !colorPicker1Element || !colorPicker2Element || 
        !modeSelectElement || !color1FillSliderElement || !gradientAngleSliderElement || !color2StartSliderElement ||
        !fontFamilySelectElement || !fontSizeInputElement || !fontWeightSelectElement || !fontStyleSelectElement ||
        !textDecorationUnderlineCheckbox || !textDecorationOverlineCheckbox || !textDecorationLinethroughCheckbox ||
        !textTransformSelectElement || !lineHeightInputElement || !letterSpacingInputElement || !wordSpacingInputElement ||
        !textAlignSelectElement || !fontVariantSelectElement
        ) {
        console.error("One or more UI elements are not found. Initialization might have failed.");
        return;
    }

    const text = textareaElement.value;
    const color1 = colorPicker1Element.value;
    const color2 = colorPicker2Element.value;
    const mode = modeSelectElement.value;
    const color1Stop = color1FillSliderElement.value;
    const angle = gradientAngleSliderElement.value;
    const color2Stop = color2StartSliderElement.value;

    // Font control values
    const fontFamily = fontFamilySelectElement.value;
    const fontSize = fontSizeInputElement.value;
    const fontWeight = fontWeightSelectElement.value;
    const fontStyle = fontStyleSelectElement.value;
    const textDecoration: string[] = [];
    if (textDecorationUnderlineCheckbox.checked) textDecoration.push('underline');
    if (textDecorationOverlineCheckbox.checked) textDecoration.push('overline');
    if (textDecorationLinethroughCheckbox.checked) textDecoration.push('line-through');
    const textTransform = textTransformSelectElement.value;
    const lineHeight = lineHeightInputElement.value;
    const letterSpacing = letterSpacingInputElement.value;
    const wordSpacing = wordSpacingInputElement.value;
    const textAlign = textAlignSelectElement.value;
    const fontVariant = fontVariantSelectElement.value;

    let DANGEROUS_generatedHtml = '';

    // Apply styles to the container div that affect block layout
    displayDivElement.style.textAlign = textAlign;
    displayDivElement.style.lineHeight = lineHeight; // Unitless line-height is fine
    // displayDivElement.style.fontFamily = fontFamily; // Apply to spans for gradient clipping
    // displayDivElement.style.fontSize = `${fontSize}px`; // Apply to spans

    if (text.length === 0) {
        displayDivElement.innerHTML = '';
        return;
    }
    
    // Styles applied to the spans for text-specific and gradient effects
    let fontSpecificStyles = `font-family: ${fontFamily}; font-size: ${fontSize}px; font-weight: ${fontWeight}; font-style: ${fontStyle}; text-decoration: ${textDecoration.join(' ') || 'none'}; text-transform: ${textTransform}; letter-spacing: ${letterSpacing}px; word-spacing: ${wordSpacing}px; font-variant: ${fontVariant};`;
    
    const gradientStyleBase = `background-image: linear-gradient(${angle}deg, ${color1} ${color1Stop}%, ${color2} ${color2Stop}%); color: transparent; -webkit-background-clip: text; background-clip: text;`;
    
    const combinedStyle = `${fontSpecificStyles} ${gradientStyleBase}`;

    const escapedText = escapeHtml(text);

    if (mode === 'word') {
        const parts = escapedText.split(/(\S+)/); 
        
        DANGEROUS_generatedHtml = parts.map(part => {
            if (part.match(/\S+/)) { 
                return `<span style="${combinedStyle} display: inline-block;">${part}</span>`;
            }
            return part.replace(/\n/g, '<br>'); // Preserve line breaks between words/spans
        }).join('');
    } else { // mode === 'phrase'
        // For phrase mode, apply font styles to the container span, line breaks handled by pre-wrap
        DANGEROUS_generatedHtml = `<span style="${combinedStyle}">${escapedText.replace(/\n/g, '<br>')}</span>`;
    }

    displayDivElement.innerHTML = DANGEROUS_generatedHtml;
}


/**
 * Initializes the application by getting references to DOM elements
 * and setting up event listeners.
 */
function init() {
    // Gradient controls
    textareaElement = document.getElementById('text-input') as HTMLTextAreaElement;
    displayDivElement = document.getElementById('text-display') as HTMLDivElement;
    colorPicker1Element = document.getElementById('color1') as HTMLInputElement;
    colorPicker2Element = document.getElementById('color2') as HTMLInputElement;
    modeSelectElement = document.getElementById('gradient-mode') as HTMLSelectElement;
    color1FillSliderElement = document.getElementById('color1-fill-slider') as HTMLInputElement;
    color1FillValueElement = document.getElementById('color1-fill-value') as HTMLSpanElement;
    gradientAngleSliderElement = document.getElementById('gradient-angle-slider') as HTMLInputElement;
    gradientAngleValueElement = document.getElementById('gradient-angle-value') as HTMLSpanElement;
    color2StartSliderElement = document.getElementById('color2-start-slider') as HTMLInputElement;
    color2StartValueElement = document.getElementById('color2-start-value') as HTMLSpanElement;

    // Font controls
    fontFamilySelectElement = document.getElementById('font-family-select') as HTMLSelectElement;
    fontSizeInputElement = document.getElementById('font-size-input') as HTMLInputElement;
    fontWeightSelectElement = document.getElementById('font-weight-select') as HTMLSelectElement;
    fontStyleSelectElement = document.getElementById('font-style-select') as HTMLSelectElement;
    textDecorationUnderlineCheckbox = document.getElementById('text-decoration-underline') as HTMLInputElement;
    textDecorationOverlineCheckbox = document.getElementById('text-decoration-overline') as HTMLInputElement;
    textDecorationLinethroughCheckbox = document.getElementById('text-decoration-linethrough') as HTMLInputElement;
    textTransformSelectElement = document.getElementById('text-transform-select') as HTMLSelectElement;
    lineHeightInputElement = document.getElementById('line-height-input') as HTMLInputElement;
    letterSpacingInputElement = document.getElementById('letter-spacing-input') as HTMLInputElement;
    wordSpacingInputElement = document.getElementById('word-spacing-input') as HTMLInputElement;
    textAlignSelectElement = document.getElementById('text-align-select') as HTMLSelectElement;
    fontVariantSelectElement = document.getElementById('font-variant-select') as HTMLSelectElement;

    const allElements = [
        textareaElement, displayDivElement, colorPicker1Element, colorPicker2Element, modeSelectElement,
        color1FillSliderElement, color1FillValueElement, gradientAngleSliderElement, gradientAngleValueElement,
        color2StartSliderElement, color2StartValueElement, fontFamilySelectElement, fontSizeInputElement,
        fontWeightSelectElement, fontStyleSelectElement, textDecorationUnderlineCheckbox, textDecorationOverlineCheckbox,
        textDecorationLinethroughCheckbox, textTransformSelectElement, lineHeightInputElement, letterSpacingInputElement,
        wordSpacingInputElement, textAlignSelectElement, fontVariantSelectElement
    ];

    if (allElements.every(el => el !== null)) {
        textareaElement.addEventListener('input', updateDisplay);
        colorPicker1Element.addEventListener('input', updateDisplay);
        colorPicker2Element.addEventListener('input', updateDisplay);
        modeSelectElement.addEventListener('change', updateDisplay);
        
        color1FillSliderElement.addEventListener('input', () => {
            color1FillValueElement.textContent = `${color1FillSliderElement.value}%`;
            updateDisplay();
        });
        color1FillValueElement.textContent = `${color1FillSliderElement.value}%`;

        gradientAngleSliderElement.addEventListener('input', () => {
            gradientAngleValueElement.textContent = `${gradientAngleSliderElement.value}°`;
            updateDisplay();
        });
        gradientAngleValueElement.textContent = `${gradientAngleSliderElement.value}°`;
        
        color2StartSliderElement.addEventListener('input', () => {
            color2StartValueElement.textContent = `${color2StartSliderElement.value}%`;
            updateDisplay();
        });
        color2StartValueElement.textContent = `${color2StartSliderElement.value}%`;

        // Font control listeners
        fontFamilySelectElement.addEventListener('change', updateDisplay);
        fontSizeInputElement.addEventListener('input', updateDisplay);
        fontWeightSelectElement.addEventListener('change', updateDisplay);
        fontStyleSelectElement.addEventListener('change', updateDisplay);
        textDecorationUnderlineCheckbox.addEventListener('change', updateDisplay);
        textDecorationOverlineCheckbox.addEventListener('change', updateDisplay);
        textDecorationLinethroughCheckbox.addEventListener('change', updateDisplay);
        textTransformSelectElement.addEventListener('change', updateDisplay);
        lineHeightInputElement.addEventListener('input', updateDisplay);
        letterSpacingInputElement.addEventListener('input', updateDisplay);
        wordSpacingInputElement.addEventListener('input', updateDisplay);
        textAlignSelectElement.addEventListener('change', updateDisplay);
        fontVariantSelectElement.addEventListener('change', updateDisplay);
        
        updateDisplay(); // Initial call to set everything up
    } else {
        console.error('Failed to initialize all UI elements. Please check element IDs in index.html.');
        const appContainer = document.getElementById('app-container');
        if (appContainer) {
            appContainer.innerHTML = '<p style="color: red; text-align: center;">Error: Could not initialize the application. Required elements are missing.</p>';
        }
    }
}

document.addEventListener('DOMContentLoaded', init);