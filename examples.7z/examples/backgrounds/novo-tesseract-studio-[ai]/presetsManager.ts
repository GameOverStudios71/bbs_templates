
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from './domElements';
import * as state from './state';
import { TESSERACT_PRESETS_KEY, ANIMATE_CSS_BASE_CLASS } from './constants';
import { generateUniqueId, getSafeFilename, updatePlaceholderVisibility, escapeHtml } from './utils';
import { selectElement, updatePanelForNoSelection } from './selectionManager';
import { updateLayer2PanelInputs } from './layer2Controller';
import { applyStylesToLayer2, applyStylesToDecorativeElement, applyStylesToAnsiArtViewer } from './styleUpdater';
import { setupDroppable, handleControlSelection, handleDroppedControlDragStart, handleDroppedControlDragEnd } from './droppedControlController';
import { renderTextColorsComponent } from './textColorsComponent';
import { applyCustomHtmlCode } from './htmlControlController';
// Removed ANIMATE_CSS_ANIMATIONS, etc. as they are not directly used in this file for export logic beyond base class name.

import type { Preset, ElementConfig, Layer2Config } from './types';


export function loadPresetsFromLocalStorage() {
    const storedPresets = localStorage.getItem(TESSERACT_PRESETS_KEY);
    if (storedPresets) {
        try {
            state.setPresets(JSON.parse(storedPresets));
        } catch (e) {
            console.error("Failed to parse presets from localStorage:", e);
            state.setPresets([]);
        }
    } else {
        state.setPresets([]);
    }
    renderPresetsList();
}

export function savePresetsToLocalStorage() {
    localStorage.setItem(TESSERACT_PRESETS_KEY, JSON.stringify(state.presets));
}

export function renderPresetsList() {
    if (!dom.presetsListContainer || !dom.noPresetsMessage) return;
    dom.presetsListContainer.innerHTML = ''; 

    if (state.presets.length === 0) {
        dom.noPresetsMessage.classList.remove('hidden');
        return;
    }
    dom.noPresetsMessage.classList.add('hidden');

    state.presets.forEach(preset => {
        const item = document.createElement('div');
        item.className = 'preset-item'; // Ensure this class provides appropriate styling
        item.innerHTML = `
            <div class="preset-item-info">
                <span class="preset-item-name truncate" title="${preset.name}">${preset.name}</span>
                <div class="preset-thumbnail" style="background-color: ${preset.layer2BgColorForThumbnail || 'transparent'};"></div>
            </div>
            <div class="preset-item-actions">
                <button class="preset-load-btn" data-preset-id="${preset.id}" title="Load Preset">Load</button>
                <button class="preset-export-btn" data-preset-id="${preset.id}" title="Export HTML">Export</button>
                <button class="preset-delete-btn" data-preset-id="${preset.id}" title="Delete Preset">Del</button>
            </div>
        `;
        dom.presetsListContainer.appendChild(item);

        item.querySelector('.preset-load-btn')?.addEventListener('click', () => handleLoadPreset(preset.id));
        item.querySelector('.preset-export-btn')?.addEventListener('click', () => handleExportPresetHTML(preset.id));
        item.querySelector('.preset-delete-btn')?.addEventListener('click', () => handleDeletePreset(preset.id));
    });
}

export function handleSavePreset() {
    if (!dom.layer2Element) return;

    const elementsConfigCopy: Record<string, Omit<ElementConfig, 'element'>> = {};
    Object.keys(state.elementsConfig).forEach(id => {
        const { element, ...rest } = state.elementsConfig[id]; // Destructure to exclude 'element'
        elementsConfigCopy[id] = JSON.parse(JSON.stringify(rest)); // Deep copy the rest
    });

    const newPreset: Preset = {
        id: generateUniqueId('preset'),
        name: `Preset - ${new Date().toLocaleString()}`,
        timestamp: Date.now(),
        layer2Config: JSON.parse(JSON.stringify(state.layer2Config)), 
        elementsConfig: elementsConfigCopy, 
        layer2HTML: dom.layer2Element.innerHTML,
        decorativeElementsHTML: {},
        layer2BgColorForThumbnail: state.layer2Config.bgColor, // For a visual cue in the preset list
    };

    // Store HTML content of each decorative element
    Object.keys(state.elementsConfig).forEach(id => {
        newPreset.decorativeElementsHTML[id] = state.elementsConfig[id].element.innerHTML;
    });

    state.addPreset(newPreset);
    savePresetsToLocalStorage();
    renderPresetsList();
    alert('Preset saved!');
}

function reinitializeLoadedContent() {
    // Re-setup droppable and event listeners for Layer 2 and its children
    if (dom.layer2Element) {
        setupDroppable(dom.layer2Element);
        dom.layer2Element.querySelectorAll<HTMLElement>('.dropped-control').forEach(control => {
            control.addEventListener('click', (e) => handleControlSelection(control, e));
            control.draggable = true;
            control.addEventListener('dragstart', handleDroppedControlDragStart);
            control.addEventListener('dragend', handleDroppedControlDragEnd);
            
            const controlType = control.dataset.controlType;
            if (controlType === 'text-colors') {
                renderTextColorsComponent(control);
            } else if (controlType === 'ansi-art-viewer') {
                applyStylesToAnsiArtViewer(control);
            } else if (controlType === 'html-control') {
                 // Ensure data attributes are present before applying
                if (control.dataset.htmlContent === undefined) control.dataset.htmlContent = '';
                if (control.dataset.cssContent === undefined) control.dataset.cssContent = '';
                if (control.dataset.jsContent === undefined) control.dataset.jsContent = '';
                setTimeout(() => applyCustomHtmlCode(control), 0);
            }

            if (control.classList.contains('dropped-row-container') || control.classList.contains('dropped-column-container')) {
                setupDroppable(control);
            }
        });
        // Update placeholder visibility for layer 2
        updatePlaceholderVisibility(dom.layer2Element, '.layer2-empty-placeholder');
    }

    // Re-setup droppable and event listeners for Decorative Elements and their children
    document.querySelectorAll<HTMLElement>('.decorative-element').forEach(el => {
        setupDroppable(el);
        el.querySelectorAll<HTMLElement>('.dropped-control').forEach(control => {
            control.addEventListener('click', (e) => handleControlSelection(control, e));
            control.draggable = true;
            control.addEventListener('dragstart', handleDroppedControlDragStart);
            control.addEventListener('dragend', handleDroppedControlDragEnd);

            const controlType = control.dataset.controlType;
            if (controlType === 'text-colors') {
                renderTextColorsComponent(control);
            } else if (controlType === 'ansi-art-viewer') {
                applyStylesToAnsiArtViewer(control);
            } else if (controlType === 'html-control') {
                if (control.dataset.htmlContent === undefined) control.dataset.htmlContent = '';
                if (control.dataset.cssContent === undefined) control.dataset.cssContent = '';
                if (control.dataset.jsContent === undefined) control.dataset.jsContent = '';
                setTimeout(() => applyCustomHtmlCode(control), 0);
            }

            if (control.classList.contains('dropped-row-container') || control.classList.contains('dropped-column-container')) {
                setupDroppable(control);
            }
        });
        // Update placeholder visibility for decorative elements
        updatePlaceholderVisibility(el, '.decorative-element-empty-placeholder');
    });
}


export function handleLoadPreset(presetId: string) {
    const preset = state.presets.find(p => p.id === presetId);
    if (!preset || !dom.layer2Element) return;

    // Deselect any currently selected element or control
    selectElement(null); 
    // Clear current content
    dom.layer2Element.innerHTML = ''; // Clear layer 2 content
    document.querySelectorAll<HTMLElement>('.decorative-element').forEach(el => {
        el.innerHTML = ''; // Clear all decorative elements
    });
    
    // Load Layer 2 config and apply styles
    state.setLayer2Config(JSON.parse(JSON.stringify(preset.layer2Config))); // Deep copy
    
    // Load Decorative Elements config
    state.setElementsConfig({}); // Clear current elementsConfig
    const tempElementsConfig = JSON.parse(JSON.stringify(preset.elementsConfig));
    Object.keys(tempElementsConfig).forEach(id => {
        const el = document.getElementById(id); // Find the element in the DOM
        if (el) {
            state.updateElementConfig(id, {
                ...tempElementsConfig[id],
                element: el // Re-link the live HTMLElement
            });
        }
    });

    applyStylesToLayer2(); // This will also re-apply styles to decorative elements due to positioning logic
    Object.keys(state.elementsConfig).forEach(id => applyStylesToDecorativeElement(id)); // Ensure all decorative elements are styled

    // Restore HTML content
    dom.layer2Element.innerHTML = preset.layer2HTML;
    Object.keys(preset.decorativeElementsHTML).forEach(id => {
        if (state.elementsConfig[id] && state.elementsConfig[id].element) {
            state.elementsConfig[id].element.innerHTML = preset.decorativeElementsHTML[id];
        }
    });

    // Reinitialize event listeners, droppables, etc. for the loaded content
    reinitializeLoadedContent();

    // Update UI panels
    updateLayer2PanelInputs(); 
    updatePanelForNoSelection(); // Or select a default if appropriate
    alert('Preset loaded!');
}


export function handleDeletePreset(presetId: string) {
    if (window.confirm('Are you sure you want to delete this preset?')) {
        state.updatePresets(state.presets.filter(p => p.id !== presetId));
        savePresetsToLocalStorage();
        renderPresetsList();
    }
}


function generateCSSTextForElement(elConfig: Omit<ElementConfig, 'element'>, layer2Conf: Layer2Config): string {
    let styles = `
        display: ${elConfig.isVisible ? elConfig.display : 'none'};
        z-index: ${elConfig.zIndex};
        overflow-x: ${elConfig.overflowX};
        overflow-y: ${elConfig.overflowY};
        width: ${elConfig.widthVmin}vmin;
        height: ${elConfig.heightVmin}vmin;
        margin-top: ${elConfig.marginTopVmin}vmin;
        margin-right: ${elConfig.marginRightVmin}vmin;
        margin-bottom: ${elConfig.marginBottomVmin}vmin;
        margin-left: ${elConfig.marginLeftVmin}vmin;
        opacity: ${elConfig.opacity};
        border-radius: ${elConfig.borderRadiusVmin}vmin;
        position: absolute;
        box-sizing: border-box;
    `;

    const transforms = [
      `translateX(${elConfig.transformTranslateX || 0}vmin)`,
      `translateY(${elConfig.transformTranslateY || 0}vmin)`,
      `rotate(${elConfig.rotationDeg || 0}deg)`,
      `scale(${elConfig.transformScale || 1})`,
      `skewX(${elConfig.transformSkewX || 0}deg)`,
      `skewY(${elConfig.transformSkewY || 0}deg)`,
    ].join(' ');
    if (transforms.trim() !== 'translateX(0vmin) translateY(0vmin) rotate(0deg) scale(1) skewX(0deg) skewY(0deg)') {
        styles += `transform: ${transforms};\n`;
    }

    const filters = [
      `blur(${elConfig.filterBlur || 0}px)`,
      `brightness(${elConfig.filterBrightness || 1})`,
      `contrast(${elConfig.filterContrast || 1})`,
      `grayscale(${elConfig.filterGrayscale || 0})`,
      `saturate(${elConfig.filterSaturate || 1})`,
      `sepia(${elConfig.filterSepia || 0})`,
      `hue-rotate(${elConfig.filterHueRotate || 0}deg)`,
      `invert(${elConfig.filterInvert || 0})`
    ];
    const activeFilters = filters.filter(f => 
        !(f.includes("blur(0px)") || f.includes("brightness(1)") || f.includes("contrast(1)") || 
        f.includes("grayscale(0)") || f.includes("saturate(1)") || f.includes("sepia(0)") ||
        f.includes("hue-rotate(0deg)") || f.includes("invert(0)")) 
    );
    if (activeFilters.length > 0) {
        styles += `filter: ${activeFilters.join(' ')};\n`;
    }


    if (elConfig.borderStyle !== 'none' && elConfig.borderWidthVmin > 0) {
        styles += `border: ${elConfig.borderWidthVmin}vmin ${elConfig.borderStyle} ${elConfig.borderColor};\n`;
    } else {
        styles += `border: none;\n`;
    }

    if (elConfig.imageUrl) {
        styles += `
            background-image: url('${elConfig.imageUrl}');
            background-size: ${elConfig.backgroundSize};
            background-position: ${elConfig.bgPosition};
            background-repeat: ${elConfig.bgRepeat};
            background-color: transparent;
        `;
    } else {
        styles += `
            background-image: none;
            background-color: ${elConfig.bgColor};
        `;
    }
    
      const hasElementBorder = elConfig.borderStyle !== 'none' && elConfig.borderWidthVmin > 0;
      const totalElementVisualWidthVmin = elConfig.widthVmin + (hasElementBorder ? 2 * elConfig.borderWidthVmin : 0);
      const totalElementVisualHeightVmin = elConfig.heightVmin + (hasElementBorder ? 2 * elConfig.borderWidthVmin : 0);
      const centeringOffsetX = totalElementVisualWidthVmin / 2;
      const centeringOffsetY = totalElementVisualHeightVmin / 2;
      const layer2ActualWidthPercent = layer2Conf.widthPercent;
      const layer2ActualHeightPercent = layer2Conf.heightPercent;
      let targetXPercent = 50; 
      let targetYPercent = 50; 
      if (elConfig.anchorX === 'left') targetXPercent = (50 - layer2ActualWidthPercent / 2);
      else if (elConfig.anchorX === 'right') targetXPercent = (50 + layer2ActualWidthPercent / 2);
      if (elConfig.anchorY === 'top') targetYPercent = (50 - layer2ActualHeightPercent / 2);
      else if (elConfig.anchorY === 'bottom') targetYPercent = (50 + layer2ActualHeightPercent / 2);
      const halfLayer2Border = layer2Conf.borderWidthPx / 2;
      let currentBorderOffsetX = 0;
      let currentBorderOffsetY = 0;
      if (elConfig.anchorX === 'left') currentBorderOffsetX = halfLayer2Border;
      else if (elConfig.anchorX === 'right') currentBorderOffsetX = -halfLayer2Border;
      if (elConfig.anchorY === 'top') currentBorderOffsetY = halfLayer2Border;
      else if (elConfig.anchorY === 'bottom') currentBorderOffsetY = -halfLayer2Border;

    styles += `
        top: calc(${targetYPercent}% + ${currentBorderOffsetY}px - ${centeringOffsetY}vmin);
        left: calc(${targetXPercent}% + ${currentBorderOffsetX}px - ${centeringOffsetX}vmin);
    `;
    return styles;
}

function getTextColorsComponentCSS(): string {
    // This CSS is fairly static, could be moved to a CSS file if preferred
    return `
        .dropped-text-colors-component {
            /* Base styles for the component */
            --primary-gradient-base-color-light: #00f000; /* Default base color */
            --gradient-lighten-color: #FFFFFF; /* Default lighten color */
            --gradient-color-1: color-mix(in srgb, var(--primary-gradient-base-color-light, #00f000) 55%, black 45%);
            --gradient-color-2: color-mix(in srgb, var(--primary-gradient-base-color-light, #00f000) 75%, black 25%);
            --gradient-color-3: var(--primary-gradient-base-color-light, #00f000);
            --gradient-color-4: color-mix(in srgb, var(--primary-gradient-base-color-light, #00f000) 75%, var(--gradient-lighten-color, #FFFFFF) 25%);
            --gradient-color-5: color-mix(in srgb, var(--primary-gradient-base-color-light, #00f000) 55%, var(--gradient-lighten-color, #FFFFFF) 45%);
            /* Add any other necessary CSS for text-colors component to function in isolation */
        }
    `;
}

export function handleExportPresetHTML(presetId: string) {
    const preset = state.presets.find(p => p.id === presetId);
    if (!preset) {
        alert('Preset not found for export.');
        return;
    }

    let collectedHtmlControlCSS = '';
    let collectedHtmlControlJS = '';

    const processControlHTML = (htmlString: string): string => {
        if (!htmlString) return '';
        const parser = new DOMParser();
        const doc = parser.parseFromString(htmlString, 'text/html');
        
        doc.querySelectorAll('.dropped-html-control').forEach(controlElement => {
            const htmlContent = controlElement.getAttribute('data-html-content') || '';
            const cssContent = controlElement.getAttribute('data-css-content') || '';
            const jsContent = controlElement.getAttribute('data-js-content') || '';

            // For export, replace the iframe's parent div with the actual HTML content.
            // The div itself (.dropped-html-control) will act as the container for the custom HTML.
            controlElement.innerHTML = htmlContent; 
            
            if (cssContent) {
                // Potentially scope CSS if controlElement has an ID, or add globally.
                // For simplicity, adding globally here.
                collectedHtmlControlCSS += `\n/* CSS from HTML Control */\n${cssContent}\n`;
            }
            if (jsContent) {
                collectedHtmlControlJS += `\n/* JS from HTML Control */\n(function() { try { \n${jsContent}\n } catch(e) { console.error("Error in embedded HTML control JS:", e); } })();\n`;
            }
        });
        
        // text-colors and ansi-art components in presets store their fully rendered HTML.
        // No special processing needed here for them, their styles are handled by global CSS.
        return doc.body.innerHTML;
    };
    
    const processedLayer2HTML = processControlHTML(preset.layer2HTML);
    const processedDecorativeElementsHTML: Record<string, string> = {};
    Object.keys(preset.decorativeElementsHTML).forEach(id => {
        processedDecorativeElementsHTML[id] = processControlHTML(preset.decorativeElementsHTML[id]);
    });

    let decorativeElementsCSS = '';
    Object.keys(preset.elementsConfig).forEach(id => {
        const elConfig = preset.elementsConfig[id];
        decorativeElementsCSS += `#${id} { ${generateCSSTextForElement(elConfig, preset.layer2Config)} }\n`;
    });

    const layer2Styles = `
        display: ${preset.layer2Config.isVisible ? 'flex' : 'none'}; /* Assuming flex for content alignment */
        flex-direction: column; /* Or as configured, default to column for simplicity */
        align-items: flex-start; /* Default, can be overridden by Tailwind */
        justify-content: flex-start; /* Default, can be overridden by Tailwind */
        width: ${preset.layer2Config.widthPercent}%;
        height: ${preset.layer2Config.heightPercent}%;
        padding: ${preset.layer2Config.paddingPx}px;
        background-color: ${preset.layer2Config.bgColor};
        border: ${preset.layer2Config.borderWidthPx}px solid ${preset.layer2Config.borderColor};
        position: relative; 
        margin: auto; 
        overflow: hidden; 
    `;

    const finalHtml = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exported: ${escapeHtml(preset.name)}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        html, body { height: 100%; margin: 0; } /* Ensure body takes full height for centering */
        body { 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            background-color: #dde1e4; /* Neutral page background */
            font-family: sans-serif;
        }
        #layer-2 {
            ${layer2Styles}
        }
        ${decorativeElementsCSS}
        ${getTextColorsComponentCSS()}
        ${collectedHtmlControlCSS}

        .ansi-row { white-space: pre; font-family: monospace; line-height: 1.2; }
        @keyframes blink { 50% { opacity: 0; } }

        /* Tailwind custom config (if any, typically not needed for CDN) */
        /* Ensure Tailwind's preflight doesn't break custom styles too much, or scope custom styles more aggressively. */
    </style>
</head>
<body>
    <div id="layer-2" class="${preset.layer2Config.shadowClass || ''} ${preset.layer2Config.backdropBlurClass || ''}">
        ${processedLayer2HTML}
    </div>
    ${Object.keys(preset.elementsConfig).map(id => {
        const elConfig = preset.elementsConfig[id];
        const animationClasses = elConfig.animationName ? 
            `${ANIMATE_CSS_BASE_CLASS} ${elConfig.animationName} ${elConfig.animationIterationClass || ''} ${elConfig.animationDelayClass || ''} ${elConfig.animationSpeedClass || ''}` 
            : '';
        return `
    <div class="decorative-element ${elConfig.shadowClass || ''} ${animationClasses}" id="${id}">
        ${processedDecorativeElementsHTML[id] || ''}
    </div>`;
    }).join('')}

    <script>
        // JS from HTML Controls
        ${collectedHtmlControlJS}
    </script>
</body>
</html>`;

    const blob = new Blob([finalHtml], { type: 'text/html' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${getSafeFilename(preset.name)}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
}
