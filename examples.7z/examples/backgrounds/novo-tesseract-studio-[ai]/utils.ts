/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export function generateUniqueId(prefix: string = 'id'): string {
    return `${prefix}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export function rgbToHex(rgb: string): string {
    if (!rgb) return '#000000';
    if (rgb.startsWith('#')) { // Already hex
        // Ensure it's either #RRGGBB or #RRGGBBAA
        if (rgb.length === 4) return `#${rgb[1]}${rgb[1]}${rgb[2]}${rgb[2]}${rgb[3]}${rgb[3]}`; // #RGB to #RRGGBB
        if (rgb.length === 5) return `#${rgb[1]}${rgb[1]}${rgb[2]}${rgb[2]}${rgb[3]}${rgb[3]}${rgb[4]}${rgb[4]}`; // #RGBA to #RRGGBBAA
        return rgb.toUpperCase();
    }
    if (rgb.toLowerCase() === 'transparent') return '#00000000';

    const match = rgb.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)$/);
    if (!match) return '#000000'; // Default to black if parsing fails

    const r = parseInt(match[1], 10);
    const g = parseInt(match[2], 10);
    const b = parseInt(match[3], 10);

    const toHex = (c: number) => c.toString(16).padStart(2, '0');

    if (match[4] !== undefined) { // RGBA
        const a = parseFloat(match[4]);
        const alphaHex = Math.round(a * 255).toString(16).padStart(2, '0');
        return `#${toHex(r)}${toHex(g)}${toHex(b)}${alphaHex}`.toUpperCase();
    } else { // RGB
        return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toUpperCase();
    }
}


export function splitColorToHexAndAlpha(colorString: string | null | undefined): { hexRGB: string, alpha: number } {
    if (!colorString || typeof colorString !== 'string') {
        return { hexRGB: '#000000', alpha: 1.0 };
    }

    colorString = colorString.toLowerCase().trim();

    if (colorString === 'transparent') {
        return { hexRGB: '#000000', alpha: 0.0 };
    }

    // Try to match rgba(r,g,b,a)
    let match = colorString.match(/^rgba\((\d+),\s*(\d+),\s*(\d+),\s*([\d.]+)\)$/);
    if (match) {
        const r = parseInt(match[1], 10);
        const g = parseInt(match[2], 10);
        const b = parseInt(match[3], 10);
        const a = parseFloat(match[4]);
        const hex = "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase();
        return { hexRGB: hex, alpha: Math.max(0, Math.min(1, a)) };
    }

    // Try to match rgb(r,g,b)
    match = colorString.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    if (match) {
        const r = parseInt(match[1], 10);
        const g = parseInt(match[2], 10);
        const b = parseInt(match[3], 10);
        const hex = "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase();
        return { hexRGB: hex, alpha: 1.0 };
    }

    // Try to match #RRGGBBAA or #RGBA
    match = colorString.match(/^#([0-9a-f]{8})$/i) || colorString.match(/^#([0-9a-f]{4})$/i);
    if (match) {
        let hexPart = match[1];
        if (hexPart.length === 4) { // #RGBA to #RRGGBBAA
            hexPart = hexPart[0] + hexPart[0] + hexPart[1] + hexPart[1] + hexPart[2] + hexPart[2] + hexPart[3] + hexPart[3];
        }
        const hexRGB = `#${hexPart.substring(0, 6)}`.toUpperCase();
        const alphaHex = hexPart.substring(6, 8);
        const alpha = Math.max(0, Math.min(1, parseInt(alphaHex, 16) / 255));
        return { hexRGB: hexRGB, alpha: alpha };
    }

    // Try to match #RRGGBB or #RGB
    match = colorString.match(/^#([0-9a-f]{6})$/i) || colorString.match(/^#([0-9a-f]{3})$/i);
    if (match) {
        let hexPart = match[1];
        if (hexPart.length === 3) { // #RGB to #RRGGBB
             hexPart = hexPart[0] + hexPart[0] + hexPart[1] + hexPart[1] + hexPart[2] + hexPart[2];
        }
        return { hexRGB: `#${hexPart}`.toUpperCase(), alpha: 1.0 };
    }
    
    // Default for unknown format (e.g., named colors not handled yet)
    // For simplicity, attempt to use it as is for hexRGB, and assume opaque.
    // A more robust solution might involve a color name to hex map or a canvas trick.
    // However, input type="color" usually handles named colors for its value.
    const tempElement = document.createElement('div');
    tempElement.style.color = colorString;
    const computedColor = getComputedStyle(tempElement).color;
     if (computedColor && (computedColor.startsWith('rgb') || computedColor.startsWith('rgba'))) {
        return splitColorToHexAndAlpha(computedColor); // Recurse with the computed value
    }

    return { hexRGB: '#000000', alpha: 1.0 }; // Fallback
}


export function getSafeFilename(name: string): string {
    return name.replace(/[^a-z0-9_\-\s.]/gi, '_').replace(/\s+/g, '_');
}

export function updatePlaceholderVisibility(container: HTMLElement | null, placeholderSelector: string) {
    if (!container) return;
    const placeholder = container.querySelector(placeholderSelector);
    if (placeholder) {
        let childElementCount = 0;
        for (let i = 0; i < container.children.length; i++) {
            if (!container.children[i].matches(placeholderSelector)) {
                childElementCount++;
            }
        }
        placeholder.classList.toggle('hidden', childElementCount > 0);
    }
}

export function handleNumberInputMouseWheel(event: WheelEvent) {
    const target = event.target as HTMLInputElement;
    if (target.type !== 'number' && target.type !== 'range') return; 

    event.preventDefault();

    const step = parseFloat(target.step) || 1;
    let value = parseFloat(target.value);
    if (isNaN(value)) value = parseFloat(target.min) || 0; 

    if (event.deltaY < 0) { 
        value += step;
    } else { 
        value -= step;
    }
    
    if (target.min !== "" && value < parseFloat(target.min)) {
        value = parseFloat(target.min);
    }
    if (target.max !== "" && value > parseFloat(target.max)) {
        value = parseFloat(target.max);
    }

    const stepString = target.step.toString();
    const decimalPlaces = stepString.includes('.') ? stepString.split('.')[1].length : 0;
    target.value = value.toFixed(decimalPlaces);

    target.dispatchEvent(new Event('input', { bubbles: true }));
}

/**
 * Escapes HTML special characters to prevent XSS.
 * @param unsafe The string to escape.
 * @returns The escaped string.
 */
export function escapeHtml(unsafe: string): string {
    if (unsafe === null || unsafe === undefined) return '';
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}

/**
 * Converts an RGB or Hex color string and an alpha value to an RGBA string.
 * @param colorInput Value from color picker (hex string, e.g., #RRGGBB).
 * @param alpha Alpha value (0-1).
 * @returns RGBA string (e.g., "rgba(255,0,0,0.5)").
 */
export function combineHexAndAlphaToRGBA(hexColor: string, alpha: number): string {
    if (!hexColor.startsWith('#') || (hexColor.length !== 7 && hexColor.length !== 4)) {
        // If not a valid hex, try to parse it as is with alpha, or fallback
        const parsed = splitColorToHexAndAlpha(hexColor); // Try to normalize it
        hexColor = parsed.hexRGB; // Use the normalized hex
    }

    let r: number, g: number, b: number;
    if (hexColor.length === 4) { // Short hex #RGB
        r = parseInt(hexColor[1] + hexColor[1], 16);
        g = parseInt(hexColor[2] + hexColor[2], 16);
        b = parseInt(hexColor[3] + hexColor[3], 16);
    } else { // Full hex #RRGGBB
        r = parseInt(hexColor.slice(1, 3), 16);
        g = parseInt(hexColor.slice(3, 5), 16);
        b = parseInt(hexColor.slice(5, 7), 16);
    }

    if (isNaN(r) || isNaN(g) || isNaN(b)) { // Fallback if parsing failed
        return `rgba(0,0,0,${Math.max(0, Math.min(1, alpha))})`;
    }

    return `rgba(${r},${g},${b},${Math.max(0, Math.min(1, alpha))})`;
}

/**
 * Processes an image to make a target color (within a tolerance) transparent.
 * @param base64ImageData The base64 encoded image data.
 * @param targetColor Optional object with r, g, b properties for the target color
 *                    and an optional `tolerance` (0-255, default 0).
 *                    If not provided, the image is just converted to PNG.
 * @returns A promise that resolves to a base64 encoded PNG data URL.
 */
export function processImageForTransparency(
    base64ImageData: string,
    targetColor?: { r: number; g: number; b: number; tolerance?: number }
): Promise<string> {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = img.width;
            canvas.height = img.height;
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                reject(new Error('Could not get canvas context.'));
                return;
            }
            ctx.drawImage(img, 0, 0);
            
            if (targetColor) {
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                const data = imageData.data;
                const tolerance = targetColor.tolerance || 0;
                for (let i = 0; i < data.length; i += 4) {
                    const r = data[i];
                    const g = data[i + 1];
                    const b = data[i + 2];
                    
                    // Check if current pixel is within tolerance of the target color
                    if (
                        Math.abs(r - targetColor.r) <= tolerance &&
                        Math.abs(g - targetColor.g) <= tolerance &&
                        Math.abs(b - targetColor.b) <= tolerance
                    ) {
                        data[i + 3] = 0; // Set alpha to 0 (transparent)
                    }
                }
                ctx.putImageData(imageData, 0, 0);
            }
            resolve(canvas.toDataURL('image/png'));
        };
        img.onerror = (error) => {
            console.error("Error loading image for transparency processing:", error);
            reject(new Error('Error loading image.'));
        };
        img.src = base64ImageData;
    });
}
