
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as state from './state';
import * as dom from './domElements';
import { SHADOW_CLASSES, BACKDROP_BLUR_CLASSES } from './constants';
import { updatePlaceholderVisibility, rgbToHex } from './utils';
import type { TextAlignmentHorizontal, TextAlignmentVertical, FlexAlignItems, FlexJustifyContent, FontStyleType, TextDecorationType, TextTransformType } from './types';
import { renderTextColorsComponent } from './textColorsComponent';
import { renderAnsiToHtml, hasAnsi } from './ansiArtRenderer';


export function applyStylesToDecorativeElement(id: string) {
  if (!state.elementsConfig[id] || !state.layer2Config) return; 
  const config = state.elementsConfig[id];
  const el = config.element;

  el.style.display = config.isVisible ? config.display : 'none'; 
  el.style.zIndex = config.zIndex.toString();
  el.style.overflowX = config.overflowX;
  el.style.overflowY = config.overflowY;
  el.style.width = `${config.widthVmin}vmin`;
  el.style.height = `${config.heightVmin}vmin`;
  
  if (config.paddingVmin !== undefined) {
    el.style.padding = `${config.paddingVmin}vmin`;
  } else {
    el.style.padding = '0'; // Default if not set
  }

  el.style.marginTop = `${config.marginTopVmin}vmin`;
  el.style.marginRight = `${config.marginRightVmin}vmin`;
  el.style.marginBottom = `${config.marginBottomVmin}vmin`;
  el.style.marginLeft = `${config.marginLeftVmin}vmin`;

  el.style.opacity = config.opacity.toString();
  el.style.borderRadius = `${config.borderRadiusVmin}vmin`;
  
  const transforms = [
      `translateX(${config.transformTranslateX || 0}vmin)`,
      `translateY(${config.transformTranslateY || 0}vmin)`,
      `rotate(${config.rotationDeg || 0}deg)`,
      `scale(${config.transformScale || 1})`,
      `skewX(${config.transformSkewX || 0}deg)`,
      `skewY(${config.transformSkewY || 0}deg)`,
  ];
  el.style.transform = transforms.join(' ');

  const filters = [
      `blur(${config.filterBlur || 0}px)`,
      `brightness(${config.filterBrightness || 1})`,
      `contrast(${config.filterContrast || 1})`,
      `grayscale(${config.filterGrayscale || 0})`,
      `saturate(${config.filterSaturate || 1})`,
      `sepia(${config.filterSepia || 0})`,
      `hue-rotate(${config.filterHueRotate || 0}deg)`,
      `invert(${config.filterInvert || 0})`
  ];
  const activeFilters = filters.filter(f => 
      !(f.includes("blur(0px)") || f.includes("brightness(1)") || f.includes("contrast(1)") || 
      f.includes("grayscale(0)") || f.includes("saturate(1)") || f.includes("sepia(0)") ||
      f.includes("hue-rotate(0deg)") || f.includes("invert(0)")) 
  );
  el.style.filter = activeFilters.length > 0 ? activeFilters.join(' ') : 'none';


  if (config.borderStyle !== 'none' && config.borderWidthVmin > 0) {
    el.style.border = `${config.borderWidthVmin}vmin ${config.borderStyle} ${config.borderColor}`;
  } else {
    el.style.border = 'none';
  }

  const hasElementBorder = config.borderStyle !== 'none' && config.borderWidthVmin > 0;
  const totalElementVisualWidthVmin = config.widthVmin + (hasElementBorder ? 2 * config.borderWidthVmin : 0);
  const totalElementVisualHeightVmin = config.heightVmin + (hasElementBorder ? 2 * config.borderWidthVmin : 0);
  
  const centeringOffsetX = totalElementVisualWidthVmin / 2;
  const centeringOffsetY = totalElementVisualHeightVmin / 2;

  const layer2ActualWidthPercent = state.layer2Config.widthPercent;
  const layer2ActualHeightPercent = state.layer2Config.heightPercent;

  let targetXPercent = 50; 
  let targetYPercent = 50; 

  if (config.anchorX === 'left') {
    targetXPercent = (50 - layer2ActualWidthPercent / 2);
  } else if (config.anchorX === 'right') {
    targetXPercent = (50 + layer2ActualWidthPercent / 2);
  }

  if (config.anchorY === 'top') {
    targetYPercent = (50 - layer2ActualHeightPercent / 2);
  } else if (config.anchorY === 'bottom') {
    targetYPercent = (50 + layer2ActualHeightPercent / 2);
  }
  
  const halfLayer2Border = state.layer2Config.borderWidthPx / 2;
  let currentBorderOffsetX = 0;
  let currentBorderOffsetY = 0;

  if (config.anchorX === 'left') currentBorderOffsetX = halfLayer2Border;
  else if (config.anchorX === 'right') currentBorderOffsetX = -halfLayer2Border;

  if (config.anchorY === 'top') currentBorderOffsetY = halfLayer2Border;
  else if (config.anchorY === 'bottom') currentBorderOffsetY = -halfLayer2Border;

  el.style.top = `calc(${targetYPercent}% + ${currentBorderOffsetY}px - ${centeringOffsetY}vmin)`;
  el.style.left = `calc(${targetXPercent}% + ${currentBorderOffsetX}px - ${centeringOffsetX}vmin)`;
  
  if (config.imageUrl) {
    el.style.backgroundImage = `url('${config.imageUrl}')`;
    el.style.backgroundSize = config.backgroundSize;
    el.style.backgroundPosition = config.bgPosition;
    el.style.backgroundRepeat = config.bgRepeat;
    el.style.backgroundColor = 'transparent'; // Ensure bg color doesn't interfere
  } else {
    el.style.backgroundImage = 'none';
    el.style.backgroundColor = config.bgColor;
  }

  SHADOW_CLASSES.forEach(cls => el.classList.remove(cls));
  if (config.shadowClass !== 'shadow-none') {
    el.classList.add(config.shadowClass);
  }
}

export function applyStylesToDroppedControl() {
    if (!state.selectedDroppedControl) return;
    const control = state.selectedDroppedControl;
    const controlType = control.dataset.controlType || control.tagName.toLowerCase();

    if (controlType === 'text-colors') {
        renderTextColorsComponent(control);
        return;
    }
    if (controlType === 'ansi-art-viewer') {
        applyStylesToAnsiArtViewer(control);
        return;
    }
    
    // Fallback for other generic controls
    if (!dom.droppedControlVisibleInput || !dom.droppedControlTextContentInput || 
        !dom.droppedControlPlaceholderInput || !dom.droppedControlImageSrcInput || !dom.droppedControlWidthInput || 
        !dom.droppedControlHeightInput || !dom.droppedControlBgColorInput || !dom.droppedControlTextColorInput ||
        !dom.droppedControlOpacityInput || !dom.droppedControlBorderRadiusInput || 
        !dom.droppedControlBorderWidthInput || !dom.droppedControlBorderStyleSelect || !dom.droppedControlBorderColorInput ||
        !dom.droppedControlBoxShadowXInput || !dom.droppedControlBoxShadowYInput || !dom.droppedControlBoxShadowBlurInput || !dom.droppedControlBoxShadowColorInput ||
        !dom.droppedControlFontFamilyInput || !dom.droppedControlFontSizeInput || !dom.droppedControlFontWeightSelect ||
        !dom.droppedControlFontStyleSelect || !dom.droppedControlLineHeightInput || !dom.droppedControlLetterSpacingInput ||
        !dom.droppedControlTextTransformSelect || !dom.droppedControlTextDecorationSelect ||
        // Assuming the rest of the condition and function body is as provided,
        // even if truncated in the prompt. The fix is above this part.
        // The following lines are just to match the structure from the prompt.
        // It's possible the original file has more here.
        !dom.textAlignHorizontalSelect || !dom.textAlignVerticalSelect || !dom.containerAlignItemsSelect || !dom.containerJustifyContentSelect) return;


    control.style.display = dom.droppedControlVisibleInput.checked ? '' : 'none'; // Use '' to revert to default display

    if (control.tagName === 'INPUT' || control.tagName === 'TEXTAREA') {
        (control as HTMLInputElement | HTMLTextAreaElement).value = dom.droppedControlTextContentInput.value;
        (control as HTMLInputElement | HTMLTextAreaElement).placeholder = dom.droppedControlPlaceholderInput.value;
    } else {
        control.textContent = dom.droppedControlTextContentInput.value;
    }

    if (control.tagName === 'IMG') {
        (control as HTMLImageElement).src = dom.droppedControlImageSrcInput.value;
    } else if (control.dataset.controlType === 'image-element') {
        control.style.backgroundImage = dom.droppedControlImageSrcInput.value ? `url('${dom.droppedControlImageSrcInput.value}')` : 'none';
        control.style.backgroundSize = 'cover'; // Or make this configurable
        control.style.backgroundPosition = 'center';
    }


    control.style.width = dom.droppedControlWidthInput.value;
    control.style.height = dom.droppedControlHeightInput.value;
    control.style.backgroundColor = dom.droppedControlBgColorInput.value;
    control.style.color = dom.droppedControlTextColorInput.value;
    control.style.opacity = dom.droppedControlOpacityInput.value;
    control.style.borderRadius = `${dom.droppedControlBorderRadiusInput.value}px`;
    control.style.borderWidth = `${dom.droppedControlBorderWidthInput.value}px`;
    control.style.borderStyle = dom.droppedControlBorderStyleSelect.value;
    control.style.borderColor = dom.droppedControlBorderColorInput.value;

    const boxShadowX = dom.droppedControlBoxShadowXInput.value + 'px';
    const boxShadowY = dom.droppedControlBoxShadowYInput.value + 'px';
    const boxShadowBlur = dom.droppedControlBoxShadowBlurInput.value + 'px';
    const boxShadowColor = dom.droppedControlBoxShadowColorInput.value;
    if (boxShadowX !== '0px' || boxShadowY !== '0px' || boxShadowBlur !== '0px') {
        control.style.boxShadow = `${boxShadowX} ${boxShadowY} ${boxShadowBlur} ${boxShadowColor}`;
    } else {
        control.style.boxShadow = 'none';
    }

    // Typography
    control.style.fontFamily = dom.droppedControlFontFamilyInput.value;
    control.style.fontSize = dom.droppedControlFontSizeInput.value;
    control.style.fontWeight = dom.droppedControlFontWeightSelect.value;
    control.style.fontStyle = dom.droppedControlFontStyleSelect.value as FontStyleType;
    control.style.lineHeight = dom.droppedControlLineHeightInput.value;
    control.style.letterSpacing = dom.droppedControlLetterSpacingInput.value;
    control.style.textTransform = dom.droppedControlTextTransformSelect.value as TextTransformType;
    control.style.textDecoration = dom.droppedControlTextDecorationSelect.value as TextDecorationType;

    const textShadowX = dom.droppedControlTextShadowXInput.value + 'px';
    const textShadowY = dom.droppedControlTextShadowYInput.value + 'px';
    const textShadowBlur = dom.droppedControlTextShadowBlurInput.value + 'px';
    const textShadowColor = dom.droppedControlTextShadowColorInput.value;
     if (textShadowX !== '0px' || textShadowY !== '0px' || textShadowBlur !== '0px') {
        control.style.textShadow = `${textShadowX} ${textShadowY} ${textShadowBlur} ${textShadowColor}`;
    } else {
        control.style.textShadow = 'none';
    }

    // Text Alignment (for textual controls)
    if (['button', 'text-block', 'text-input'].includes(controlType) && dom.textAlignHorizontalSelect && dom.textAlignVerticalSelect) {
        control.style.textAlign = dom.textAlignHorizontalSelect.value as TextAlignmentHorizontal;
        if (controlType !== 'text-input') { // Vertical alignment typically for block/flex items
            control.style.display = 'flex'; // Ensure flex for vertical alignment
            control.style.alignItems = dom.textAlignVerticalSelect.value as FlexAlignItems; 
            // For buttons, also set justify-content if you want text centered horizontally within the button via flex
            if(controlType === 'button') control.style.justifyContent = 'center';
        }
    }

    // Container Alignment (for row/column containers)
    if (['row-container', 'column-container'].includes(controlType) && dom.containerAlignItemsSelect && dom.containerJustifyContentSelect) {
        control.style.alignItems = dom.containerAlignItemsSelect.value as FlexAlignItems;
        control.style.justifyContent = dom.containerJustifyContentSelect.value as FlexJustifyContent;
    }

    // Update placeholder visibility for parent container if this control is inside one
    const parent = control.parentElement;
    if (parent) {
        if (parent.classList.contains('dropped-row-container') || parent.classList.contains('dropped-column-container')) {
            updatePlaceholderVisibility(parent, '.container-empty-placeholder');
        } else if (parent.classList.contains('decorative-element')) {
             updatePlaceholderVisibility(parent, '.decorative-element-empty-placeholder');
        } else if (parent.id === 'layer-2') {
            updatePlaceholderVisibility(parent, '.layer2-empty-placeholder');
        }
    }
}


export function applyStylesToLayer2() {
  if (!dom.layer2Element || !state.layer2Config) return;
  const config = state.layer2Config;

  dom.layer2Element.style.display = config.isVisible ? 'flex' : 'none';
  dom.layer2Element.style.width = `${config.widthPercent}%`;
  dom.layer2Element.style.height = `${config.heightPercent}%`;
  dom.layer2Element.style.padding = `${config.paddingPx}px`;
  
  dom.layer2Element.style.opacity = (config.opacity !== undefined) ? config.opacity.toString() : '1';

  if (config.imageUrl) {
    dom.layer2Element.style.backgroundImage = `url('${config.imageUrl}')`;
    dom.layer2Element.style.backgroundSize = config.backgroundSize || 'cover';
    dom.layer2Element.style.backgroundPosition = config.bgPosition || 'center center';
    dom.layer2Element.style.backgroundRepeat = config.bgRepeat || 'no-repeat';
    dom.layer2Element.style.backgroundColor = 'transparent'; // Ensure bg color doesn't interfere
  } else {
    dom.layer2Element.style.backgroundImage = 'none';
    dom.layer2Element.style.backgroundColor = config.bgColor;
  }
  
  dom.layer2Element.style.borderWidth = `${config.borderWidthPx}px`;
  dom.layer2Element.style.borderStyle = config.borderStyle || 'solid';
  dom.layer2Element.style.borderColor = config.borderColor;
  dom.layer2Element.style.borderRadius = `${config.borderRadiusPx || 0}px`;


  SHADOW_CLASSES.forEach(cls => dom.layer2Element!.classList.remove(cls));
  if (config.shadowClass && config.shadowClass !== 'shadow-none') {
    dom.layer2Element.classList.add(config.shadowClass);
  }
  
  BACKDROP_BLUR_CLASSES.forEach(cls => {
    if (cls) dom.layer2Element!.classList.remove(cls); 
  });
  if (config.backdropBlurClass && config.backdropBlurClass !== 'backdrop-blur-none' && config.backdropBlurClass !== '') {
    dom.layer2Element.classList.add(config.backdropBlurClass);
  }

  Object.keys(state.elementsConfig).forEach(id => applyStylesToDecorativeElement(id));
}

export function applyStylesToAnsiArtViewer(passedControl?: HTMLElement) {
    const controlToStyle = passedControl || state.selectedDroppedControl;
    if (!controlToStyle || controlToStyle.dataset.controlType !== 'ansi-art-viewer' ||
        !dom.ansiArtVisibleInput || !dom.ansiArtContentInput || !dom.ansiArtWidthInput || !dom.ansiArtHeightInput ||
        !dom.ansiArtBgColorInput || !dom.ansiArtTextColorInput || !dom.ansiArtOpacityInput ||
        !dom.ansiArtBorderRadiusInput || !dom.ansiArtBorderWidthInput || !dom.ansiArtBorderStyleSelect || !dom.ansiArtBorderColorInput ||
        !dom.ansiArtBoxShadowXInput || !dom.ansiArtBoxShadowYInput || !dom.ansiArtBoxShadowBlurInput || !dom.ansiArtBoxShadowColorInput
    ) return;

    controlToStyle.style.display = dom.ansiArtVisibleInput.checked ? 'block' : 'none';
    controlToStyle.style.width = dom.ansiArtWidthInput.value;
    controlToStyle.style.height = dom.ansiArtHeightInput.value;
    controlToStyle.style.opacity = dom.ansiArtOpacityInput.value;
    
    controlToStyle.style.borderRadius = `${dom.ansiArtBorderRadiusInput.value}px`;
    controlToStyle.style.borderWidth = `${dom.ansiArtBorderWidthInput.value}px`;
    controlToStyle.style.borderStyle = dom.ansiArtBorderStyleSelect.value;
    controlToStyle.style.borderColor = dom.ansiArtBorderColorInput.value;

    const boxShadowX = dom.ansiArtBoxShadowXInput.value + 'px';
    const boxShadowY = dom.ansiArtBoxShadowYInput.value + 'px';
    const boxShadowBlur = dom.ansiArtBoxShadowBlurInput.value + 'px';
    const boxShadowColor = dom.ansiArtBoxShadowColorInput.value;
    if (boxShadowX !== '0px' || boxShadowY !== '0px' || boxShadowBlur !== '0px') {
        controlToStyle.style.boxShadow = `${boxShadowX} ${boxShadowY} ${boxShadowBlur} ${boxShadowColor}`;
    } else {
        controlToStyle.style.boxShadow = 'none';
    }
    
    const ansiContent = dom.ansiArtContentInput.value;
    controlToStyle.dataset.ansiContent = ansiContent;
    const contentWrapper = controlToStyle.querySelector('.ansi-art-content-wrapper') as HTMLElement;
    const placeholder = controlToStyle.querySelector('.ansi-art-placeholder') as HTMLElement;

    if (contentWrapper) {
        contentWrapper.style.backgroundColor = dom.ansiArtBgColorInput.value;
        contentWrapper.style.color = dom.ansiArtTextColorInput.value; // Default text color for non-ANSI parts

        if (ansiContent.trim() === '') {
            if (placeholder) placeholder.style.display = 'block';
            contentWrapper.innerHTML = ''; // Clear previous art
            contentWrapper.appendChild(placeholder); // Re-add placeholder if it was cleared
        } else {
            if (placeholder) placeholder.style.display = 'none';
            // Render ANSI or plain text
            if (hasAnsi(ansiContent)) {
                 contentWrapper.innerHTML = renderAnsiToHtml(ansiContent);
            } else {
                const pre = document.createElement('pre');
                pre.textContent = ansiContent;
                contentWrapper.innerHTML = ''; // Clear previous
                contentWrapper.appendChild(pre);
            }
        }
    }
}