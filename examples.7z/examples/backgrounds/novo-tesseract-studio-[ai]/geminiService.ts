/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { GenerateContentParameters } from "@google/genai";
import type { AiInteraction } from './types'; // Import AiInteraction type from types.ts

// Store the AI client instance globally within this module
let ai: GoogleGenAI | null = null;
let currentApiKey: string | null = null;

/**
 * Initializes the GoogleGenAI client with the provided API key.
 * If the key is different from the current one, a new client is created.
 * @param apiKey The API key for Google GenAI.
 */
function initializeAiClient(apiKey: string) {
    if (ai && currentApiKey === apiKey) {
        return; // Client already initialized with this key
    }
    try {
        ai = new GoogleGenAI({ apiKey });
        currentApiKey = apiKey;
        console.log('[GeminiService] GoogleGenAI client initialized.');
    } catch (error) {
        console.error('[GeminiService] Error initializing GoogleGenAI client:', error);
        ai = null;
        currentApiKey = null;
        throw new Error(`Failed to initialize AI client: ${error instanceof Error ? error.message : String(error)}`);
    }
}

/**
 * Generates an image using the Gemini API (Imagen model).
 * @param prompt The text prompt for image generation.
 * @param apiKey The API key for Google GenAI.
 * @returns A promise that resolves to a base64 encoded image data URL.
 */
export async function generateImageWithGemini(prompt: string, apiKey: string): Promise<string> {
    initializeAiClient(apiKey);
    if (!ai) {
        throw new Error("AI client is not initialized. Please provide a valid API key.");
    }

    console.log('[GeminiService] Requesting image generation with prompt:', prompt);
    try {
        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: prompt,
            config: { numberOfImages: 1, outputMimeType: 'image/png' },
        });

        if (response.generatedImages && response.generatedImages.length > 0 && response.generatedImages[0].image?.imageBytes) {
            const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
            const imageUrl = `data:image/png;base64,${base64ImageBytes}`;
            console.log('[GeminiService] Image generated successfully.');
            return imageUrl;
        } else {
            let detail = "Unknown reason.";
            if (!response.generatedImages) {
                detail = "The 'generatedImages' field was missing in the API response.";
            } else if (response.generatedImages.length === 0) {
                detail = "The 'generatedImages' array was empty. The API might have filtered the result or failed to generate an image for the prompt.";
            } else if (!response.generatedImages[0].image) {
                detail = "The first generated image object was missing the 'image' field.";
            } else if (!response.generatedImages[0].image.imageBytes) {
                detail = "The first generated image object was missing the 'imageBytes' field.";
            }
            console.error(`[GeminiService] No image data received from API. Detail: ${detail}. Full API response:`, JSON.stringify(response, null, 2));
            throw new Error(`No image data received from API. ${detail}`);
        }
    } catch (error) {
        console.error('[GeminiService] Error generating image:', error);
        if (error instanceof Error && error.message.includes('API key not valid')) {
             throw new Error('Invalid API Key. Please check your Gemini API Key.');
        }
        // Check if it's the error we threw above, if so, rethrow it to preserve detail
        if (error instanceof Error && error.message.startsWith('No image data received from API')) {
            throw error;
        }
        throw new Error(`Failed to generate image: ${error instanceof Error ? error.message : String(error)}`);
    }
}

/**
 * Interprets a configuration prompt using the Gemini API (text model).
 * Attempts to parse a JSON response, cleaning markdown fences if present.
 * @param prompt The text prompt for configuration.
 * @param apiKey The API key for Google GenAI.
 * @param history An array of previous AiInteraction objects for context.
 * @returns A promise that resolves to a string (JSON string or plain text).
 */
export async function interpretConfigurationPrompt(
    prompt: string,
    apiKey: string,
    history: AiInteraction[]
): Promise<string> {
    initializeAiClient(apiKey);
    if (!ai) {
        throw new Error("AI client is not initialized. Please provide a valid API key.");
    }
    
    console.log('[GeminiService] Interpreting configuration prompt with history:', prompt, history);

    const systemInstructionText = `You are an AI assistant for a UI editor. The user will provide a request to change UI elements or manage controls. Your task is to translate this request into a JSON object or an array of JSON objects representing actions.

A history of the last up to 50 interactions (user prompt and your JSON response) is provided as part of the conversation. Use this history to understand context. The application assigns unique IDs to new controls (e.g., 'dc-button-xyz'). When a user refers to 'the button I just asked you to add' or similar, you should infer context from your most recent 'addControl' instruction.

Each JSON object in your response (or the single JSON object if not an array) MUST have an "action" key. Possible actions are "modifyElementProperties", "addControl", "deleteControl", "modifyControlProperties".

1. For "modifyElementProperties" (for Layer-2 or Decorative Elements):
   - "elementId": string (ID of the element, e.g., "element-1", "layer-2").
   - "properties": object (key-value pairs of CSS properties or their equivalents).
   Recognized properties for "modifyElementProperties":
     - Visibility & Display: "visible" (boolean), "display" (string, e.g., "flex"), "opacity" (number 0-1), "zIndex" (number).
     - Sizing (decorative: vmin default; layer-2: % width/height, px padding/border): "width", "height" (string/number).
     - Spacing (decorative: vmin default; layer-2 padding: px): "padding", "marginTop", "marginRight", "marginBottom", "marginLeft" (string/number).
     - Colors & Background: "bgColor"/"backgroundColor" (CSS color), "imageUrl" (URL), "backgroundSize", "backgroundRepeat", "backgroundPosition".
     - Borders (decorative: vmin; layer-2: px): "borderWidth", "borderStyle", "borderColor", "borderRadius" (string/number).
     - Shadows & Filters: "shadow" (string class), "backdropBlur" (string class for layer-2), "blur" (px string/number), "brightness" (number), "contrast" (number), "grayscale" (0-1), "saturate" (number), "sepia" (0-1), "hueRotate" (deg string/number), "invert" (0-1).
     - Transforms: "rotation" (deg string/number), "scale" (number), "translateX"/"translateY" (vmin string/number), "skewX"/"skewY" (deg string/number).
     - Animations: "animationName" (string, e.g., "bounce" - do not add "animate__" prefix, the app will handle it).

2. For "addControl":
   - "parentId": string (ID of the parent element, e.g., "layer-2", "element-1", or a dropped control ID like "dc-row-container-xyz").
   - "controlType": string (e.g., "button", "text-input", "row-container", "column-container", "text-block", "image-element", "text-colors", "ansi-art-viewer", "html-control").
   - "initialProperties": object (optional, key-value pairs for the new control, see "modifyControlProperties" for examples).
   - "placementHint": string (optional, e.g., "inside_most_recent_row-container", "inside_most_recent_column-container"). Use this if parentId is ambiguous from user prompt but clear from recent context. If performing multiple 'addControl' actions where one new control is a parent for another new control in the SAME list of actions, use 'placementHint' to specify this relationship (e.g., 'parentId' for the child would be the parent of the *newly_created_container*, and 'placementHint' would refer to that container type).

3. For "deleteControl":
   - "controlId": string (ID of the dropped control to delete, e.g., "dc-button-xyz").

4. For "modifyControlProperties":
   - "controlId": string (ID of the dropped control to modify).
   - "properties": object (key-value pairs for the control).
   Recognized properties for "modifyControlProperties":
     - Generic: "visible" (boolean), "textContent" (string), "placeholder" (string for inputs), "imageSrc" (URL for images), "width"/"height" (CSS string, e.g., "100px", "50%"), "bgColor"/"backgroundColor" (CSS color), "textColor" (CSS color), "opacity" (0-1).
     - Border: "borderRadius" (px string/number), "borderWidth" (px string/number), "borderStyle" (string), "borderColor" (CSS color).
     - Box Shadow: "boxShadowX", "boxShadowY", "boxShadowBlur" (px string/number), "boxShadowColor" (CSS color).
     - Typography (for text-based controls): "fontFamily", "fontSize" (CSS string), "fontWeight", "fontStyle", "lineHeight" (CSS string/number), "letterSpacing" (CSS string), "textTransform", "textDecoration" (string: none, underline, etc.).
     - Text Shadow: "textShadowX", "textShadowY", "textShadowBlur" (px string/number), "textShadowColor" (CSS color).
     - Text Alignment (textual controls): "textAlignHorizontal" ("left", "center", "right", "justify"), "textAlignVertical" ("flex-start", "center", "flex-end").
     - Container Alignment (container controls): "containerAlignItems" ("flex-start", "center", etc.), "containerJustifyContent" ("flex-start", "center", etc.).
     - TextColors Specific (prefix with "tc"): "tcContent" (text), "tcColor1", "tcColor2" (CSS color), "tcColor1Alpha", "tcColor2Alpha" (0-1), "tcGradientMode" ("word", "phrase"), "tcColor1Fill", "tcGradientAngle", "tcColor2Start" (number 0-100 or 0-360), "tcFontFamily", "tcFontSize" (px string), "tcFontWeight", "tcFontStyle", "tcDecorationUnderline"/"tcDecorationOverline"/"tcDecorationLinethrough" (boolean), "tcTextTransform", "tcLineHeight", "tcLetterSpacing", "tcWordSpacing" (px string), "tcTextAlign", "tcFontVariant".
     - ANSI Art Specific (prefix with "ansi"): "ansiContent" (string), "ansiWidth", "ansiHeight" (CSS string), "ansiBgColor", "ansiTextColor" (CSS color), "ansiBgColorAlpha", "ansiTextColorAlpha" (0-1), "ansiOpacity" (0-1), "ansiBorderRadius", "ansiBorderWidth" (px string), "ansiBorderStyle", "ansiBorderColor", "ansiBoxShadowX/Y/Blur/Color".
     - HTML Box Specific: "htmlContent", "cssContent", "jsContent" (strings).

If the parent for an 'addControl' action is truly ambiguous from the prompt and history, and no clear context helps, return an error action: {"action": "error", "message": "Please specify where to add the control (e.g., its parentId)."}.
If a user asks to modify 'the second column', and you cannot determine the ID of 'the second column' from the history or context, ask for clarification or the specific ID.

Respond ONLY with the JSON (single object or array of objects). Ensure property names in the "properties" object match the examples. If a unit is part of the value (e.g., "10px", "5vmin", "45deg"), include it. For boolean properties, use true or false. For colors, use valid CSS color strings.`;

    const contentsForApi: Array<{ role: string, parts: Array<{text: string}> }> = [];

    // Add history to contents
    for (const interaction of history) {
        contentsForApi.push({ role: "user", parts: [{ text: interaction.user }] });
        contentsForApi.push({ role: "model", parts: [{ text: interaction.aiResponse }] });
    }
    // Add current prompt
    contentsForApi.push({ role: "user", parts: [{ text: prompt }] });

    try {
        const generationParams: GenerateContentParameters = {
            model: 'gemini-2.5-flash-preview-04-17',
            contents: contentsForApi,
            config: {
                systemInstruction: systemInstructionText,
                responseMimeType: "application/json",
                 // thinkingConfig: { thinkingBudget: 0 } // Optional: uncomment for low latency needs
            }
        };

        const response: GenerateContentResponse = await ai.models.generateContent(generationParams);
        
        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);

        if (match && match[2]) {
          jsonStr = match[2].trim();
        }

        try {
            JSON.parse(jsonStr); 
            console.log('[GeminiService] Parsed JSON configuration response:', jsonStr);
            return jsonStr;
        } catch (e) {
            console.warn('[GeminiService] Response was not valid JSON after cleaning, original text:', response.text, 'Cleaned attempt:', jsonStr);
            // Construct a valid JSON error response if parsing fails
            const errorMessage = `AI response was not valid JSON. Raw AI text: ${response.text.replace(/"/g, '\\"')}`;
            return JSON.stringify({ action: "error", message: errorMessage });
        }

    } catch (error) {
        console.error('[GeminiService] Error interpreting configuration prompt:', error);
         if (error instanceof Error && error.message.includes('API key not valid')) {
             throw new Error('Invalid API Key. Please check your Gemini API Key.');
        }
        // Construct a valid JSON error response for service errors
        const serviceErrorMessage = `Failed to interpret configuration: ${error instanceof Error ? error.message : String(error)}`;
        return JSON.stringify({ action: "error", message: serviceErrorMessage.replace(/"/g, '\\"') });
    }
}