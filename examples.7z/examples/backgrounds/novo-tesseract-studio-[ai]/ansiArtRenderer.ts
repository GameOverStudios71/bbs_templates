
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Mapeamento completo CP437 para Unicode
const cp437ToUnicode: Record<number, string> = {
    128: 'Ç', 129: 'ü', 130: 'é', 131: 'â', 132: 'ä', 133: 'à', 134: 'å', 135: 'ç',
    136: 'ê', 137: 'ë', 138: 'è', 139: 'ï', 140: 'î', 141: 'ì', 142: 'Ä', 143: 'Å',
    144: 'É', 145: 'æ', 146: 'Æ', 147: 'ô', 148: 'ö', 149: 'ò', 150: 'û', 151: 'ù',
    152: 'ÿ', 153: 'Ö', 154: 'Ü', 155: '¢', 156: '£', 157: '¥', 158: '₧', 159: 'ƒ',
    160: 'á', 161: 'í', 162: 'ó', 163: 'ú', 164: 'ñ', 165: 'Ñ', 166: 'ª', 167: 'º',
    168: '¿', 169: '⌐', 170: '¬', 171: '½', 172: '¼', 173: '¡', 174: '«', 175: '»',
    176: '░', 177: '▒', 178: '▓', 179: '│', 180: '┤', 181: '╡', 182: '╢', 183: '╖',
    184: '╕', 185: '╣', 186: '║', 187: '╗', 188: '╝', 189: '╜', 190: '╛', 191: '┐',
    192: '└', 193: '┴', 194: '┬', 195: '├', 196: '─', 197: '┼', 198: '╞', 199: '╟',
    200: '╚', 201: '╔', 202: '╩', 203: '╦', 204: '╠', 205: '═', 206: '╬', 207: '╧',
    208: '╨', 209: '╤', 210: '╥', 211: '╙', 212: '╘', 213: '╒', 214: '╓', 215: '╫',
    216: '╪', 217: '┘', 218: '┌', 219: '█', 220: '▄', 221: '▌', 222: '▐', 223: '▀',
    224: 'α', 225: 'ß', 226: 'Γ', 227: 'π', 228: 'Σ', 229: 'σ', 230: 'µ', 231: 'τ',
    232: 'Φ', 233: 'Θ', 234: 'Ω', 235: 'δ', 236: '∞', 237: 'φ', 238: 'ε', 239: '∩',
    240: '≡', 241: '±', 242: '≥', 243: '≤', 244: '⌠', 245: '⌡', 246: '÷', 247: '≈',
    248: '°', 249: '∙', 250: '·', 251: '√', 252: 'ⁿ', 253: '²', 254: '■', 255: ' ' // Non-breaking space for CP437 255
};

const vgaColors: Record<number, string> = {
    30: 'rgb(0, 0, 0)', 31: 'rgb(170, 0, 0)', 32: 'rgb(0, 170, 0)', 33: 'rgb(170, 85, 0)', 
    34: 'rgb(0, 0, 170)', 35: 'rgb(170, 0, 170)', 36: 'rgb(0, 170, 170)', 37: 'rgb(170, 170, 170)',
    40: 'rgb(0, 0, 0)', 41: 'rgb(170, 0, 0)', 42: 'rgb(0, 170, 0)', 43: 'rgb(170, 85, 0)',
    44: 'rgb(0, 0, 170)', 45: 'rgb(170, 0, 170)', 46: 'rgb(0, 170, 170)', 47: 'rgb(170, 170, 170)',
    90: 'rgb(85, 85, 85)', 91: 'rgb(255, 85, 85)', 92: 'rgb(85, 255, 85)', 93: 'rgb(255, 255, 85)',
    94: 'rgb(85, 85, 255)', 95: 'rgb(255, 85, 255)', 96: 'rgb(85, 255, 255)', 97: 'rgb(255, 255, 255)',
    100: 'rgb(85, 85, 85)', 101: 'rgb(255, 85, 85)', 102: 'rgb(85, 255, 85)', 103: 'rgb(255, 255, 85)',
    104: 'rgb(85, 85, 255)', 105: 'rgb(255, 85, 255)', 106: 'rgb(85, 255, 255)', 107: 'rgb(255, 255, 255)'
};

function convertCP437ToUnicode(text: string): string {
    let result = '';
    for (let i = 0; i < text.length; i++) {
        const charCode = text.charCodeAt(i);
        if (charCode >= 128 && charCode <= 255 && cp437ToUnicode[charCode]) {
            result += cp437ToUnicode[charCode];
        } else if (charCode < 32 && charCode !== 10 && charCode !== 13 && charCode !== 9 && charCode !== 27) { // Filter out most control chars except LF, CR, TAB, ESC
            // Optionally replace with a placeholder or skip
        }
         else {
            result += text.charAt(i);
        }
    }
    return result;
}

function hasAnsiCodes(text: string): boolean {
    return text ? /\x1b\[[0-9;]*[a-zA-Z]/.test(text) : false;
}

class AnsiProcessor {
    foreground = 37;
    background = 40;
    bold = false;
    italic = false;
    underline = false;
    blink = false;
    inverse = false;
    conceal = false;
    strikethrough = false;

    reset() {
        this.foreground = 37; this.background = 40; this.bold = false; this.italic = false;
        this.underline = false; this.blink = false; this.inverse = false; this.conceal = false;
        this.strikethrough = false;
    }

    processSGR(codes: string) {
        if (!codes || codes === '') codes = '0';
        const codeArray = codes.split(';').map(c => parseInt(c) || 0);

        for (const code of codeArray) {
            if (code === 0) this.reset();
            else if (code === 1) this.bold = true;
            else if (code === 3) this.italic = true;
            else if (code === 4) this.underline = true;
            else if (code === 5 || code === 6) this.blink = true;
            else if (code === 7) this.inverse = true;
            else if (code === 8) this.conceal = true;
            else if (code === 9) this.strikethrough = true;
            else if (code === 22) this.bold = false;
            else if (code === 23) this.italic = false;
            else if (code === 24) this.underline = false;
            else if (code === 25) this.blink = false;
            else if (code === 27) this.inverse = false;
            else if (code === 28) this.conceal = false;
            else if (code === 29) this.strikethrough = false;
            else if (code >= 30 && code <= 37) this.foreground = code;
            else if (code === 39) this.foreground = 37;
            else if (code >= 40 && code <= 47) this.background = code;
            else if (code === 49) this.background = 40;
            else if (code >= 90 && code <= 97) this.foreground = code;
            else if (code >= 100 && code <= 107) this.background = code;
        }
    }

    generateCSS(): string {
        const styles: string[] = [];
        let fg = this.foreground, bg = this.background;
        if (this.inverse) { [fg, bg] = [bg, fg]; }

        if (vgaColors[fg]) styles.push(`color: ${vgaColors[fg]}`);
        if (bg !== 40 && vgaColors[bg]) styles.push(`background-color: ${vgaColors[bg]}`);
        
        if (this.bold) styles.push('font-weight: bold');
        if (this.italic) styles.push('font-style: italic');
        if (this.underline) styles.push('text-decoration: underline');
        if (this.strikethrough) styles.push('text-decoration: line-through');
        if (this.blink) styles.push('animation: blink 1s steps(1, end) infinite');
        if (this.conceal) styles.push('opacity: 0');
        return styles.join('; ');
    }
}

class AnsiScreen {
    width: number;
    height: number;
    cursorX = 0;
    cursorY = 0;
    savedCursorX = 0;
    savedCursorY = 0;
    processor = new AnsiProcessor();
    screen: { char: string; style: string }[][] = [];

    constructor(width = 80, height = 25) {
        this.width = width;
        this.height = height;
        this.initScreen();
    }

    initScreen() {
        this.screen = [];
        for (let y = 0; y < this.height; y++) {
            this.screen[y] = [];
            for (let x = 0; x < this.width; x++) {
                this.screen[y][x] = { char: ' ', style: this.processor.generateCSS() };
            }
        }
    }
    
    ensureRowExists(y: number) {
        while (y >= this.screen.length) {
            const newRow = [];
            for (let x = 0; x < this.width; x++) {
                newRow.push({ char: ' ', style: '' });
            }
            this.screen.push(newRow);
        }
    }
    
    ensureCellExists(y: number, x: number) {
        this.ensureRowExists(y);
        while (x >= this.screen[y].length) {
            this.screen[y].push({ char: ' ', style: '' });
        }
         // Update overall width if this cell expands it
        if (x >= this.width) {
            const oldWidth = this.width;
            this.width = x + 1;
            for (let r = 0; r < this.screen.length; r++) {
                for (let fillX = oldWidth; fillX < this.width; fillX++) {
                    if(this.screen[r][fillX] === undefined) this.screen[r][fillX] = { char: ' ', style: ''};
                }
            }
        }
    }


    moveCursor(x: number, y: number) { this.cursorX = Math.max(0, x); this.cursorY = Math.max(0, y); }
    saveCursor() { this.savedCursorX = this.cursorX; this.savedCursorY = this.cursorY; }
    restoreCursor() { this.cursorX = this.savedCursorX; this.cursorY = this.savedCursorY; }

    writeChar(char: string) {
        if (char === '\n') { this.cursorX = 0; this.cursorY++; return; }
        if (char === '\r') { this.cursorX = 0; return; }

        if (this.cursorX >= this.width) { // Auto-wrap
            this.cursorX = 0;
            this.cursorY++;
        }
        this.ensureCellExists(this.cursorY, this.cursorX);
        this.screen[this.cursorY][this.cursorX] = { char: char, style: this.processor.generateCSS() };
        this.cursorX++;
    }

    clearScreen(mode: number) {
        if (mode === 2) { // Clear entire screen and home cursor
            this.initScreen();
            this.moveCursor(0,0);
        } else if (mode === 0) { // Clear from cursor to end of screen
            for (let y = this.cursorY; y < this.screen.length; y++) {
                for (let x = (y === this.cursorY ? this.cursorX : 0); x < this.width; x++) {
                     if(this.screen[y]?.[x]) this.screen[y][x] = { char: ' ', style: this.processor.generateCSS() };
                }
            }
        } // Other modes (1, 3) can be added if needed
    }

    clearLine(mode: number) {
        this.ensureRowExists(this.cursorY);
        if (mode === 0) { // Clear from cursor to end of line
            for (let x = this.cursorX; x < this.width; x++) {
                if(this.screen[this.cursorY]?.[x]) this.screen[this.cursorY][x] = { char: ' ', style: this.processor.generateCSS() };
            }
        } else if (mode === 1) { // Clear from start of line to cursor
             for (let x = 0; x <= this.cursorX; x++) {
                if(this.screen[this.cursorY]?.[x]) this.screen[this.cursorY][x] = { char: ' ', style: this.processor.generateCSS() };
            }
        } else if (mode === 2) { // Clear entire line
            for (let x = 0; x < this.width; x++) {
                 if(this.screen[this.cursorY]?.[x]) this.screen[this.cursorY][x] = { char: ' ', style: this.processor.generateCSS() };
            }
        }
    }


    toHTML(): string {
        let html = '';
        for (let y = 0; y < this.screen.length; y++) {
            if (!this.screen[y] || this.screen[y].every(cell => cell.char === ' ' && !cell.style)) continue; // Skip empty rows quickly

            html += `<div class="ansi-row">`;
            let currentStyle = '';
            let spanOpen = false;
            let lineContent = '';

            for (let x = 0; x < this.screen[y].length; x++) {
                const cell = this.screen[y][x] || { char: ' ', style: '' };
                const charToRender = cell.char === ' ' ? '&nbsp;' : (cell.char.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'));

                if (cell.style !== currentStyle) {
                    if (spanOpen) lineContent += '</span>';
                    if (cell.style) {
                        lineContent += `<span style="${cell.style}">`;
                        spanOpen = true;
                    } else {
                        spanOpen = false; // Ensure span is closed if current cell has no style
                    }
                    currentStyle = cell.style;
                }
                lineContent += charToRender;
            }
            if (spanOpen) lineContent += '</span>';
            if (lineContent.trim() === '' || lineContent.replace(/&nbsp;/g, '').trim() === '') lineContent = '&nbsp;'; // Ensure non-empty row if it had styles
            html += lineContent + '</div>';
        }
        return html;
    }
}

export function renderAnsiToHtml(rawAnsiText: string): string {
    if (!rawAnsiText) return '';
    const text = convertCP437ToUnicode(rawAnsiText);

    const lines = text.split(/\r?\n/);
    let autoWidth = 80;
    lines.forEach(line => { autoWidth = Math.max(autoWidth, line.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, '').length); });
    autoWidth = Math.min(autoWidth + 5, 250); // Cap width for performance/layout

    const screen = new AnsiScreen(autoWidth, Math.max(25, lines.length + 5));
    let i = 0;

    while (i < text.length) {
        if (text[i] === '\x1b' && text[i + 1] === '[') {
            let j = i + 2;
            let codes = '';
            while (j < text.length && !/[a-zA-Z]/.test(text[j])) { codes += text[j]; j++; }
            const command = text[j];

            if (command === 'm') screen.processor.processSGR(codes);
            else if (command === 'H' || command === 'f') {
                const params = codes.split(';').map(p => parseInt(p) || 1);
                screen.moveCursor((params[1] || 1) - 1, (params[0] || 1) - 1);
            } else if (command === 'A') screen.moveCursor(screen.cursorX, screen.cursorY - (parseInt(codes) || 1));
            else if (command === 'B') screen.moveCursor(screen.cursorX, screen.cursorY + (parseInt(codes) || 1));
            else if (command === 'C') screen.moveCursor(screen.cursorX + (parseInt(codes) || 1), screen.cursorY);
            else if (command === 'D') screen.moveCursor(screen.cursorX - (parseInt(codes) || 1), screen.cursorY);
            else if (command === 'J') screen.clearScreen(parseInt(codes) || 0);
            else if (command === 'K') screen.clearLine(parseInt(codes) || 0);
            else if (command === 's') screen.saveCursor();
            else if (command === 'u') screen.restoreCursor();
            i = j + 1;
        } else if (text[i].charCodeAt(0) === 26) { // EOF for some DOS files
            break;
        }
         else {
            screen.writeChar(text[i]);
            i++;
        }
    }
    return screen.toHTML();
}

export function hasAnsi(text: string): boolean {
    return hasAnsiCodes(text);
}
