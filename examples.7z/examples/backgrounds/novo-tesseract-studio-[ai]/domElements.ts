

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Config Panel Elements
export let configPanel: HTMLElement | null = null;
export let configPanelToggleButton: HTMLButtonElement | null = null;
export let configPanelCloseButton: HTMLButtonElement | null = null;
export let configPanelCollapseButton: HTMLButtonElement | null = null;
export let configPanelHeader: HTMLElement | null = null;
export let configPanelBody: HTMLElement | null = null; 
export let configPanelResizeHandle: HTMLElement | null = null;

// Tab Buttons
export let tabButtonGlobals: HTMLButtonElement | null = null;
export let tabButtonElement: HTMLButtonElement | null = null;
export let tabButtonAnimations: HTMLButtonElement | null = null; 
export let tabButtonControls: HTMLButtonElement | null = null;
// export let tabButtonComponents: HTMLButtonElement | null = null; // Removed
export let tabButtonPresets: HTMLButtonElement | null = null;
export let tabButtonAi: HTMLButtonElement | null = null; // New AI Tab Button

// Tab Content Panes
export let tabContentGlobals: HTMLElement | null = null;
export let tabContentElement: HTMLElement | null = null;
export let tabContentAnimations: HTMLElement | null = null; 
export let tabContentControls: HTMLElement | null = null;
// export let tabContentComponents: HTMLElement | null = null; // Removed
export let tabContentPresets: HTMLElement | null = null;
export let tabContentAi: HTMLElement | null = null; // New AI Tab Content Pane
export let tabContentAreaContainer: HTMLElement | null = null; // The div.flex-grow

// Element Tab - General
export let selectedElementNameDisplay: HTMLElement | null = null;
export let decorativeElementVisibilityControls: HTMLElement | null = null; // Container for visibility toggles
export let decorativeElementVisibilityToggles: NodeListOf<HTMLButtonElement> | null = null; // The toggle buttons themselves
export let decorativeElementPropsSection: HTMLElement | null = null;
export let noElementSelectedMsg: HTMLElement | null = null; // For Element Tab

// Controls Tab - Specific sections to be MOVED here visually
export let controlPropertiesContainer: HTMLElement | null = null; // New container in Controls Tab
export let selectedControlNameControlsTabDisplay: HTMLElement | null = null; // Displays selected control name in Controls Tab
export let noControlSelectedMsgControlsTab: HTMLElement | null = null; // For Controls Tab properties area
export let droppedControlPropsSection: HTMLElement | null = null;
export let textColorsPropsSection: HTMLElement | null = null;
export let ansiArtPropsSection: HTMLElement | null = null;
export let htmlControlPropsSection: HTMLElement | null = null; // New for HTML Control
// controlsContainer might be unused or misnamed from original plan; selected-element-controls-container seems to be its ID.

// Decorative Element Inputs
export let visibleInput: HTMLInputElement | null = null;
export let elDisplaySelect: HTMLSelectElement | null = null;
export let elZIndexInput: HTMLInputElement | null = null;
export let elOverflowXSelect: HTMLSelectElement | null = null;
export let elOverflowYSelect: HTMLSelectElement | null = null;
export let widthInput: HTMLInputElement | null = null;
export let heightInput: HTMLInputElement | null = null;
export let marginTopInput: HTMLInputElement | null = null;
export let marginRightInput: HTMLInputElement | null = null;
export let marginBottomInput: HTMLInputElement | null = null;
export let marginLeftInput: HTMLInputElement | null = null;
export let bgColorInput: HTMLInputElement | null = null;
export let bgColorAlphaSlider: HTMLInputElement | null = null;
export let bgColorAlphaValueDisplay: HTMLElement | null = null;
export let imageUrlInput: HTMLInputElement | null = null;
export let bgSizeSelect: HTMLSelectElement | null = null;
export let elBgRepeatSelect: HTMLSelectElement | null = null;
export let elBgPositionInput: HTMLInputElement | null = null;
export let shadowSelect: HTMLSelectElement | null = null;
export let opacityInput: HTMLInputElement | null = null;
export let opacityValueDisplay: HTMLElement | null = null;
export let elBlurInput: HTMLInputElement | null = null; 
export let elBlurValueDisplay: HTMLElement | null = null; 
export let elBrightnessInput: HTMLInputElement | null = null;
export let elBrightnessValueDisplay: HTMLElement | null = null;
export let elContrastInput: HTMLInputElement | null = null;
export let elContrastValueDisplay: HTMLElement | null = null;
export let elSaturateInput: HTMLInputElement | null = null;
export let elSaturateValueDisplay: HTMLElement | null = null;
export let elGrayscaleInput: HTMLInputElement | null = null;
export let elGrayscaleValueDisplay: HTMLElement | null = null;
export let elSepiaInput: HTMLInputElement | null = null;
export let elSepiaValueDisplay: HTMLElement | null = null;
export let elInvertInput: HTMLInputElement | null = null;
export let elInvertValueDisplay: HTMLElement | null = null;
export let elHueRotateInput: HTMLInputElement | null = null;
export let elHueRotateValueDisplay: HTMLElement | null = null;
export let elBorderWidthInput: HTMLInputElement | null = null;
export let elBorderStyleSelect: HTMLSelectElement | null = null;
export let elBorderColorInput: HTMLInputElement | null = null;
export let elBorderColorAlphaSlider: HTMLInputElement | null = null;
export let elBorderColorAlphaValueDisplay: HTMLElement | null = null;
export let elBorderRadiusInput: HTMLInputElement | null = null;
export let elRotationInput: HTMLInputElement | null = null;
export let elRotationValueDisplay: HTMLElement | null = null;
export let elScaleInput: HTMLInputElement | null = null;
export let elScaleValueDisplay: HTMLElement | null = null;
export let elTranslateXInput: HTMLInputElement | null = null;
export let elTranslateYInput: HTMLInputElement | null = null;
export let elSkewXInput: HTMLInputElement | null = null;
export let elSkewYInput: HTMLInputElement | null = null;

// Dropped Control Inputs
export let droppedControlVisibleInput: HTMLInputElement | null = null;
export let droppedControlTextContentInput: HTMLTextAreaElement | null = null;
export let droppedControlPlaceholderInput: HTMLInputElement | null = null;
export let droppedControlImageSrcInput: HTMLInputElement | null = null;
export let droppedControlWidthInput: HTMLInputElement | null = null;
export let droppedControlHeightInput: HTMLInputElement | null = null;
export let droppedControlBgColorInput: HTMLInputElement | null = null;
export let droppedControlBgColorAlphaSlider: HTMLInputElement | null = null;
export let droppedControlBgColorAlphaValueDisplay: HTMLElement | null = null;
export let droppedControlTextColorInput: HTMLInputElement | null = null;
export let droppedControlTextColorAlphaSlider: HTMLInputElement | null = null;
export let droppedControlTextColorAlphaValueDisplay: HTMLElement | null = null;
export let droppedControlOpacityInput: HTMLInputElement | null = null;
export let droppedControlOpacityValueDisplay: HTMLElement | null = null;
export let droppedControlBorderRadiusInput: HTMLInputElement | null = null;
export let droppedControlBorderWidthInput: HTMLInputElement | null = null;
export let droppedControlBorderStyleSelect: HTMLSelectElement | null = null;
export let droppedControlBorderColorInput: HTMLInputElement | null = null;
export let droppedControlBorderColorAlphaSlider: HTMLInputElement | null = null;
export let droppedControlBorderColorAlphaValueDisplay: HTMLElement | null = null;
export let droppedControlBoxShadowXInput: HTMLInputElement | null = null;
export let droppedControlBoxShadowYInput: HTMLInputElement | null = null;
export let droppedControlBoxShadowBlurInput: HTMLInputElement | null = null;
export let droppedControlBoxShadowColorInput: HTMLInputElement | null = null;
export let droppedControlBoxShadowColorAlphaSlider: HTMLInputElement | null = null;
export let droppedControlBoxShadowColorAlphaValueDisplay: HTMLElement | null = null;
export let deleteControlBtn: HTMLButtonElement | null = null;

// Dropped Control Typography Section & Inputs
export let droppedControlTypographySection: HTMLElement | null = null;
export let droppedControlFontFamilyInput: HTMLInputElement | null = null;
export let droppedControlFontSizeInput: HTMLInputElement | null = null;
export let droppedControlFontWeightSelect: HTMLSelectElement | null = null;
export let droppedControlFontStyleSelect: HTMLSelectElement | null = null;
export let droppedControlLineHeightInput: HTMLInputElement | null = null;
export let droppedControlLetterSpacingInput: HTMLInputElement | null = null;
export let droppedControlTextTransformSelect: HTMLSelectElement | null = null;
export let droppedControlTextDecorationSelect: HTMLSelectElement | null = null;
export let droppedControlTextShadowXInput: HTMLInputElement | null = null;
export let droppedControlTextShadowYInput: HTMLInputElement | null = null;
export let droppedControlTextShadowBlurInput: HTMLInputElement | null = null;
export let droppedControlTextShadowColorInput: HTMLInputElement | null = null;
export let droppedControlTextShadowColorAlphaSlider: HTMLInputElement | null = null;
export let droppedControlTextShadowColorAlphaValueDisplay: HTMLElement | null = null;

// Text Alignment Controls (for dropped textual controls)
export let textAlignmentControlsContainer: HTMLElement | null = null;
export let textAlignHorizontalSelect: HTMLSelectElement | null = null;
export let textAlignVerticalSelect: HTMLSelectElement | null = null;

// Container Alignment Controls (for dropped container controls)
export let containerAlignmentControlsContainer: HTMLElement | null = null;
export let containerAlignItemsSelect: HTMLSelectElement | null = null;
export let containerJustifyContentSelect: HTMLSelectElement | null = null;

// TextColors Component Inputs (New Advanced Controls)
export let textColorsContentInput: HTMLTextAreaElement | null = null;
export let textColorsColor1Picker: HTMLInputElement | null = null;
export let textColorsColor1AlphaSlider: HTMLInputElement | null = null;
export let textColorsColor1AlphaValueDisplay: HTMLElement | null = null;
export let textColorsColor2Picker: HTMLInputElement | null = null;
export let textColorsColor2AlphaSlider: HTMLInputElement | null = null;
export let textColorsColor2AlphaValueDisplay: HTMLElement | null = null;
export let textColorsGradientModeSelect: HTMLSelectElement | null = null;
export let textColorsColor1FillSlider: HTMLInputElement | null = null;
export let textColorsColor1FillValue: HTMLSpanElement | null = null;
export let textColorsGradientAngleSlider: HTMLInputElement | null = null;
export let textColorsGradientAngleValue: HTMLSpanElement | null = null;
export let textColorsColor2StartSlider: HTMLInputElement | null = null;
export let textColorsColor2StartValue: HTMLSpanElement | null = null;
export let textColorsFontFamilySelect: HTMLSelectElement | null = null;
export let textColorsFontSizeInput: HTMLInputElement | null = null;
export let textColorsFontWeightSelect: HTMLSelectElement | null = null;
export let textColorsFontStyleSelect: HTMLSelectElement | null = null;
export let textColorsDecorationUnderline: HTMLInputElement | null = null;
export let textColorsDecorationOverline: HTMLInputElement | null = null;
export let textColorsDecorationLinethrough: HTMLInputElement | null = null;
export let textColorsTextTransformSelect: HTMLSelectElement | null = null;
export let textColorsLineHeightInput: HTMLInputElement | null = null;
export let textColorsLetterSpacingInput: HTMLInputElement | null = null;
export let textColorsWordSpacingInput: HTMLInputElement | null = null;
export let textColorsTextAlignSelect: HTMLSelectElement | null = null;
export let textColorsFontVariantSelect: HTMLSelectElement | null = null;
export let deleteTextColorsControlBtn: HTMLButtonElement | null = null;


// ANSI/ASCII Art Component Inputs
export let ansiArtVisibleInput: HTMLInputElement | null = null;
export let ansiArtContentInput: HTMLTextAreaElement | null = null;
export let ansiArtWidthInput: HTMLInputElement | null = null;
export let ansiArtHeightInput: HTMLInputElement | null = null;
export let ansiArtBgColorInput: HTMLInputElement | null = null;
export let ansiArtBgColorAlphaSlider: HTMLInputElement | null = null;
export let ansiArtBgColorAlphaValueDisplay: HTMLElement | null = null;
export let ansiArtTextColorInput: HTMLInputElement | null = null;
export let ansiArtTextColorAlphaSlider: HTMLInputElement | null = null;
export let ansiArtTextColorAlphaValueDisplay: HTMLElement | null = null;
export let ansiArtOpacityInput: HTMLInputElement | null = null;
export let ansiArtOpacityValueDisplay: HTMLElement | null = null;
export let ansiArtBorderRadiusInput: HTMLInputElement | null = null;
export let ansiArtBorderWidthInput: HTMLInputElement | null = null;
export let ansiArtBorderStyleSelect: HTMLSelectElement | null = null;
export let ansiArtBorderColorInput: HTMLInputElement | null = null;
export let ansiArtBorderColorAlphaSlider: HTMLInputElement | null = null;
export let ansiArtBorderColorAlphaValueDisplay: HTMLElement | null = null;
export let ansiArtBoxShadowXInput: HTMLInputElement | null = null;
export let ansiArtBoxShadowYInput: HTMLInputElement | null = null;
export let ansiArtBoxShadowBlurInput: HTMLInputElement | null = null;
export let ansiArtBoxShadowColorInput: HTMLInputElement | null = null;
export let ansiArtBoxShadowColorAlphaSlider: HTMLInputElement | null = null;
export let ansiArtBoxShadowColorAlphaValueDisplay: HTMLElement | null = null;
export let deleteAnsiArtBtn: HTMLButtonElement | null = null;

// HTML Control Inputs
export let htmlControlHtmlContentInput: HTMLTextAreaElement | null = null;
export let htmlControlCssContentInput: HTMLTextAreaElement | null = null;
export let htmlControlJsContentInput: HTMLTextAreaElement | null = null;
export let applyHtmlControlCodeBtn: HTMLButtonElement | null = null;
export let deleteHtmlControlBtn: HTMLButtonElement | null = null;


// Layer 2 (Globals Tab) Inputs
export let layer2Element: HTMLElement | null = null; // Main layer-2 div itself
export let layer2VisibleInput: HTMLInputElement | null = null;
export let layer2WidthInput: HTMLInputElement | null = null;
export let layer2HeightInput: HTMLInputElement | null = null;
export let layer2PaddingInput: HTMLInputElement | null = null;
export let layer2BgColorInput: HTMLInputElement | null = null;
export let layer2BgColorAlphaSlider: HTMLInputElement | null = null;
export let layer2BgColorAlphaValueDisplay: HTMLElement | null = null;
export let layer2BorderWidthInput: HTMLInputElement | null = null;
export let layer2BorderColorInput: HTMLInputElement | null = null;
export let layer2BorderColorAlphaSlider: HTMLInputElement | null = null;
export let layer2BorderColorAlphaValueDisplay: HTMLElement | null = null;
export let layer2ShadowSelect: HTMLSelectElement | null = null;
export let layer2BackdropBlurSelect: HTMLSelectElement | null = null; 

// Animation Tab
export let animationSelectedElementNameDisplay: HTMLElement | null = null;
export let animationControlsContainer: HTMLElement | null = null;
export let noElementSelectedAnimationMsg: HTMLElement | null = null;
export let animationNameSelect: HTMLSelectElement | null = null;
export let animationIterationSelect: HTMLSelectElement | null = null;
export let animationDelaySelect: HTMLSelectElement | null = null;
export let animationSpeedSelect: HTMLSelectElement | null = null;
export let playAnimationButton: HTMLButtonElement | null = null;
export let animationOnHoverCheckbox: HTMLInputElement | null = null; 

// Controls Tab (Palette)
export let controlPaletteItems: NodeListOf<HTMLElement> | null = null;

// Presets Tab
export let savePresetButton: HTMLButtonElement | null = null;
export let presetsListContainer: HTMLElement | null = null;
export let noPresetsMessage: HTMLElement | null = null;

// AI Assistant Tab
export let aiApiKeyInput: HTMLInputElement | null = null;
export let aiPromptTextarea: HTMLTextAreaElement | null = null;
export let aiSendPromptButton: HTMLButtonElement | null = null;
export let aiLoadingIndicator: HTMLElement | null = null;
export let aiMessageArea: HTMLElement | null = null;
// export let aiImageResultArea: HTMLElement | null = null; // Removed
// export let aiGeneratedImage: HTMLImageElement | null = null; // Removed
export let aiActionGenerateImageRadio: HTMLInputElement | null = null;
export let aiActionModifyConfigRadio: HTMLInputElement | null = null;
export let aiPromptHistoryContainer: HTMLElement | null = null;
export let aiPromptHistoryEmptyMsg: HTMLElement | null = null;
export let aiApplyImageBgButton: HTMLButtonElement | null = null;

// AI Image Preview Modal
export let aiImagePreviewModal: HTMLElement | null = null;
export let aiModalImage: HTMLImageElement | null = null;
export let aiModalCloseButton: HTMLButtonElement | null = null;

// AI Transparency Controls
export let aiTransparencyControlsSection: HTMLElement | null = null;
export let aiTransparencyColorPicker: HTMLInputElement | null = null;
export let aiTransparencyToleranceSlider: HTMLInputElement | null = null;
export let aiTransparencyToleranceValue: HTMLElement | null = null;
export let aiReprocessTransparencyButton: HTMLButtonElement | null = null;


export function initializeDomElements() {
    configPanel = document.getElementById('config-panel');
    configPanelToggleButton = document.getElementById('toggle-config-panel-btn') as HTMLButtonElement;
    configPanelCloseButton = document.getElementById('config-panel-close-btn') as HTMLButtonElement;
    configPanelCollapseButton = document.getElementById('config-panel-collapse-btn') as HTMLButtonElement;
    configPanelHeader = document.getElementById('config-panel-header');
    configPanelBody = document.getElementById('config-panel-body');
    configPanelResizeHandle = document.getElementById('config-panel-resize-handle');

    tabButtonGlobals = document.getElementById('tab-btn-globals') as HTMLButtonElement;
    tabButtonElement = document.getElementById('tab-btn-element') as HTMLButtonElement;
    tabButtonControls = document.getElementById('tab-btn-controls') as HTMLButtonElement; 
    tabButtonAnimations = document.getElementById('tab-btn-animations') as HTMLButtonElement;
    // tabButtonComponents = document.getElementById('tab-btn-components') as HTMLButtonElement; // Removed
    tabButtonPresets = document.getElementById('tab-btn-presets') as HTMLButtonElement;
    tabButtonAi = document.getElementById('tab-btn-ai') as HTMLButtonElement; // New

    tabContentGlobals = document.getElementById('global-settings-tab-content');
    tabContentElement = document.getElementById('element-settings-tab-content');
    tabContentControls = document.getElementById('controls-tab-content'); 
    tabContentAnimations = document.getElementById('animations-tab-content');
    // tabContentComponents = document.getElementById('components-tab-content'); // Removed
    tabContentPresets = document.getElementById('presets-tab-content');
    tabContentAi = document.getElementById('ai-assistant-tab-content'); // New
    if (configPanelBody) {
        tabContentAreaContainer = configPanelBody.querySelector('.flex-grow');
    }


    decorativeElementVisibilityControls = document.getElementById('decorative-elements-visibility-controls');
    if (decorativeElementVisibilityControls) {
        decorativeElementVisibilityToggles = decorativeElementVisibilityControls.querySelectorAll('.visibility-toggle-btn');
    }
    
    // Element Tab
    selectedElementNameDisplay = document.getElementById('selected-element-name');
    decorativeElementPropsSection = document.getElementById('decorative-element-props-section');
    noElementSelectedMsg = document.getElementById('no-element-selected-msg');

    // Controls Tab
    controlPropertiesContainer = document.getElementById('control-properties-container');
    selectedControlNameControlsTabDisplay = document.getElementById('selected-control-name-controls-tab');
    noControlSelectedMsgControlsTab = document.getElementById('no-control-selected-msg-controls-tab');
    droppedControlPropsSection = document.getElementById('dropped-control-props-section');
    textColorsPropsSection = document.getElementById('text-colors-props-section');
    ansiArtPropsSection = document.getElementById('ansi-art-props-section');
    htmlControlPropsSection = document.getElementById('html-control-props-section');


    visibleInput = document.getElementById('config-visible') as HTMLInputElement;
    elDisplaySelect = document.getElementById('config-el-display') as HTMLSelectElement;
    elZIndexInput = document.getElementById('config-el-zindex') as HTMLInputElement;
    elOverflowXSelect = document.getElementById('config-el-overflow-x') as HTMLSelectElement;
    elOverflowYSelect = document.getElementById('config-el-overflow-y') as HTMLSelectElement;
    widthInput = document.getElementById('config-width') as HTMLInputElement;
    heightInput = document.getElementById('config-height') as HTMLInputElement;
    marginTopInput = document.getElementById('config-margin-top') as HTMLInputElement;
    marginRightInput = document.getElementById('config-margin-right') as HTMLInputElement;
    marginBottomInput = document.getElementById('config-margin-bottom') as HTMLInputElement;
    marginLeftInput = document.getElementById('config-margin-left') as HTMLInputElement;
    bgColorInput = document.getElementById('config-bgcolor') as HTMLInputElement;
    bgColorAlphaSlider = document.getElementById('config-bgcolor-alpha') as HTMLInputElement;
    bgColorAlphaValueDisplay = document.getElementById('config-bgcolor-alpha-value');
    imageUrlInput = document.getElementById('config-image-url') as HTMLInputElement;
    bgSizeSelect = document.getElementById('config-bg-size') as HTMLSelectElement;
    elBgRepeatSelect = document.getElementById('config-el-bg-repeat') as HTMLSelectElement;
    elBgPositionInput = document.getElementById('config-el-bg-position') as HTMLInputElement;
    shadowSelect = document.getElementById('config-shadow') as HTMLSelectElement;
    opacityInput = document.getElementById('config-opacity') as HTMLInputElement;
    opacityValueDisplay = document.getElementById('config-opacity-value');
    elBlurInput = document.getElementById('config-blur') as HTMLInputElement;
    elBlurValueDisplay = document.getElementById('config-blur-value');
    elBrightnessInput = document.getElementById('config-el-brightness') as HTMLInputElement;
    elBrightnessValueDisplay = document.getElementById('config-el-brightness-value');
    elContrastInput = document.getElementById('config-el-contrast') as HTMLInputElement;
    elContrastValueDisplay = document.getElementById('config-el-contrast-value');
    elSaturateInput = document.getElementById('config-el-saturate') as HTMLInputElement;
    elSaturateValueDisplay = document.getElementById('config-el-saturate-value');
    elGrayscaleInput = document.getElementById('config-el-grayscale') as HTMLInputElement;
    elGrayscaleValueDisplay = document.getElementById('config-el-grayscale-value');
    elSepiaInput = document.getElementById('config-el-sepia') as HTMLInputElement;
    elSepiaValueDisplay = document.getElementById('config-el-sepia-value');
    elInvertInput = document.getElementById('config-el-invert') as HTMLInputElement;
    elInvertValueDisplay = document.getElementById('config-el-invert-value');
    elHueRotateInput = document.getElementById('config-el-hue-rotate') as HTMLInputElement;
    elHueRotateValueDisplay = document.getElementById('config-el-hue-rotate-value');
    elBorderWidthInput = document.getElementById('config-border-width-el') as HTMLInputElement;
    elBorderStyleSelect = document.getElementById('config-border-style-el') as HTMLSelectElement;
    elBorderColorInput = document.getElementById('config-border-color-el') as HTMLInputElement;
    elBorderColorAlphaSlider = document.getElementById('config-border-color-el-alpha') as HTMLInputElement;
    elBorderColorAlphaValueDisplay = document.getElementById('config-border-color-el-alpha-value');
    elBorderRadiusInput = document.getElementById('config-border-radius') as HTMLInputElement;
    elRotationInput = document.getElementById('config-rotation') as HTMLInputElement;
    elRotationValueDisplay = document.getElementById('config-rotation-value');
    elScaleInput = document.getElementById('config-el-scale') as HTMLInputElement;
    elScaleValueDisplay = document.getElementById('config-el-scale-value');
    elTranslateXInput = document.getElementById('config-el-translate-x') as HTMLInputElement;
    elTranslateYInput = document.getElementById('config-el-translate-y') as HTMLInputElement;
    elSkewXInput = document.getElementById('config-el-skew-x') as HTMLInputElement;
    elSkewYInput = document.getElementById('config-el-skew-y') as HTMLInputElement;
    
    droppedControlVisibleInput = document.getElementById('dropped-control-visible') as HTMLInputElement;
    droppedControlTextContentInput = document.getElementById('dropped-control-text-content') as HTMLTextAreaElement;
    droppedControlPlaceholderInput = document.getElementById('dropped-control-placeholder') as HTMLInputElement;
    droppedControlImageSrcInput = document.getElementById('dropped-control-image-src') as HTMLInputElement;
    droppedControlWidthInput = document.getElementById('dropped-control-width') as HTMLInputElement;
    droppedControlHeightInput = document.getElementById('dropped-control-height') as HTMLInputElement;
    droppedControlBgColorInput = document.getElementById('dropped-control-bgcolor') as HTMLInputElement;
    droppedControlBgColorAlphaSlider = document.getElementById('dropped-control-bgcolor-alpha') as HTMLInputElement;
    droppedControlBgColorAlphaValueDisplay = document.getElementById('dropped-control-bgcolor-alpha-value');
    droppedControlTextColorInput = document.getElementById('dropped-control-textcolor') as HTMLInputElement;
    droppedControlTextColorAlphaSlider = document.getElementById('dropped-control-textcolor-alpha') as HTMLInputElement;
    droppedControlTextColorAlphaValueDisplay = document.getElementById('dropped-control-textcolor-alpha-value');
    droppedControlOpacityInput = document.getElementById('dropped-control-opacity') as HTMLInputElement;
    droppedControlOpacityValueDisplay = document.getElementById('dropped-control-opacity-value');
    droppedControlBorderRadiusInput = document.getElementById('dropped-control-border-radius') as HTMLInputElement;
    droppedControlBorderWidthInput = document.getElementById('dropped-control-border-width') as HTMLInputElement;
    droppedControlBorderStyleSelect = document.getElementById('dropped-control-border-style') as HTMLSelectElement;
    droppedControlBorderColorInput = document.getElementById('dropped-control-border-color') as HTMLInputElement;
    droppedControlBorderColorAlphaSlider = document.getElementById('dropped-control-border-color-alpha') as HTMLInputElement;
    droppedControlBorderColorAlphaValueDisplay = document.getElementById('dropped-control-border-color-alpha-value');
    droppedControlBoxShadowXInput = document.getElementById('dropped-control-boxshadow-x') as HTMLInputElement;
    droppedControlBoxShadowYInput = document.getElementById('dropped-control-boxshadow-y') as HTMLInputElement;
    droppedControlBoxShadowBlurInput = document.getElementById('dropped-control-boxshadow-blur') as HTMLInputElement;
    droppedControlBoxShadowColorInput = document.getElementById('dropped-control-boxshadow-color') as HTMLInputElement;
    droppedControlBoxShadowColorAlphaSlider = document.getElementById('dropped-control-boxshadow-color-alpha') as HTMLInputElement;
    droppedControlBoxShadowColorAlphaValueDisplay = document.getElementById('dropped-control-boxshadow-color-alpha-value');
    deleteControlBtn = document.getElementById('delete-control-btn') as HTMLButtonElement;

    droppedControlTypographySection = document.getElementById('dropped-control-typography-section');
    droppedControlFontFamilyInput = document.getElementById('dropped-control-font-family') as HTMLInputElement;
    droppedControlFontSizeInput = document.getElementById('dropped-control-font-size') as HTMLInputElement;
    droppedControlFontWeightSelect = document.getElementById('dropped-control-font-weight') as HTMLSelectElement;
    droppedControlFontStyleSelect = document.getElementById('dropped-control-font-style') as HTMLSelectElement;
    droppedControlLineHeightInput = document.getElementById('dropped-control-line-height') as HTMLInputElement;
    droppedControlLetterSpacingInput = document.getElementById('dropped-control-letter-spacing') as HTMLInputElement;
    droppedControlTextTransformSelect = document.getElementById('dropped-control-text-transform') as HTMLSelectElement;
    droppedControlTextDecorationSelect = document.getElementById('dropped-control-text-decoration') as HTMLSelectElement;
    droppedControlTextShadowXInput = document.getElementById('dropped-control-textshadow-x') as HTMLInputElement;
    droppedControlTextShadowYInput = document.getElementById('dropped-control-textshadow-y') as HTMLInputElement;
    droppedControlTextShadowBlurInput = document.getElementById('dropped-control-textshadow-blur') as HTMLInputElement;
    droppedControlTextShadowColorInput = document.getElementById('dropped-control-textshadow-color') as HTMLInputElement;
    droppedControlTextShadowColorAlphaSlider = document.getElementById('dropped-control-textshadow-color-alpha') as HTMLInputElement;
    droppedControlTextShadowColorAlphaValueDisplay = document.getElementById('dropped-control-textshadow-color-alpha-value');

    textAlignmentControlsContainer = document.getElementById('text-alignment-controls-container');
    textAlignHorizontalSelect = document.getElementById('text-align-horizontal') as HTMLSelectElement;
    textAlignVerticalSelect = document.getElementById('text-align-vertical') as HTMLSelectElement;
    containerAlignmentControlsContainer = document.getElementById('container-alignment-controls-container');
    containerAlignItemsSelect = document.getElementById('container-align-items') as HTMLSelectElement;
    containerJustifyContentSelect = document.getElementById('container-justify-content') as HTMLSelectElement;

    // Advanced TextColors Component Inputs
    textColorsContentInput = document.getElementById('text-colors-content-input') as HTMLTextAreaElement;
    textColorsColor1Picker = document.getElementById('text-colors-color1') as HTMLInputElement;
    textColorsColor1AlphaSlider = document.getElementById('text-colors-color1-alpha') as HTMLInputElement;
    textColorsColor1AlphaValueDisplay = document.getElementById('text-colors-color1-alpha-value');
    textColorsColor2Picker = document.getElementById('text-colors-color2') as HTMLInputElement;
    textColorsColor2AlphaSlider = document.getElementById('text-colors-color2-alpha') as HTMLInputElement;
    textColorsColor2AlphaValueDisplay = document.getElementById('text-colors-color2-alpha-value');
    textColorsGradientModeSelect = document.getElementById('text-colors-gradient-mode') as HTMLSelectElement;
    textColorsColor1FillSlider = document.getElementById('text-colors-color1-fill-slider') as HTMLInputElement;
    textColorsColor1FillValue = document.getElementById('text-colors-color1-fill-value') as HTMLSpanElement;
    textColorsGradientAngleSlider = document.getElementById('text-colors-gradient-angle-slider') as HTMLInputElement;
    textColorsGradientAngleValue = document.getElementById('text-colors-gradient-angle-value') as HTMLSpanElement;
    textColorsColor2StartSlider = document.getElementById('text-colors-color2-start-slider') as HTMLInputElement;
    textColorsColor2StartValue = document.getElementById('text-colors-color2-start-value') as HTMLSpanElement;
    textColorsFontFamilySelect = document.getElementById('text-colors-font-family-select') as HTMLSelectElement;
    textColorsFontSizeInput = document.getElementById('text-colors-font-size-input') as HTMLInputElement;
    textColorsFontWeightSelect = document.getElementById('text-colors-font-weight-select') as HTMLSelectElement;
    textColorsFontStyleSelect = document.getElementById('text-colors-font-style-select') as HTMLSelectElement;
    textColorsDecorationUnderline = document.getElementById('text-colors-decoration-underline') as HTMLInputElement;
    textColorsDecorationOverline = document.getElementById('text-colors-decoration-overline') as HTMLInputElement;
    textColorsDecorationLinethrough = document.getElementById('text-colors-decoration-linethrough') as HTMLInputElement;
    textColorsTextTransformSelect = document.getElementById('text-colors-text-transform-select') as HTMLSelectElement;
    textColorsLineHeightInput = document.getElementById('text-colors-line-height-input') as HTMLInputElement;
    textColorsLetterSpacingInput = document.getElementById('text-colors-letter-spacing-input') as HTMLInputElement;
    textColorsWordSpacingInput = document.getElementById('text-colors-word-spacing-input') as HTMLInputElement;
    textColorsTextAlignSelect = document.getElementById('text-colors-text-align-select') as HTMLSelectElement;
    textColorsFontVariantSelect = document.getElementById('text-colors-font-variant-select') as HTMLSelectElement;
    deleteTextColorsControlBtn = document.getElementById('delete-text-colors-control-btn') as HTMLButtonElement;


    // ANSI/ASCII Art Inputs
    ansiArtVisibleInput = document.getElementById('ansi-art-visible') as HTMLInputElement;
    ansiArtContentInput = document.getElementById('ansi-art-content-input') as HTMLTextAreaElement;
    ansiArtWidthInput = document.getElementById('ansi-art-width') as HTMLInputElement;
    ansiArtHeightInput = document.getElementById('ansi-art-height') as HTMLInputElement;
    ansiArtBgColorInput = document.getElementById('ansi-art-bgcolor') as HTMLInputElement;
    ansiArtBgColorAlphaSlider = document.getElementById('ansi-art-bgcolor-alpha') as HTMLInputElement;
    ansiArtBgColorAlphaValueDisplay = document.getElementById('ansi-art-bgcolor-alpha-value');
    ansiArtTextColorInput = document.getElementById('ansi-art-textcolor') as HTMLInputElement;
    ansiArtTextColorAlphaSlider = document.getElementById('ansi-art-textcolor-alpha') as HTMLInputElement;
    ansiArtTextColorAlphaValueDisplay = document.getElementById('ansi-art-textcolor-alpha-value');
    ansiArtOpacityInput = document.getElementById('ansi-art-opacity') as HTMLInputElement;
    ansiArtOpacityValueDisplay = document.getElementById('ansi-art-opacity-value');
    ansiArtBorderRadiusInput = document.getElementById('ansi-art-border-radius') as HTMLInputElement;
    ansiArtBorderWidthInput = document.getElementById('ansi-art-border-width') as HTMLInputElement;
    ansiArtBorderStyleSelect = document.getElementById('ansi-art-border-style') as HTMLSelectElement;
    ansiArtBorderColorInput = document.getElementById('ansi-art-border-color') as HTMLInputElement;
    ansiArtBorderColorAlphaSlider = document.getElementById('ansi-art-border-color-alpha') as HTMLInputElement;
    ansiArtBorderColorAlphaValueDisplay = document.getElementById('ansi-art-border-color-alpha-value');
    ansiArtBoxShadowXInput = document.getElementById('ansi-art-boxshadow-x') as HTMLInputElement;
    ansiArtBoxShadowYInput = document.getElementById('ansi-art-boxshadow-y') as HTMLInputElement;
    ansiArtBoxShadowBlurInput = document.getElementById('ansi-art-boxshadow-blur') as HTMLInputElement;
    ansiArtBoxShadowColorInput = document.getElementById('ansi-art-boxshadow-color') as HTMLInputElement;
    ansiArtBoxShadowColorAlphaSlider = document.getElementById('ansi-art-boxshadow-color-alpha') as HTMLInputElement;
    ansiArtBoxShadowColorAlphaValueDisplay = document.getElementById('ansi-art-boxshadow-color-alpha-value');
    deleteAnsiArtBtn = document.getElementById('delete-ansi-art-btn') as HTMLButtonElement;

    // HTML Control Inputs
    htmlControlHtmlContentInput = document.getElementById('html-control-html-content') as HTMLTextAreaElement;
    htmlControlCssContentInput = document.getElementById('html-control-css-content') as HTMLTextAreaElement;
    htmlControlJsContentInput = document.getElementById('html-control-js-content') as HTMLTextAreaElement;
    applyHtmlControlCodeBtn = document.getElementById('apply-html-control-code-btn') as HTMLButtonElement;
    deleteHtmlControlBtn = document.getElementById('delete-html-control-btn') as HTMLButtonElement;


    layer2Element = document.getElementById('layer-2');
    layer2VisibleInput = document.getElementById('layer2-visible') as HTMLInputElement;
    layer2WidthInput = document.getElementById('layer2-width') as HTMLInputElement;
    layer2HeightInput = document.getElementById('layer2-height') as HTMLInputElement;
    layer2PaddingInput = document.getElementById('layer2-padding') as HTMLInputElement;
    layer2BgColorInput = document.getElementById('layer2-bgcolor') as HTMLInputElement;
    layer2BgColorAlphaSlider = document.getElementById('layer2-bgcolor-alpha') as HTMLInputElement;
    layer2BgColorAlphaValueDisplay = document.getElementById('layer2-bgcolor-alpha-value');
    layer2BorderWidthInput = document.getElementById('layer2-border-width') as HTMLInputElement;
    layer2BorderColorInput = document.getElementById('layer2-border-color') as HTMLInputElement;
    layer2BorderColorAlphaSlider = document.getElementById('layer2-border-color-alpha') as HTMLInputElement;
    layer2BorderColorAlphaValueDisplay = document.getElementById('layer2-border-color-alpha-value');
    layer2ShadowSelect = document.getElementById('layer2-shadow') as HTMLSelectElement;
    layer2BackdropBlurSelect = document.getElementById('layer2-backdrop-blur') as HTMLSelectElement;

    animationSelectedElementNameDisplay = document.getElementById('animation-selected-element-name');
    animationControlsContainer = document.getElementById('animation-controls-container');
    noElementSelectedAnimationMsg = document.getElementById('no-element-selected-animation-msg');
    animationNameSelect = document.getElementById('config-animation-name') as HTMLSelectElement;
    animationIterationSelect = document.getElementById('config-animation-iteration') as HTMLSelectElement;
    animationDelaySelect = document.getElementById('config-animation-delay') as HTMLSelectElement;
    animationSpeedSelect = document.getElementById('config-animation-speed') as HTMLSelectElement;
    playAnimationButton = document.getElementById('play-animation-btn') as HTMLButtonElement;
    animationOnHoverCheckbox = document.getElementById('config-animation-on-hover') as HTMLInputElement; 

    controlPaletteItems = document.querySelectorAll('#control-palette .control-palette-item');


    savePresetButton = document.getElementById('save-preset-btn') as HTMLButtonElement;
    presetsListContainer = document.getElementById('presets-list-container');
    noPresetsMessage = document.getElementById('no-presets-message');

    // AI Assistant Tab Elements
    aiApiKeyInput = document.getElementById('ai-api-key-input') as HTMLInputElement;
    aiPromptTextarea = document.getElementById('ai-prompt-textarea') as HTMLTextAreaElement;
    aiSendPromptButton = document.getElementById('ai-send-prompt-button') as HTMLButtonElement;
    aiLoadingIndicator = document.getElementById('ai-loading-indicator');
    aiMessageArea = document.getElementById('ai-message-area');
    // aiImageResultArea = document.getElementById('ai-image-result-area'); // Removed
    // aiGeneratedImage = document.getElementById('ai-generated-image') as HTMLImageElement; // Removed
    aiActionGenerateImageRadio = document.getElementById('ai-action-generate-image') as HTMLInputElement;
    aiActionModifyConfigRadio = document.getElementById('ai-action-modify-config') as HTMLInputElement;
    aiPromptHistoryContainer = document.getElementById('ai-prompt-history-container');
    aiPromptHistoryEmptyMsg = document.getElementById('ai-prompt-history-empty');
    aiApplyImageBgButton = document.getElementById('ai-apply-image-bg-button') as HTMLButtonElement;

    // AI Image Preview Modal
    aiImagePreviewModal = document.getElementById('ai-image-preview-modal');
    aiModalImage = document.getElementById('ai-modal-image') as HTMLImageElement;
    aiModalCloseButton = document.getElementById('ai-modal-close-button') as HTMLButtonElement;

    // AI Transparency Controls
    aiTransparencyControlsSection = document.getElementById('ai-transparency-controls-section');
    aiTransparencyColorPicker = document.getElementById('ai-transparency-color-picker') as HTMLInputElement;
    aiTransparencyToleranceSlider = document.getElementById('ai-transparency-tolerance-slider') as HTMLInputElement;
    aiTransparencyToleranceValue = document.getElementById('ai-transparency-tolerance-value');
    aiReprocessTransparencyButton = document.getElementById('ai-reprocess-transparency-button') as HTMLButtonElement;
}
