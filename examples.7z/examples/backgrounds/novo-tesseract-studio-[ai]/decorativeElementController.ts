

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from './domElements';
import * as state from './state';
import { applyStylesToDecorativeElement } from './styleUpdater';
import { selectElement, updateDecorativeElementInputs } from './selectionManager';
import { setupDroppable } from './droppedControlController';
import { SHADOW_CLASSES } from './constants';
import { combineHexAndAlphaToRGBA } from './utils';
import type { ElementConfig, AnchorXType, AnchorYType, ElementDisplayType, ElementOverflowType, BackgroundSizeType, BackgroundRepeatType, ElementBorderStyle } from './types';


export function initializeElementsConfig() {
  const decorativeElements = document.querySelectorAll<HTMLElement>('.decorative-element');
  decorativeElements.forEach(el => {
    const id = el.dataset.elementId;
    if (!id) return;

    const computedStyle = getComputedStyle(el);
    const initialWidth = parseFloat(computedStyle.width);
    const initialHeight = parseFloat(computedStyle.height);
    const vmin = Math.min(window.innerWidth, window.innerHeight) / 100; 
    
    const anchorX = el.dataset.anchorX as AnchorXType || 'center';
    const anchorY = el.dataset.anchorY as AnchorYType || 'center';
    
    const filterBlurMatch = computedStyle.filter.match(/blur\((\d+(\.\d+)?)px\)/);

    const newElementConfig: ElementConfig = {
      id: id,
      element: el,
      anchorX: anchorX,
      anchorY: anchorY,
      isVisible: false, // Initialize as hidden
      display: 'flex', 
      zIndex: parseInt(computedStyle.zIndex) || 0,
      overflowX: 'hidden' as ElementOverflowType, 
      overflowY: 'hidden' as ElementOverflowType, 
      widthVmin: parseFloat((initialWidth / vmin).toFixed(1)) || 20, 
      heightVmin: parseFloat((initialHeight / vmin).toFixed(1)) || 20, 
      paddingVmin: 0, // New: Default padding
      marginTopVmin: parseFloat(computedStyle.marginTop) / vmin || 0,
      marginRightVmin: parseFloat(computedStyle.marginRight) / vmin || 0,
      marginBottomVmin: parseFloat(computedStyle.marginBottom) / vmin || 0,
      marginLeftVmin: parseFloat(computedStyle.marginLeft) / vmin || 0,
      bgColor: computedStyle.backgroundColor || 'rgba(139, 92, 246, 1)', // #8b5cf6 with alpha 1
      imageUrl: '',
      backgroundSize: 'cover',
      bgRepeat: 'no-repeat',
      bgPosition: 'center center',
      shadowClass: Array.from(el.classList).find(cls => SHADOW_CLASSES.includes(cls)) || 'shadow-xl',
      opacity: parseFloat(computedStyle.opacity) || 1,
      filterBlur: filterBlurMatch ? parseFloat(filterBlurMatch[1]) : 0, 
      filterBrightness: 1, filterContrast: 1, filterGrayscale: 0, filterSaturate: 1,
      filterSepia: 0, filterHueRotate: 0, filterInvert: 0,
      borderWidthVmin: 0,
      borderStyle: 'none',
      borderColor: 'rgba(255, 255, 255, 1)', // #FFFFFF with alpha 1
      borderRadiusVmin: 0.5, 
      rotationDeg: 0,
      transformScale: 1, transformTranslateX: 0, transformTranslateY: 0,
      transformSkewX: 0, transformSkewY: 0,
      animationName: '',
      animationIterationClass: '',
      animationDelayClass: '',
      animationSpeedClass: '',
      animationOnHover: false,
    };
    state.updateElementConfig(id, newElementConfig);
    applyStylesToDecorativeElement(id); // Apply initial hidden state

    // Add ID Badge
    const badge = document.createElement('span');
    badge.textContent = id;
    badge.className = 'absolute top-1 left-1 bg-slate-900/70 text-white text-[10px] px-1.5 py-0.5 rounded-sm pointer-events-none shadow';
    badge.style.zIndex = '10'; // Ensure badge is above element content but respects element z-index
    el.appendChild(badge);

    el.addEventListener('click', (e) => {
        // Prevent selection if a child control is clicked
        if (e.target !== el && (e.target as HTMLElement).closest('.dropped-control')) {
            return;
        }
        selectElement(id);
    });
    setupDroppable(el); 
  });
}

function updateVisibilityToggleButtonAppearance(button: HTMLButtonElement, isVisible: boolean) {
    if (isVisible) {
        button.classList.remove('opacity-60', 'bg-slate-600', 'hover:bg-slate-500');
        button.classList.add('bg-teal-600', 'hover:bg-teal-500');
        button.setAttribute('aria-pressed', 'true');
        button.title = `Hide ${button.textContent} element`;
    } else {
        button.classList.remove('bg-teal-600', 'hover:bg-teal-500');
        button.classList.add('opacity-60', 'bg-slate-600', 'hover:bg-slate-500');
        button.setAttribute('aria-pressed', 'false');
        button.title = `Show ${button.textContent} element`;
    }
}

export function updateAllVisibilityToggleButtons() {
    if (!dom.decorativeElementVisibilityToggles) return;
    dom.decorativeElementVisibilityToggles.forEach(button => {
        const elementId = button.dataset.elementIdToggle;
        if (elementId && state.elementsConfig[elementId]) {
            updateVisibilityToggleButtonAppearance(button, state.elementsConfig[elementId].isVisible);
        }
    });
}

export function setupDecorativeElementVisibilityControls() {
    if (!dom.decorativeElementVisibilityToggles) return;

    dom.decorativeElementVisibilityToggles.forEach(button => {
        button.addEventListener('click', () => {
            const elementIdToToggle = button.dataset.elementIdToggle;
            if (elementIdToToggle && state.elementsConfig[elementIdToToggle]) {
                const config = state.elementsConfig[elementIdToToggle];
                config.isVisible = !config.isVisible;
                applyStylesToDecorativeElement(elementIdToToggle);
                updateVisibilityToggleButtonAppearance(button, config.isVisible);

                // Select the element when it's made visible
                if (config.isVisible) {
                    selectElement(elementIdToToggle);
                }
                
                // If the currently selected element's visibility was toggled, update its panel inputs
                if (state.selectedElementId === elementIdToToggle && dom.visibleInput) {
                    dom.visibleInput.checked = config.isVisible;
                }
            }
        });
    });
    updateAllVisibilityToggleButtons(); // Set initial state of buttons
}


export function setupDecorativeElementPanelListeners() {
  if (!dom.visibleInput || !dom.elDisplaySelect || !dom.elZIndexInput || !dom.elOverflowXSelect || !dom.elOverflowYSelect ||
      !dom.widthInput || !dom.heightInput || 
      !dom.bgColorInput || !dom.bgColorAlphaSlider || !dom.bgColorAlphaValueDisplay ||
      !dom.shadowSelect ||
      !dom.marginTopInput || !dom.marginRightInput || !dom.marginBottomInput || !dom.marginLeftInput ||
      !dom.imageUrlInput || !dom.bgSizeSelect || !dom.elBgRepeatSelect || !dom.elBgPositionInput ||
      !dom.opacityInput || !dom.opacityValueDisplay || !dom.elBlurInput || !dom.elBlurValueDisplay ||
      !dom.elBrightnessInput || !dom.elBrightnessValueDisplay || !dom.elContrastInput || !dom.elContrastValueDisplay ||
      !dom.elSaturateInput || !dom.elSaturateValueDisplay || !dom.elGrayscaleInput || !dom.elGrayscaleValueDisplay ||
      !dom.elSepiaInput || !dom.elSepiaValueDisplay || !dom.elInvertInput || !dom.elInvertValueDisplay ||
      !dom.elHueRotateInput || !dom.elHueRotateValueDisplay ||
      !dom.elBorderWidthInput || !dom.elBorderStyleSelect || 
      !dom.elBorderColorInput || !dom.elBorderColorAlphaSlider || !dom.elBorderColorAlphaValueDisplay ||
      !dom.elBorderRadiusInput || 
      !dom.elRotationInput || !dom.elRotationValueDisplay || !dom.elScaleInput || !dom.elScaleValueDisplay ||
      !dom.elTranslateXInput || !dom.elTranslateYInput || !dom.elSkewXInput || !dom.elSkewYInput
      // Note: Padding input not added here, AI can control it.
    ) return;

  const updateFn = () => { 
      if (state.selectedElementId) {
          applyStylesToDecorativeElement(state.selectedElementId); 
          if (dom.decorativeElementVisibilityToggles) {
            dom.decorativeElementVisibilityToggles.forEach(btn => {
                if (btn.dataset.elementIdToggle === state.selectedElementId && state.elementsConfig[state.selectedElementId]) {
                    updateVisibilityToggleButtonAppearance(btn, state.elementsConfig[state.selectedElementId].isVisible);
                }
            });
          }
      }
  };
  
  const updateBgColor = () => {
    if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.bgColorInput && dom.bgColorAlphaSlider) {
        const newColor = combineHexAndAlphaToRGBA(dom.bgColorInput.value, parseFloat(dom.bgColorAlphaSlider.value));
        state.elementsConfig[state.selectedElementId].bgColor = newColor;
        if (!state.elementsConfig[state.selectedElementId].imageUrl) { updateFn(); }
    }
  };

  const updateBorderColor = () => {
    if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.elBorderColorInput && dom.elBorderColorAlphaSlider) {
        const newColor = combineHexAndAlphaToRGBA(dom.elBorderColorInput.value, parseFloat(dom.elBorderColorAlphaSlider.value));
        state.elementsConfig[state.selectedElementId].borderColor = newColor;
        updateFn();
    }
  };

  dom.visibleInput.addEventListener('change', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].isVisible = (e.target as HTMLInputElement).checked; updateFn(); }});
  dom.elDisplaySelect.addEventListener('change', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].display = (e.target as HTMLSelectElement).value as ElementDisplayType; updateFn(); }});
  dom.elZIndexInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].zIndex = parseInt((e.target as HTMLInputElement).value) || 0; updateFn(); }});
  dom.elOverflowXSelect.addEventListener('change', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].overflowX = (e.target as HTMLSelectElement).value as ElementOverflowType; updateFn(); }});
  dom.elOverflowYSelect.addEventListener('change', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].overflowY = (e.target as HTMLSelectElement).value as ElementOverflowType; updateFn(); }});
  dom.widthInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].widthVmin = parseFloat((e.target as HTMLInputElement).value) || 0; updateFn(); }});
  dom.heightInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].heightVmin = parseFloat((e.target as HTMLInputElement).value) || 0; updateFn(); }});
  dom.marginTopInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].marginTopVmin = parseFloat((e.target as HTMLInputElement).value) || 0; updateFn(); }});
  dom.marginRightInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].marginRightVmin = parseFloat((e.target as HTMLInputElement).value) || 0; updateFn(); }});
  dom.marginBottomInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].marginBottomVmin = parseFloat((e.target as HTMLInputElement).value) || 0; updateFn(); }});
  dom.marginLeftInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].marginLeftVmin = parseFloat((e.target as HTMLInputElement).value) || 0; updateFn(); }});
  
  dom.bgColorInput.addEventListener('input', updateBgColor);
  dom.bgColorAlphaSlider.addEventListener('input', (e) => {
    if(dom.bgColorAlphaValueDisplay) dom.bgColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
    updateBgColor();
  });

  dom.imageUrlInput.addEventListener('change', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].imageUrl = (e.target as HTMLInputElement).value; updateFn(); }});
  dom.bgSizeSelect.addEventListener('change', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].backgroundSize = (e.target as HTMLSelectElement).value as BackgroundSizeType; if (state.elementsConfig[state.selectedElementId].imageUrl) { updateFn(); } }});
  dom.elBgRepeatSelect.addEventListener('change', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].bgRepeat = (e.target as HTMLSelectElement).value as BackgroundRepeatType; if (state.elementsConfig[state.selectedElementId].imageUrl) { updateFn(); } }});
  dom.elBgPositionInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].bgPosition = (e.target as HTMLInputElement).value; if (state.elementsConfig[state.selectedElementId].imageUrl) { updateFn(); } }});
  dom.shadowSelect.addEventListener('change', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].shadowClass = (e.target as HTMLSelectElement).value; updateFn(); }});
  
  dom.opacityInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.opacityValueDisplay) { const val = parseFloat((e.target as HTMLInputElement).value) || 1; state.elementsConfig[state.selectedElementId].opacity = val; dom.opacityValueDisplay.textContent = val.toFixed(2); updateFn(); }});
  dom.elBlurInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.elBlurValueDisplay) { const val = parseFloat((e.target as HTMLInputElement).value) || 0; state.elementsConfig[state.selectedElementId].filterBlur = val; dom.elBlurValueDisplay.textContent = val.toString(); updateFn(); }});
  dom.elBrightnessInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.elBrightnessValueDisplay) { const val = parseFloat((e.target as HTMLInputElement).value) || 1; state.elementsConfig[state.selectedElementId].filterBrightness = val; dom.elBrightnessValueDisplay.textContent = val.toFixed(2); updateFn(); }});
  dom.elContrastInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.elContrastValueDisplay) { const val = parseFloat((e.target as HTMLInputElement).value) || 1; state.elementsConfig[state.selectedElementId].filterContrast = val; dom.elContrastValueDisplay.textContent = val.toFixed(2); updateFn(); }});
  dom.elSaturateInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.elSaturateValueDisplay) { const val = parseFloat((e.target as HTMLInputElement).value) || 1; state.elementsConfig[state.selectedElementId].filterSaturate = val; dom.elSaturateValueDisplay.textContent = val.toFixed(2); updateFn(); }});
  dom.elGrayscaleInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.elGrayscaleValueDisplay) { const val = parseFloat((e.target as HTMLInputElement).value) || 0; state.elementsConfig[state.selectedElementId].filterGrayscale = val; dom.elGrayscaleValueDisplay.textContent = val.toFixed(2); updateFn(); }});
  dom.elSepiaInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.elSepiaValueDisplay) { const val = parseFloat((e.target as HTMLInputElement).value) || 0; state.elementsConfig[state.selectedElementId].filterSepia = val; dom.elSepiaValueDisplay.textContent = val.toFixed(2); updateFn(); }});
  dom.elInvertInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.elInvertValueDisplay) { const val = parseFloat((e.target as HTMLInputElement).value) || 0; state.elementsConfig[state.selectedElementId].filterInvert = val; dom.elInvertValueDisplay.textContent = val.toFixed(2); updateFn(); }});
  dom.elHueRotateInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.elHueRotateValueDisplay) { const val = parseFloat((e.target as HTMLInputElement).value) || 0; state.elementsConfig[state.selectedElementId].filterHueRotate = val; dom.elHueRotateValueDisplay.textContent = val.toString(); updateFn(); }});
  
  dom.elBorderWidthInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].borderWidthVmin = parseFloat((e.target as HTMLInputElement).value) || 0; updateFn(); }});
  dom.elBorderStyleSelect.addEventListener('change', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].borderStyle = (e.target as HTMLSelectElement).value as ElementBorderStyle; updateFn(); }});
  
  dom.elBorderColorInput.addEventListener('input', updateBorderColor);
  dom.elBorderColorAlphaSlider.addEventListener('input', (e) => {
    if(dom.elBorderColorAlphaValueDisplay) dom.elBorderColorAlphaValueDisplay.textContent = parseFloat((e.target as HTMLInputElement).value).toFixed(2);
    updateBorderColor();
  });

  dom.elBorderRadiusInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].borderRadiusVmin = parseFloat((e.target as HTMLInputElement).value) || 0; updateFn(); }});
  
  dom.elRotationInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.elRotationValueDisplay) { const val = parseFloat((e.target as HTMLInputElement).value) || 0; state.elementsConfig[state.selectedElementId].rotationDeg = val; dom.elRotationValueDisplay.textContent = val.toString(); updateFn(); }});
  dom.elScaleInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId] && dom.elScaleValueDisplay) { const val = parseFloat((e.target as HTMLInputElement).value) || 1; state.elementsConfig[state.selectedElementId].transformScale = val; dom.elScaleValueDisplay.textContent = val.toFixed(2); updateFn(); }});
  dom.elTranslateXInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].transformTranslateX = parseFloat((e.target as HTMLInputElement).value) || 0; updateFn(); }});
  dom.elTranslateYInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].transformTranslateY = parseFloat((e.target as HTMLInputElement).value) || 0; updateFn(); }});
  dom.elSkewXInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].transformSkewX = parseFloat((e.target as HTMLInputElement).value) || 0; updateFn(); }});
  dom.elSkewYInput.addEventListener('input', (e) => { if (state.selectedElementId && state.elementsConfig[state.selectedElementId]) { state.elementsConfig[state.selectedElementId].transformSkewY = parseFloat((e.target as HTMLInputElement).value) || 0; updateFn(); }});
}