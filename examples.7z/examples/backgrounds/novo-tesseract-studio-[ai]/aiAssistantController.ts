/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from './domElements';
import * as state from './state';
import { applyStylesToDecorativeElement, applyStylesToLayer2, applyStylesToDroppedControl, applyStylesToAnsiArtViewer } from './styleUpdater';
import { updateDecorativeElementInputs, selectElement, updateDroppedControlInputs, updateTextColorsComponentInputs, updateAnsiArtViewerInputs, updateHtmlControlInputs, handleControlSelection } from './selectionManager';
import { updateLayer2PanelInputs } from './layer2Controller';
import { generateImageWithGemini, interpretConfigurationPrompt } from './geminiService';
import { processImageForTransparency, generateUniqueId, combineHexAndAlphaToRGBA, splitColorToHexAndAlpha } from './utils';
import type { Layer2Config, ElementConfig, BackgroundRepeatType, BackgroundSizeType, ElementBorderStyle, ElementDisplayType, ControlPaletteItemType, TextColorAdvancedGradientMode, FontStyleType, TextTransformType, TextDecorationType, TextAlignmentHorizontal, TextAlignmentVertical, FlexAlignItems, FlexJustifyContent, AiInteraction } from './types';
import { switchTab } from './configPanelManager';
import { 
    setupDroppable, 
    handleDroppedControlDragStart, 
    handleDroppedControlDragEnd,
} from './droppedControlController';
import { renderTextColorsComponent } from './textColorsComponent';
import { applyCustomHtmlCode, DEFAULT_HTML_CONTENT, DEFAULT_CSS_CONTENT, DEFAULT_JS_CONTENT } from './htmlControlController';
import { 
    DEFAULT_TEXTCOLORS_TEXT_CONTENT,
    DEFAULT_TEXTCOLORS_COLOR1,
    DEFAULT_TEXTCOLORS_COLOR2,
    DEFAULT_TEXTCOLORS_GRADIENT_MODE,
    DEFAULT_TEXTCOLORS_COLOR1_FILL,
    DEFAULT_TEXTCOLORS_GRADIENT_ANGLE,
    DEFAULT_TEXTCOLORS_COLOR2_START,
    DEFAULT_TEXTCOLORS_FONT_FAMILY,
    DEFAULT_TEXTCOLORS_FONT_SIZE,
    DEFAULT_TEXTCOLORS_FONT_WEIGHT,
    DEFAULT_TEXTCOLORS_FONT_STYLE,
    DEFAULT_TEXTCOLORS_DECORATION_UNDERLINE,
    DEFAULT_TEXTCOLORS_DECORATION_OVERLINE,
    DEFAULT_TEXTCOLORS_DECORATION_LINETHROUGH,
    DEFAULT_TEXTCOLORS_TEXT_TRANSFORM,
    DEFAULT_TEXTCOLORS_LINE_HEIGHT,
    DEFAULT_TEXTCOLORS_LETTER_SPACING,
    DEFAULT_TEXTCOLORS_WORD_SPACING,
    DEFAULT_TEXTCOLORS_TEXT_ALIGN,
    DEFAULT_TEXTCOLORS_FONT_VARIANT
 } from './constants';
 import { updatePlaceholderVisibility } from './utils';


const GEMINI_API_KEY_COOKIE = 'geminiApiKey_tesseractStudio';
const CURRENT_AI_ACTIVE_IMAGE_ID = 'current-ai-active-image';


// Simple debounce function
function debounce<F extends (...args: any[]) => void>(func: F, waitFor: number) {
    let timeout: ReturnType<typeof setTimeout> | null = null;
    return (...args: Parameters<F>): void => {
        if (timeout) {
            clearTimeout(timeout);
        }
        timeout = setTimeout(() => func(...args), waitFor);
    };
}

// Helper to convert hex color string to an RGB object
function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
    const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    hex = hex.replace(shorthandRegex, (m, r, g, b) => r + r + g + g + b + b);
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result
        ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16),
          }
        : null;
}

function saveApiKeyToCookie(apiKey: string) {
    if (!apiKey) return;
    // Store for 1 year
    document.cookie = `${GEMINI_API_KEY_COOKIE}=${encodeURIComponent(apiKey)};max-age=31536000;path=/;SameSite=Lax`;
}

function getApiKeyFromCookie(): string | null {
    const cookies = document.cookie.split('; ');
    const apiKeyCookie = cookies.find(row => row.startsWith(`${GEMINI_API_KEY_COOKIE}=`));
    if (apiKeyCookie) {
        return decodeURIComponent(apiKeyCookie.split('=')[1]);
    }
    return null;
}


function showLoading(isLoading: boolean) {
    if (dom.aiLoadingIndicator) {
        dom.aiLoadingIndicator.classList.toggle('hidden', !isLoading);
    }
    if (dom.aiSendPromptButton) {
        dom.aiSendPromptButton.disabled = isLoading;
    }
    if (dom.aiPromptTextarea) {
        (dom.aiPromptTextarea as HTMLTextAreaElement).disabled = isLoading;
    }
}

function addMessageToChat(type: 'user' | 'ai' | 'error' | 'image', content: string, imageUrl?: string, imageId?: string) {
    if (!dom.aiMessageArea) return;

    dom.aiMessageArea.classList.remove('hidden');
    const placeholder = dom.aiMessageArea.querySelector('#ai-chat-placeholder');
    if (placeholder) placeholder.classList.add('hidden');

    const bubble = document.createElement('div');
    bubble.classList.add('max-w-[85%]', 'p-2', 'rounded-lg', 'text-sm', 'mb-3', 'shadow'); // Tailwind mb-3

    if (type === 'image') {
        bubble.classList.add('ai-image-bubble'); // Uses existing CSS for image bubbles
        const img = document.createElement('img');
        img.src = imageUrl || '';
        img.alt = content || 'AI Generated Image';
        img.className = 'max-w-full h-auto rounded border border-slate-600 cursor-pointer transition-opacity duration-200 hover:opacity-85';
        if (imageId) img.id = imageId;
        img.addEventListener('click', () => showImagePreviewModal(imageUrl || ''));
        bubble.appendChild(img);
        
        // Make this new image the "active" one for global controls
        state.setLastOriginalImageUrl(imageUrl || null); // Store original for re-processing
        state.setLastGeneratedImageUrl(imageUrl || null); // Store current (possibly processed) version

        if (dom.aiApplyImageBgButton) dom.aiApplyImageBgButton.classList.remove('hidden');
        if (dom.aiTransparencyControlsSection) dom.aiTransparencyControlsSection.classList.remove('hidden');

    } else {
        const textSpan = document.createElement('span');
        textSpan.textContent = content;
        bubble.appendChild(textSpan);

        switch (type) {
            case 'user':
                bubble.classList.add('bg-sky-600', 'text-white', 'self-end', 'user-prompt-bubble');
                break;
            case 'ai':
                bubble.classList.add('bg-slate-700', 'text-slate-100', 'self-start', 'ai-response-bubble');
                break;
            case 'error':
                bubble.classList.add('bg-red-700', 'text-white', 'self-start', 'ai-response-bubble');
                break;
        }
    }
    dom.aiMessageArea.appendChild(bubble);
    dom.aiMessageArea.scrollTop = dom.aiMessageArea.scrollHeight; // Auto-scroll
}


function addPromptToHistoryUI(prompt: string) {
    if (!dom.aiPromptHistoryContainer || !dom.aiPromptHistoryEmptyMsg) return;

    dom.aiPromptHistoryEmptyMsg.classList.add('hidden');
    const item = document.createElement('div');
    item.textContent = prompt;
    item.className = 'ai-prompt-history-item text-slate-300 hover:text-sky-300';
    item.addEventListener('click', () => {
        if (dom.aiPromptTextarea) {
            dom.aiPromptTextarea.value = prompt;
            dom.aiPromptTextarea.focus();
        }
    });
    // Add to the top of the history list
    if (dom.aiPromptHistoryContainer.firstChild) {
        dom.aiPromptHistoryContainer.insertBefore(item, dom.aiPromptHistoryContainer.firstChild);
    } else {
        dom.aiPromptHistoryContainer.appendChild(item);
    }
    // Limit history display (only for UI, state manages its own limit)
    let uiHistoryItemCount = 0;
    for(const child of Array.from(dom.aiPromptHistoryContainer.children)) {
        if (child.id !== 'ai-prompt-history-empty') {
            uiHistoryItemCount++;
        }
    }

    while (uiHistoryItemCount > state.MAX_PROMPT_HISTORY) {
      const lastChild = dom.aiPromptHistoryContainer.lastElementChild;
      if(lastChild && lastChild.id !== 'ai-prompt-history-empty'){
        dom.aiPromptHistoryContainer.removeChild(lastChild);
        uiHistoryItemCount--;
      } else {
        break; 
      }
    }
}

function showImagePreviewModal(imageUrl: string) {
    if (dom.aiImagePreviewModal && dom.aiModalImage) {
        dom.aiModalImage.src = imageUrl;
        dom.aiImagePreviewModal.classList.remove('hidden');
        dom.aiImagePreviewModal.classList.add('flex'); // Use flex to center
        dom.aiImagePreviewModal.setAttribute('aria-hidden', 'false');
        if(dom.aiModalCloseButton) dom.aiModalCloseButton.focus();
    }
}

function hideImagePreviewModal() {
     if (dom.aiImagePreviewModal) {
        dom.aiImagePreviewModal.classList.add('hidden');
        dom.aiImagePreviewModal.classList.remove('flex');
        dom.aiImagePreviewModal.setAttribute('aria-hidden', 'true');
    }
}


function parseValueWithUnit(value: string | number, defaultUnit: 'px' | 'vmin' | 'deg' | '%'): { num: number, unit: string } {
    if (typeof value === 'number') {
        return { num: value, unit: defaultUnit };
    }
    const match = String(value).match(/^([+-]?\d*\.?\d+)\s*(\w*|%)$/);
    if (match) {
        return { num: parseFloat(match[1]), unit: match[2] || defaultUnit };
    }
    return { num: parseFloat(String(value)) || 0, unit: defaultUnit }; // Fallback
}


function applyAiModifyElementProperties(elementId: string, properties: any) {
    let targetConfig: Layer2Config | ElementConfig | null = null;
    let isLayer2 = false;

    if (elementId === 'layer-2') {
        targetConfig = state.layer2Config;
        isLayer2 = true;
    } else if (state.elementsConfig[elementId]) {
        targetConfig = state.elementsConfig[elementId];
    } else {
        addMessageToChat('error', `Element with ID "${elementId}" not found for property modification.`);
        return;
    }

    let changesMade = false;
    for (const propName in properties) {
        const propValue = properties[propName];
        changesMade = true; // Assume a change is made if a property is present

        if (isLayer2 && targetConfig) {
            const l2Config = targetConfig as Layer2Config;
            switch (propName.toLowerCase()) {
                case 'visible': l2Config.isVisible = Boolean(propValue); break;
                case 'width': l2Config.widthPercent = parseValueWithUnit(propValue, '%').num; break;
                case 'height': l2Config.heightPercent = parseValueWithUnit(propValue, '%').num; break;
                case 'padding': l2Config.paddingPx = parseValueWithUnit(propValue, 'px').num; break;
                case 'bgcolor': case 'backgroundcolor': l2Config.bgColor = String(propValue); break;
                case 'opacity': l2Config.opacity = parseFloat(String(propValue)); break;
                case 'imageurl': l2Config.imageUrl = String(propValue); break;
                case 'backgroundsize': l2Config.backgroundSize = String(propValue) as BackgroundSizeType; break;
                case 'backgroundrepeat': l2Config.bgRepeat = String(propValue) as BackgroundRepeatType; break;
                case 'backgroundposition': l2Config.bgPosition = String(propValue); break;
                case 'borderwidth': l2Config.borderWidthPx = parseValueWithUnit(propValue, 'px').num; break;
                case 'bordercolor': l2Config.borderColor = String(propValue); break;
                case 'borderstyle': l2Config.borderStyle = String(propValue) as ElementBorderStyle; break;
                case 'borderradius': l2Config.borderRadiusPx = parseValueWithUnit(propValue, 'px').num; break;
                case 'shadow': l2Config.shadowClass = String(propValue); break;
                case 'backdropblur': l2Config.backdropBlurClass = String(propValue); break;
                default: console.warn(`AI tried to set unhandled Layer 2 property: ${propName}`); changesMade = false;
            }
        } else if (!isLayer2 && targetConfig) {
            const elConfig = targetConfig as ElementConfig;
            switch (propName.toLowerCase()) {
                case 'visible': elConfig.isVisible = Boolean(propValue); break;
                case 'display': elConfig.display = String(propValue) as ElementDisplayType; break;
                case 'zindex': elConfig.zIndex = parseInt(String(propValue)) || 0; break;
                case 'width': elConfig.widthVmin = parseValueWithUnit(propValue, 'vmin').num; break;
                case 'height': elConfig.heightVmin = parseValueWithUnit(propValue, 'vmin').num; break;
                case 'padding': elConfig.paddingVmin = parseValueWithUnit(propValue, 'vmin').num; break;
                case 'margintop': elConfig.marginTopVmin = parseValueWithUnit(propValue, 'vmin').num; break;
                case 'marginright': elConfig.marginRightVmin = parseValueWithUnit(propValue, 'vmin').num; break;
                case 'marginbottom': elConfig.marginBottomVmin = parseValueWithUnit(propValue, 'vmin').num; break;
                case 'marginleft': elConfig.marginLeftVmin = parseValueWithUnit(propValue, 'vmin').num; break;
                case 'bgcolor': case 'backgroundcolor': elConfig.bgColor = String(propValue); break;
                case 'imageurl': elConfig.imageUrl = String(propValue); break;
                case 'backgroundsize': elConfig.backgroundSize = String(propValue) as BackgroundSizeType; break;
                case 'backgroundrepeat': elConfig.bgRepeat = String(propValue) as BackgroundRepeatType; break;
                case 'backgroundposition': elConfig.bgPosition = String(propValue); break;
                case 'shadow': elConfig.shadowClass = String(propValue); break;
                case 'opacity': elConfig.opacity = parseFloat(String(propValue)); break;
                case 'blur': elConfig.filterBlur = parseValueWithUnit(propValue, 'px').num; break;
                case 'brightness': elConfig.filterBrightness = parseFloat(String(propValue)); break;
                case 'contrast': elConfig.filterContrast = parseFloat(String(propValue)); break;
                case 'grayscale': elConfig.filterGrayscale = parseFloat(String(propValue)); break;
                case 'saturate': elConfig.filterSaturate = parseFloat(String(propValue)); break;
                case 'sepia': elConfig.filterSepia = parseFloat(String(propValue)); break;
                case 'huerotate': elConfig.filterHueRotate = parseValueWithUnit(propValue, 'deg').num; break;
                case 'invert': elConfig.filterInvert = parseFloat(String(propValue)); break;
                case 'borderwidth': elConfig.borderWidthVmin = parseValueWithUnit(propValue, 'vmin').num; break;
                case 'borderstyle': elConfig.borderStyle = String(propValue) as ElementBorderStyle; break;
                case 'bordercolor': elConfig.borderColor = String(propValue); break;
                case 'borderradius': elConfig.borderRadiusVmin = parseValueWithUnit(propValue, 'vmin').num; break;
                case 'rotation': elConfig.rotationDeg = parseValueWithUnit(propValue, 'deg').num; break;
                case 'scale': elConfig.transformScale = parseFloat(String(propValue)); break;
                case 'translatex': elConfig.transformTranslateX = parseValueWithUnit(propValue, 'vmin').num; break;
                case 'translatey': elConfig.transformTranslateY = parseValueWithUnit(propValue, 'vmin').num; break;
                case 'skewx': elConfig.transformSkewX = parseValueWithUnit(propValue, 'deg').num; break;
                case 'skewy': elConfig.transformSkewY = parseValueWithUnit(propValue, 'deg').num; break;
                case 'animationname':
                    let animName = String(propValue);
                    if (animName && !animName.startsWith('animate__')) animName = `animate__${animName}`;
                    elConfig.animationName = animName;
                    break;
                default: console.warn(`AI tried to set unhandled Element property: ${propName}`); changesMade = false;
            }
        }
    }

    if (changesMade) {
        if (isLayer2) {
            applyStylesToLayer2();
            updateLayer2PanelInputs();
            addMessageToChat('ai', `Configuration for ${elementId} updated. Check the Globals tab.`);
            if (state.activeTabId !== 'ai') switchTab('globals');
        } else {
            applyStylesToDecorativeElement(elementId);
            if (state.selectedElementId === elementId && state.elementsConfig[elementId]) {
                updateDecorativeElementInputs(state.elementsConfig[elementId]);
            }
            addMessageToChat('ai', `Configuration for ${elementId} updated. Select it to see changes in the Element tab.`);
            selectElement(elementId, false); // Select the element, but don't switch tab from AI
        }
    } else {
         addMessageToChat('ai', `No recognized changes applied for ${elementId}.`);
    }
}

function handleAiAddControl(config: any) {
    const { parentId, controlType, initialProperties, placementHint } = config;
    if (!parentId || !controlType) {
        addMessageToChat('error', 'AI response for adding control was missing parentId or controlType.');
        state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null); // Clear context
        return;
    }

    let actualParentId = parentId;
    let parentElement: HTMLElement | null = null;

    if (placementHint && parentId) {
        const grandparentElement = document.getElementById(parentId) || document.querySelector(`[data-dropped-control-id="${parentId}"]`);
        if (grandparentElement) {
            let targetTypeFilter = '';
            if (placementHint === 'inside_most_recent_row-container') targetTypeFilter = '[data-control-type="row-container"]';
            else if (placementHint === 'inside_most_recent_column-container') targetTypeFilter = '[data-control-type="column-container"]';

            if (targetTypeFilter) {
                const children = Array.from(grandparentElement.querySelectorAll<HTMLElement>(`.dropped-control${targetTypeFilter}`));
                if (children.length > 0) {
                    const mostRecentTarget = children[children.length - 1];
                    actualParentId = mostRecentTarget.dataset.droppedControlId;
                    parentElement = mostRecentTarget;
                    console.log(`[AI AddControl] Using placementHint. Original parentId: ${parentId}, Hint: ${placementHint}. Resolved to actualParentId: ${actualParentId}`);
                } else {
                    addMessageToChat('error', `AI suggested placing inside a recent ${placementHint.split('_').pop()} in ${parentId}, but no such control was found. Adding to ${parentId} instead.`);
                    parentElement = grandparentElement; // Fallback to original parentId
                }
            } else {
                 parentElement = grandparentElement; // Fallback if hint is not recognized
            }
        } else {
             addMessageToChat('error', `Grandparent element with ID "${parentId}" (for placementHint) not found.`);
             state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null);
             return;
        }
    }
    
    // If parentElement wasn't determined by placementHint, find it now using actualParentId
    if (!parentElement) {
        if (actualParentId === 'layer-2') {
            parentElement = dom.layer2Element;
        } else if (state.elementsConfig[actualParentId]) {
            parentElement = state.elementsConfig[actualParentId].element;
        } else {
            parentElement = document.querySelector(`[data-dropped-control-id="${actualParentId}"]`);
        }
    }


    if (!parentElement) {
        addMessageToChat('error', `Parent element with ID "${actualParentId}" not found for adding control.`);
        state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null);
        return;
    }
     // Check if the resolved parentElement is a valid drop target
    const isLayer2 = parentElement.id === 'layer-2';
    const isDecorativeElement = parentElement.classList.contains('decorative-element');
    const isRowContainer = parentElement.classList.contains('dropped-row-container');
    const isColumnContainer = parentElement.classList.contains('dropped-column-container');

    if (!isLayer2 && !isDecorativeElement && !isRowContainer && !isColumnContainer) {
        addMessageToChat('error', `Parent element "${actualParentId}" (resolved from parentId: ${parentId} and hint: ${placementHint || 'none'}) is not a valid drop target. Target must be layer-2, a decorative-element, or a row/column container.`);
        state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null);
        return;
    }


    let newControl: HTMLElement | null = null;
    const type = controlType as ControlPaletteItemType;

    switch (type) {
        case 'button':
            newControl = document.createElement('button');
            newControl.className = 'dropped-control dropped-button bg-blue-500 text-white p-2 rounded';
            newControl.textContent = 'Button'; // Default
            newControl.style.display = 'flex'; newControl.style.alignItems = 'center'; newControl.style.justifyContent = 'center'; newControl.style.textAlign = 'center';
            break;
        case 'text-input':
            newControl = document.createElement('input');
            (newControl as HTMLInputElement).type = 'text'; (newControl as HTMLInputElement).placeholder = 'Text Input'; // Default
            newControl.className = 'dropped-control dropped-input p-2 border border-gray-400 rounded bg-white text-gray-800';
            newControl.style.textAlign = 'left';
            break;
        case 'row-container':
            newControl = document.createElement('div');
            newControl.className = 'dropped-control dropped-row-container flex flex-row border border-dashed border-gray-500 p-2 min-h-[50px] space-x-2 items-start w-full';
            newControl.dataset.droppableType = 'container';
            newControl.innerHTML = '<span class="container-empty-placeholder text-xs text-gray-400 italic p-1 self-center pointer-events-none">Row</span>';
            newControl.style.alignItems = 'flex-start'; newControl.style.justifyContent = 'flex-start';
            break;
        case 'column-container':
            newControl = document.createElement('div');
            newControl.className = 'dropped-control dropped-column-container flex flex-col border border-dashed border-gray-500 p-2 min-h-[50px] space-y-2 items-start w-full';
            newControl.dataset.droppableType = 'container';
            newControl.innerHTML = '<span class="container-empty-placeholder text-xs text-gray-400 italic p-1 self-center pointer-events-none">Col</span>';
            newControl.style.alignItems = 'flex-start'; newControl.style.justifyContent = 'flex-start';
            break;
        case 'text-block':
            newControl = document.createElement('p');
            newControl.className = 'dropped-control dropped-text-block text-gray-200 p-1';
            newControl.textContent = 'Some text content...'; // Default
            newControl.style.display = 'flex'; newControl.style.alignItems = 'flex-start'; newControl.style.textAlign = 'left';
            break;
        case 'image-element':
            newControl = document.createElement('div');
            newControl.className = 'dropped-control dropped-image-element w-24 h-24 bg-gray-600 bg-cover bg-center flex items-center justify-center text-gray-400 italic';
            newControl.textContent = 'Image'; // Default
            break;
        case 'text-colors':
            newControl = document.createElement('div');
            newControl.className = 'dropped-control dropped-text-colors-component';
            Object.assign(newControl.dataset, {
                textContent: DEFAULT_TEXTCOLORS_TEXT_CONTENT, color1: DEFAULT_TEXTCOLORS_COLOR1, color2: DEFAULT_TEXTCOLORS_COLOR2, gradientMode: DEFAULT_TEXTCOLORS_GRADIENT_MODE,
                color1Fill: DEFAULT_TEXTCOLORS_COLOR1_FILL.toString(), gradientAngle: DEFAULT_TEXTCOLORS_GRADIENT_ANGLE.toString(), color2Start: DEFAULT_TEXTCOLORS_COLOR2_START.toString(),
                fontFamily: DEFAULT_TEXTCOLORS_FONT_FAMILY, fontSize: DEFAULT_TEXTCOLORS_FONT_SIZE.toString(), fontWeight: DEFAULT_TEXTCOLORS_FONT_WEIGHT, fontStyle: DEFAULT_TEXTCOLORS_FONT_STYLE,
                decorationUnderline: String(DEFAULT_TEXTCOLORS_DECORATION_UNDERLINE), decorationOverline: String(DEFAULT_TEXTCOLORS_DECORATION_OVERLINE), decorationLinethrough: String(DEFAULT_TEXTCOLORS_DECORATION_LINETHROUGH),
                textTransform: DEFAULT_TEXTCOLORS_TEXT_TRANSFORM, lineHeight: DEFAULT_TEXTCOLORS_LINE_HEIGHT.toString(), letterSpacing: DEFAULT_TEXTCOLORS_LETTER_SPACING.toString(),
                wordSpacing: DEFAULT_TEXTCOLORS_WORD_SPACING.toString(), textAlign: DEFAULT_TEXTCOLORS_TEXT_ALIGN, fontVariant: DEFAULT_TEXTCOLORS_FONT_VARIANT
            });
            break;
        case 'ansi-art-viewer':
            newControl = document.createElement('div');
            newControl.className = 'dropped-control dropped-ansi-art-viewer';
            newControl.dataset.ansiContent = '';
            newControl.innerHTML = `<div class="ansi-art-content-wrapper"><span class="ansi-art-placeholder">Paste ANSI/ASCII art here</span></div>`;
            break;
        case 'html-control':
            newControl = document.createElement('div');
            newControl.className = 'dropped-control dropped-html-control w-full h-48 bg-slate-700/30 border border-slate-600 rounded';
            newControl.style.minHeight = '100px';
            Object.assign(newControl.dataset, { htmlContent: DEFAULT_HTML_CONTENT, cssContent: DEFAULT_CSS_CONTENT, jsContent: DEFAULT_JS_CONTENT });
            newControl.innerHTML = `<iframe class="html-control-render-iframe w-full h-full border-0 pointer-events-none" sandbox="allow-scripts allow-same-origin"></iframe>`;
            break;
        default:
            addMessageToChat('error', `Unknown control type "${controlType}" requested by AI.`);
            state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null);
            return;
    }

    if (newControl) {
        const controlId = generateUniqueId('dc');
        newControl.dataset.controlType = type;
        newControl.dataset.droppedControlId = controlId;
        newControl.draggable = true;
        newControl.addEventListener('dragstart', handleDroppedControlDragStart);
        newControl.addEventListener('dragend', handleDroppedControlDragEnd);
        newControl.addEventListener('click', (e) => handleControlSelection(newControl as HTMLElement, e));

        parentElement.appendChild(newControl);
        state.setLastAiAddedControlId(controlId); 
        state.setLastAiAddedControlType(type);   

        if (initialProperties && typeof initialProperties === 'object') {
            handleAiModifyControlProperties({ controlId: controlId, properties: initialProperties }, newControl); 
        }
        
        if (type === 'row-container' || type === 'column-container') setupDroppable(newControl);
        if (type === 'text-colors') renderTextColorsComponent(newControl);
        if (type === 'ansi-art-viewer') applyStylesToAnsiArtViewer(newControl);
        if (type === 'html-control') setTimeout(() => applyCustomHtmlCode(newControl!), 0);

        updatePlaceholderVisibility(parentElement, parentElement.id === 'layer-2' ? '.layer2-empty-placeholder' : (parentElement.classList.contains('decorative-element') ? '.decorative-element-empty-placeholder' : '.container-empty-placeholder'));
        
        addMessageToChat('ai', `Added a new ${type} control with ID ${controlId} to ${actualParentId}.`);
        handleControlSelection(newControl); 
    } else {
        state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null);
    }
}

function handleAiDeleteControl(config: any) {
    const { controlId } = config;
    if (!controlId) {
        addMessageToChat('error', 'AI response for deleting control was missing controlId.');
        return;
    }

    const controlToDelete = document.querySelector(`[data-dropped-control-id="${controlId}"]`) as HTMLElement;
    if (controlToDelete) {
        const parent = controlToDelete.parentElement;
        if (parent) {
            parent.removeChild(controlToDelete);
            updatePlaceholderVisibility(parent, parent.id === 'layer-2' ? '.layer2-empty-placeholder' : (parent.classList.contains('decorative-element') ? '.decorative-element-empty-placeholder' : '.container-empty-placeholder'));
        }
        if (state.selectedDroppedControl === controlToDelete) {
            state.setSelectedDroppedControl(null);
            // updatePanelForNoSelection(); // This is handled by selectElement(null) if needed
        }
        addMessageToChat('ai', `Control with ID ${controlId} deleted.`);
    } else {
        addMessageToChat('error', `Control with ID "${controlId}" not found for deletion.`);
    }
    state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null); // Clear context
}

function handleAiModifyControlProperties(config: any, targetControl?: HTMLElement) {
    const { controlId, properties } = config;
    if (!controlId || typeof properties !== 'object') {
        addMessageToChat('error', 'AI response for modifying control properties was missing controlId or properties.');
        return;
    }

    const control = targetControl || document.querySelector(`[data-dropped-control-id="${controlId}"]`) as HTMLElement;
    if (!control) {
        addMessageToChat('error', `Control with ID "${controlId}" not found for modification.`);
        return;
    }

    let changesMade = false;
    for (const propName in properties) {
        const propValue = properties[propName];
        changesMade = true;
        const lowerPropName = propName.toLowerCase();

        // Generic Properties
        if (lowerPropName === 'visible') control.style.display = Boolean(propValue) ? '' : 'none';
        else if (lowerPropName === 'textcontent') {
            if (control.tagName === 'INPUT' || control.tagName === 'TEXTAREA') (control as HTMLInputElement | HTMLTextAreaElement).value = String(propValue);
            else control.textContent = String(propValue);
        }
        else if (lowerPropName === 'placeholder' && (control.tagName === 'INPUT' || control.tagName === 'TEXTAREA')) (control as HTMLInputElement | HTMLTextAreaElement).placeholder = String(propValue);
        else if (lowerPropName === 'imagesrc') {
            if (control.tagName === 'IMG') (control as HTMLImageElement).src = String(propValue);
            else if (control.dataset.controlType === 'image-element') control.style.backgroundImage = String(propValue) ? `url('${String(propValue)}')` : 'none';
        }
        else if (lowerPropName === 'width') control.style.width = String(propValue);
        else if (lowerPropName === 'height') control.style.height = String(propValue);
        else if (lowerPropName === 'bgcolor' || lowerPropName === 'backgroundcolor') control.style.backgroundColor = String(propValue);
        else if (lowerPropName === 'textcolor') control.style.color = String(propValue);
        else if (lowerPropName === 'opacity') control.style.opacity = String(propValue);
        // Border
        else if (lowerPropName === 'borderradius') control.style.borderRadius = String(propValue).endsWith('px') ? String(propValue) : `${propValue}px`;
        else if (lowerPropName === 'borderwidth') control.style.borderWidth = String(propValue).endsWith('px') ? String(propValue) : `${propValue}px`;
        else if (lowerPropName === 'borderstyle') control.style.borderStyle = String(propValue);
        else if (lowerPropName === 'bordercolor') control.style.borderColor = String(propValue);
        // Box Shadow
        else if (lowerPropName.startsWith('boxshadow')) {
            const currentShadow = control.style.boxShadow && control.style.boxShadow !== 'none' ? control.style.boxShadow.split(' ') : ['0px', '0px', '0px', 'rgba(0,0,0,0)'];
            let x = '0px', y = '0px', blur = '0px', color = 'rgba(0,0,0,0)';
            
            const colorMatch = control.style.boxShadow.match(/(rgba?\(.+?\)|#([0-9a-fA-F]{3}){1,2}(?:[0-9a-fA-F]{2})?)/);
            let remainingShadow = control.style.boxShadow;
            if (colorMatch) {
                color = colorMatch[0];
                remainingShadow = remainingShadow.replace(color, '').trim();
            }
            const parts = remainingShadow.split(/\s+/).filter(Boolean); 

            if (parts.length >= 3) { 
                 x = parts[0]; y = parts[1]; blur = parts[2];
            }
            
            if (lowerPropName === 'boxshadowx') x = String(propValue).endsWith('px') ? String(propValue) : `${propValue}px`;
            else if (lowerPropName === 'boxshadowy') y = String(propValue).endsWith('px') ? String(propValue) : `${propValue}px`;
            else if (lowerPropName === 'boxshadowblur') blur = String(propValue).endsWith('px') ? String(propValue) : `${propValue}px`;
            else if (lowerPropName === 'boxshadowcolor') color = String(propValue);
            control.style.boxShadow = (x === '0px' && y === '0px' && blur === '0px' && (color === 'rgba(0,0,0,0)' || color === 'transparent')) ? 'none' : `${x} ${y} ${blur} ${color}`;
        }
        // Typography
        else if (lowerPropName === 'fontfamily') control.style.fontFamily = String(propValue);
        else if (lowerPropName === 'fontsize') control.style.fontSize = String(propValue);
        else if (lowerPropName === 'fontweight') control.style.fontWeight = String(propValue);
        else if (lowerPropName === 'fontstyle') control.style.fontStyle = String(propValue) as FontStyleType;
        else if (lowerPropName === 'lineheight') control.style.lineHeight = String(propValue);
        else if (lowerPropName === 'letterspacing') control.style.letterSpacing = String(propValue);
        else if (lowerPropName === 'texttransform') control.style.textTransform = String(propValue) as TextTransformType;
        else if (lowerPropName === 'textdecoration') control.style.textDecoration = String(propValue) as TextDecorationType;
        // Text Shadow
        else if (lowerPropName.startsWith('textshadow')) {
            const currentTShadow = control.style.textShadow && control.style.textShadow !== 'none' ? control.style.textShadow : '0px 0px 0px rgba(0,0,0,0)';
            let tx = '0px', ty = '0px', tblur = '0px', tcolor = 'rgba(0,0,0,0)';

            const tColorMatch = currentTShadow.match(/(rgba?\(.+?\)|#([0-9a-fA-F]{3}){1,2}(?:[0-9a-fA-F]{2})?)/);
            let remainingTShadow = currentTShadow;
            if (tColorMatch) {
                tcolor = tColorMatch[0];
                remainingTShadow = remainingTShadow.replace(tcolor, '').trim();
            }
            const tParts = remainingTShadow.split(/\s+/).filter(Boolean);
            if (tParts.length >= 3) { tx = tParts[0]; ty = tParts[1]; tblur = tParts[2];}


            if (lowerPropName === 'textshadowx') tx = String(propValue).endsWith('px') ? String(propValue) : `${propValue}px`;
            else if (lowerPropName === 'textshadowy') ty = String(propValue).endsWith('px') ? String(propValue) : `${propValue}px`;
            else if (lowerPropName === 'textshadowblur') tblur = String(propValue).endsWith('px') ? String(propValue) : `${propValue}px`;
            else if (lowerPropName === 'textshadowcolor') tcolor = String(propValue);
            control.style.textShadow = (tx === '0px' && ty === '0px' && tblur === '0px' && (tcolor === 'rgba(0,0,0,0)' || tcolor === 'transparent')) ? 'none' : `${tx} ${ty} ${tblur} ${tcolor}`;
        }
        // Text Alignment
        else if (lowerPropName === 'textalignhorizontal') control.style.textAlign = String(propValue) as TextAlignmentHorizontal;
        else if (lowerPropName === 'textalignvertical') { control.style.display = 'flex'; control.style.alignItems = String(propValue) as FlexAlignItems; if(control.dataset.controlType === 'button') control.style.justifyContent = 'center';}
        // Container Alignment
        else if (lowerPropName === 'containeralignitems') control.style.alignItems = String(propValue) as FlexAlignItems;
        else if (lowerPropName === 'containerjustifycontent') control.style.justifyContent = String(propValue) as FlexJustifyContent;
        // TextColors Specific
        else if (lowerPropName.startsWith('tc')) {
            if (lowerPropName === 'tccontent') control.dataset.textContent = String(propValue);
            else if (lowerPropName === 'tccolor1') control.dataset.color1 = String(propValue);
            else if (lowerPropName === 'tccolor2') control.dataset.color2 = String(propValue);
            else if (lowerPropName === 'tccolor1alpha') control.dataset.color1Alpha = String(propValue);
            else if (lowerPropName === 'tccolor2alpha') control.dataset.color2Alpha = String(propValue);
            else if (lowerPropName === 'tcgradientmode') control.dataset.gradientMode = String(propValue) as TextColorAdvancedGradientMode;
            else if (lowerPropName === 'tccolor1fill') control.dataset.color1Fill = String(propValue);
            else if (lowerPropName === 'tcgradientangle') control.dataset.gradientAngle = String(propValue);
            else if (lowerPropName === 'tccolor2start') control.dataset.color2Start = String(propValue);
            else if (lowerPropName === 'tcfontfamily') control.dataset.fontFamily = String(propValue);
            else if (lowerPropName === 'tcfontsize') control.dataset.fontSize = String(propValue);
            else if (lowerPropName === 'tcfontweight') control.dataset.fontWeight = String(propValue);
            else if (lowerPropName === 'tcfontstyle') control.dataset.fontStyle = String(propValue);
            else if (lowerPropName === 'tcdecorationunderline') control.dataset.decorationUnderline = String(Boolean(propValue));
            else if (lowerPropName === 'tcdecorationoverline') control.dataset.decorationOverline = String(Boolean(propValue));
            else if (lowerPropName === 'tcdecorationlinethrough') control.dataset.decorationLinethrough = String(Boolean(propValue));
            else if (lowerPropName === 'tctexttransform') control.dataset.textTransform = String(propValue);
            else if (lowerPropName === 'tclineheight') control.dataset.lineHeight = String(propValue);
            else if (lowerPropName === 'tcletterspacing') control.dataset.letterSpacing = String(propValue);
            else if (lowerPropName === 'tcwordspacing') control.dataset.wordSpacing = String(propValue);
            else if (lowerPropName === 'tctextalign') control.dataset.textAlign = String(propValue);
            else if (lowerPropName === 'tcfontvariant') control.dataset.fontVariant = String(propValue);
            else { console.warn(`AI tried to set unhandled TextColors property: ${propName}`); changesMade = false; }
            if (changesMade && control.dataset.controlType === 'text-colors') renderTextColorsComponent(control);
        }
        // ANSI Art Specific
        else if (lowerPropName.startsWith('ansi')) {
            const ansiContentWrapper = control.querySelector('.ansi-art-content-wrapper') as HTMLElement | null;
            if (lowerPropName === 'ansicontent') control.dataset.ansiContent = String(propValue);
            else if (lowerPropName === 'ansiwidth') control.style.width = String(propValue);
            else if (lowerPropName === 'ansiheight') control.style.height = String(propValue);
            else if (lowerPropName === 'ansibgcolor') {
                if (ansiContentWrapper) {
                    const bgColorStyle = ansiContentWrapper.style.backgroundColor;
                    const currentAlpha = bgColorStyle ? bgColorStyle.match(/rgba\(.+,\s*([\d.]+)\)/)?.[1] || '1' : '1';
                    ansiContentWrapper.style.backgroundColor = combineHexAndAlphaToRGBA(String(propValue), parseFloat(currentAlpha));
                } else { console.warn(`AI: ANSI content wrapper not found for control ${controlId} when setting 'ansibgcolor'.`); changesMade = false; }
            }
            else if (lowerPropName === 'ansitextcolor') {
                if (ansiContentWrapper) {
                    const textColorStyle = ansiContentWrapper.style.color;
                    const currentAlpha = textColorStyle ? textColorStyle.match(/rgba\(.+,\s*([\d.]+)\)/)?.[1] || '1' : '1';
                    ansiContentWrapper.style.color = combineHexAndAlphaToRGBA(String(propValue), parseFloat(currentAlpha));
                } else { console.warn(`AI: ANSI content wrapper not found for control ${controlId} when setting 'ansitextcolor'.`); changesMade = false; }
            }
            else if (lowerPropName === 'ansibgcoloralpha') {
                if (ansiContentWrapper) {
                    const currentColor = ansiContentWrapper.style.backgroundColor || 'rgb(0,0,0)';
                    ansiContentWrapper.style.backgroundColor = combineHexAndAlphaToRGBA(splitColorToHexAndAlpha(currentColor).hexRGB, parseFloat(String(propValue)));
                } else { console.warn(`AI: ANSI content wrapper not found for control ${controlId} when setting 'ansibgcoloralpha'.`); changesMade = false; }
            }
            else if (lowerPropName === 'ansitextcoloralpha') {
                if (ansiContentWrapper) {
                    const currentColor = ansiContentWrapper.style.color || 'rgb(255,255,255)';
                    ansiContentWrapper.style.color = combineHexAndAlphaToRGBA(splitColorToHexAndAlpha(currentColor).hexRGB, parseFloat(String(propValue)));
                } else { console.warn(`AI: ANSI content wrapper not found for control ${controlId} when setting 'ansitextcoloralpha'.`); changesMade = false; }
            }
            else if (lowerPropName === 'ansiopacity') control.style.opacity = String(propValue);
            else { console.warn(`AI tried to set unhandled ANSI Art property: ${propName}`); changesMade = false; }
            if (changesMade && control.dataset.controlType === 'ansi-art-viewer') applyStylesToAnsiArtViewer(control);
        }
        // HTML Box Specific
        else if (lowerPropName.startsWith('html') || lowerPropName.startsWith('css') || lowerPropName.startsWith('js')) {
            if (lowerPropName === 'htmlcontent') control.dataset.htmlContent = String(propValue);
            else if (lowerPropName === 'csscontent') control.dataset.cssContent = String(propValue);
            else if (lowerPropName === 'jscontent') control.dataset.jsContent = String(propValue);
            else { console.warn(`AI tried to set unhandled HTML Box property: ${propName}`); changesMade = false; }
            if (changesMade && control.dataset.controlType === 'html-control') setTimeout(() => applyCustomHtmlCode(control), 0); // Apply after dataset update
        }
        else {
            console.warn(`AI tried to set unhandled Dropped Control property: ${propName}`);
            changesMade = false;
        }
    }

    if (changesMade) {
        // If the modified control is the currently selected one, update the panel inputs
        if (state.selectedDroppedControl === control) {
            if (control.dataset.controlType === 'text-colors') updateTextColorsComponentInputs(control);
            else if (control.dataset.controlType === 'ansi-art-viewer') updateAnsiArtViewerInputs(control);
            else if (control.dataset.controlType === 'html-control') {
                updateDroppedControlInputs(control); // Update generic styling part
                updateHtmlControlInputs(control); // Update code content part
            }
            else updateDroppedControlInputs(control); // For generic parts and all other controls
        }
        addMessageToChat('ai', `Properties for control ${controlId} updated.`);
    } else {
        addMessageToChat('ai', `No recognized property changes applied for control ${controlId}.`);
    }
    // Only clear context if this is NOT part of a multi-action sequence initiated by AI
    // (targetControl is only passed internally for multi-add with initial props)
    if (!targetControl) {
        state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null); 
    }
}


function processSingleAiAction(actionConfig: any) {
    if (!actionConfig || typeof actionConfig !== 'object') {
        addMessageToChat('error', 'AI action was not a valid object.');
        return;
    }
    const action = actionConfig.action;
    if (!action) {
        addMessageToChat('error', 'AI action object was missing an "action" key.');
        return;
    }

    switch (action) {
        case 'modifyElementProperties':
            if (!actionConfig.elementId || typeof actionConfig.properties !== 'object') {
                addMessageToChat('error', 'AI response for "modifyElementProperties" was missing elementId or properties.');
                return;
            }
            applyAiModifyElementProperties(actionConfig.elementId, actionConfig.properties);
            state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null);
            break;
        case 'addControl':
            handleAiAddControl(actionConfig);
            // lastAiAddedControlId is set within handleAiAddControl on success
            break;
        case 'deleteControl':
            handleAiDeleteControl(actionConfig);
            // lastAiAddedControlId is cleared within handleAiDeleteControl
            break;
        case 'modifyControlProperties':
            handleAiModifyControlProperties(actionConfig);
            // lastAiAddedControlId is cleared within handleAiModifyControlProperties
            break;
        case 'error': 
             addMessageToChat('error', `AI processing error: ${actionConfig.message || 'Unknown error from service.'}`);
             state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null);
            break;
        default:
            addMessageToChat('error', `Unknown action "${action}" requested by AI.`);
            state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null);
    }
}


function applyAiConfigurationChanges(configResponse: any[] | any) {
    if (Array.isArray(configResponse)) {
        addMessageToChat('ai', `Received ${configResponse.length} actions. Attempting to apply them sequentially.`);
        for (const actionConfig of configResponse) {
            processSingleAiAction(actionConfig);
        }
        // Clear context after all actions in a multi-action sequence are processed.
        state.setLastAiAddedControlId(null);
        state.setLastAiAddedControlType(null);
    } else {
        processSingleAiAction(configResponse);
    }
}


async function handleSendPrompt() {
    const apiKey = dom.aiApiKeyInput?.value;
    const originalUserPrompt = dom.aiPromptTextarea?.value; 

    if (!apiKey) {
        addMessageToChat('error', 'API Key is missing. Please enter your Gemini API Key.');
        dom.aiApiKeyInput?.focus();
        return;
    }
    if (!originalUserPrompt) {
        addMessageToChat('error', 'Prompt is empty. Please enter a prompt or command.');
        dom.aiPromptTextarea?.focus();
        return;
    }
    
    saveApiKeyToCookie(apiKey);
    addPromptToHistoryUI(originalUserPrompt); 
    addMessageToChat('user', originalUserPrompt);
    if(dom.aiPromptTextarea) dom.aiPromptTextarea.value = ''; 
    showLoading(true);

    let aiRawResponseString: string = ''; 
    const interactionToSaveInHistory: AiInteraction = { user: originalUserPrompt, aiResponse: '' };

    try {
        const actionType = dom.aiActionGenerateImageRadio?.checked ? 'generateImage' : 'modifyConfig';
        if (actionType === 'generateImage') {
            const imageUrl = await generateImageWithGemini(originalUserPrompt, apiKey);
            aiRawResponseString = JSON.stringify({ action: "generatedImageSuccess", imageUrl: imageUrl });
            const imageId = CURRENT_AI_ACTIVE_IMAGE_ID + '-' + generateUniqueId('img');
            addMessageToChat('image', 'Image generated:', imageUrl, imageId);
            state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null); // Clear context
        } else {
            aiRawResponseString = await interpretConfigurationPrompt(originalUserPrompt, apiKey, state.aiPromptHistory);
            try {
                const configObject = JSON.parse(aiRawResponseString);
                applyAiConfigurationChanges(configObject);
                // Context (lastAiAddedControlId) is managed within applyAiConfigurationChanges / processSingleAiAction
            } catch (e) {
                 const parseErrorMessage = `AI response was not valid JSON or could not be applied. Raw response: ${aiRawResponseString}`;
                 addMessageToChat('error', parseErrorMessage);
                 console.error("Error parsing AI config JSON:", e, "\nReceived string:", aiRawResponseString);
                 state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null);
            }
        }
    } catch (error) {
        let errorMessage = 'An unknown error occurred with the AI service.';
        if (error instanceof Error) {
            errorMessage = error.message;
        }
        addMessageToChat('error', `AI Service Error: ${errorMessage}`);
        console.error("Error communicating with AI service:", error);
        aiRawResponseString = JSON.stringify({ action: "error", message: `AI Service Error: ${errorMessage}` });
        state.setLastAiAddedControlId(null); state.setLastAiAddedControlType(null);
    } finally {
        interactionToSaveInHistory.aiResponse = aiRawResponseString;
        state.addAiPromptToHistory(interactionToSaveInHistory);
        showLoading(false);
    }
}

async function handleReprocessTransparency() {
    if (!state.lastOriginalImageUrl) {
        addMessageToChat('error', "No original image available to reprocess.");
        return;
    }
    showLoading(true);
    try {
        const targetRgb = hexToRgb(state.currentTransparencyTargetColor);
        if (!targetRgb) {
            addMessageToChat('error', "Invalid target color for transparency.");
            showLoading(false);
            return;
        }
        const processedImageUrl = await processImageForTransparency(state.lastOriginalImageUrl, {
            ...targetRgb,
            tolerance: state.currentTransparencyTolerance,
        });
        
        const imageBubbles = dom.aiMessageArea?.querySelectorAll('.ai-image-bubble img');
        const lastImageElement = imageBubbles && imageBubbles.length > 0 ? imageBubbles[imageBubbles.length -1] as HTMLImageElement : null;

        if (lastImageElement && lastImageElement.src === state.lastGeneratedImageUrl) { 
             lastImageElement.src = processedImageUrl;
             state.setLastGeneratedImageUrl(processedImageUrl); 
        } else {
            addMessageToChat('image', 'Reprocessed image:', processedImageUrl, CURRENT_AI_ACTIVE_IMAGE_ID + '-' + generateUniqueId('img'));
        }

        addMessageToChat('ai', "Transparency reprocessed.");

    } catch (error) {
        addMessageToChat('error', `Error reprocessing transparency: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
        showLoading(false);
    }
}


export function setupAiAssistantPanelListeners() {
    // API Key persistence
    const storedApiKey = getApiKeyFromCookie();
    if (storedApiKey && dom.aiApiKeyInput) {
        dom.aiApiKeyInput.value = storedApiKey;
    }
    if (dom.aiApiKeyInput) {
        dom.aiApiKeyInput.addEventListener('change', () => {
            if(dom.aiApiKeyInput) saveApiKeyToCookie(dom.aiApiKeyInput.value);
        });
    }

    if (dom.aiSendPromptButton) {
        dom.aiSendPromptButton.addEventListener('click', handleSendPrompt);
    }
    if (dom.aiPromptTextarea) {
        dom.aiPromptTextarea.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendPrompt();
            }
        });
    }

    if (dom.aiApplyImageBgButton) {
        dom.aiApplyImageBgButton.addEventListener('click', () => {
            if (state.lastGeneratedImageUrl && state.selectedElementId && state.elementsConfig[state.selectedElementId]) {
                state.elementsConfig[state.selectedElementId].imageUrl = state.lastGeneratedImageUrl;
                applyStylesToDecorativeElement(state.selectedElementId);
                updateDecorativeElementInputs(state.elementsConfig[state.selectedElementId]);
                addMessageToChat('ai', `Applied image as background to ${state.selectedElementId}.`);
                if (state.activeTabId !== 'ai') switchTab('element');
            } else if (state.lastGeneratedImageUrl && (!state.selectedElementId || !state.elementsConfig[state.selectedElementId])) {
                state.layer2Config.imageUrl = state.lastGeneratedImageUrl;
                applyStylesToLayer2();
                updateLayer2PanelInputs();
                addMessageToChat('ai', `Applied image as background to Layer 2.`);
                if (state.activeTabId !== 'ai') switchTab('globals');
            }
             else {
                addMessageToChat('error', 'No image or element selected to apply background.');
            }
        });
    }
    
    if (dom.aiModalCloseButton) {
        dom.aiModalCloseButton.addEventListener('click', hideImagePreviewModal);
    }
    if (dom.aiImagePreviewModal) {
        dom.aiImagePreviewModal.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') hideImagePreviewModal();
        });
        dom.aiImagePreviewModal.addEventListener('click', (e) => {
            if (e.target === dom.aiImagePreviewModal) hideImagePreviewModal();
        });
    }

    if (dom.aiTransparencyColorPicker) {
        dom.aiTransparencyColorPicker.value = state.currentTransparencyTargetColor;
        dom.aiTransparencyColorPicker.addEventListener('input', debounce((e) => {
            state.setCurrentTransparencyTargetColor((e.target as HTMLInputElement).value);
        }, 300));
    }
    if (dom.aiTransparencyToleranceSlider && dom.aiTransparencyToleranceValue) {
        dom.aiTransparencyToleranceSlider.value = state.currentTransparencyTolerance.toString();
        dom.aiTransparencyToleranceValue.textContent = state.currentTransparencyTolerance.toString();
        dom.aiTransparencyToleranceSlider.addEventListener('input', debounce((e) => {
            const tolerance = parseInt((e.target as HTMLInputElement).value);
            state.setCurrentTransparencyTolerance(tolerance);
            if(dom.aiTransparencyToleranceValue) dom.aiTransparencyToleranceValue.textContent = tolerance.toString();
        }, 300));
    }
    if (dom.aiReprocessTransparencyButton) {
        dom.aiReprocessTransparencyButton.addEventListener('click', handleReprocessTransparency);
    }

    state.aiPromptHistory.slice().reverse().forEach(interaction => addPromptToHistoryUI(interaction.user));
}