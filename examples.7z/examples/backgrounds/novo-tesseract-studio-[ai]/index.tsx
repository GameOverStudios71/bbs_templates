/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp } from './main';

document.addEventListener('DOMContentLoaded', () => {
  initializeApp();
});
