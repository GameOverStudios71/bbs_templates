
# Tesseract Studio AI Assistant

Welcome to Tesseract Studio! This application allows you to visually design and configure web interfaces. The integrated AI assistant, powered by Google's Gemini models, can help you modify the layout, style elements, manage controls, and even generate images.

## AI Assistant Actions

You can interact with the AI assistant by typing commands in the "AI Assistant" tab. The AI will attempt to understand your request and translate it into actions within the studio.

Below is a table of common actions the AI can perform, along with example prompts you can use:

| Action Category                      | Example User Prompt                                                                                                |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------------------ |
| **Modify Layer-2 Properties**        | "Make layer-2 90% wide and change its background to a dark blue."                                                  |
|                                      | "Set layer-2 padding to 30px and add a light shadow."                                                              |
|                                      | "Apply this image as background to layer-2: [image_url] and set background size to contain."                       |
| **Modify Decorative Element Props**  | "Change element-1 background color to #FF00FF and make it 50vmin tall."                                            |
|                                      | "Set element-3 to be invisible and rotate it by 45 degrees."                                                       |
|                                      | "Apply a blur of 5px to element-5 and increase its brightness."                                                    |
|                                      | "Add a bounce animation to element-2."                                                                             |
|                                      | "Give element-4 a 2vmin solid green border and round its corners significantly."                                     |
| **Add Control (Simple)**             | "Add a button to layer-2."                                                                                         |
|                                      | "Create a new text input inside element-1."                                                                        |
|                                      | "Place a row container in layer-2."                                                                                |
| **Add Control (with Initial Props)** | "Add a button with text 'Submit' and green background to element-2."                                                 |
|                                      | "Create a column container in layer-2, then add a text block with 'Hello' and an image control into that column."    |
| **Delete Control**                   | "Delete the control with ID dc-button-xyz." (Replace with actual ID)                                               |
|                                      | "Remove the text input dc-textinput-abc."                                                                          |
| **Modify Control Properties (Generic)** | "Change the text of control dc-textblock-123 to 'Welcome!'."                                                      |
|                                      | "Make button dc-action-456 200px wide and set its background color to orange."                                     |
|                                      | "Set the image source for control dc-img-789 to [image_url] and give it a 5px border radius."                      |
| **Modify Control Properties (Typography)** | "Set the font size of text block dc-info-001 to 24px and make it bold."                                          |
|                                      | "Change font family of button dc-submit-btn to 'Arial' and its text color to white."                               |
| **Modify Control Properties (TextColors - Adv. Text)** | "For advanced text dc-advtext-ex, set text to 'Gradient Magic', color1 to blue, color2 to purple, and gradient mode to word." |
|                                      | "Change font size of text colors component dc-tc-title to 32px and make it italic."                                |
| **Modify Control Properties (ANSI Art)** | "For ANSI art viewer dc-ansiart-disp, set its content to 'HELLO\nWORLD' and background to black, text to green." |
|                                      | "Make the ansi art control dc-main-art 500px wide and 300px tall."                                                 |
| **Modify Control Properties (HTML Box)** | "For HTML box dc-custom-widget, set HTML to '&lt;h1&gt;New Content&lt;/h1&gt;' and CSS to 'h1 { color: teal; }'."        |
|                                      | "Update the JavaScript for html control dc-interactive-box to 'console.log(\"JS Updated!\");'."                     |
| **Generate Image**                   | (Select "Generate Image" action type) "A neon cat riding a skateboard in a cyberpunk city."                        |
|                                      | (Select "Generate Image" action type) "Abstract painting representing 'creativity'."                               |

**Tips for Interacting with the AI:**

*   **Be Specific:** The more detailed your prompt, the better the AI can understand your intent.
*   **Use Element IDs:** When modifying or deleting specific elements or controls, refer to them by their IDs (e.g., "element-1", "layer-2", "dc-button-xyz"). You can usually find these IDs by selecting the item in the UI.
*   **Iterate:** If the first result isn't perfect, try rephrasing your prompt or providing more context.
*   **Check the Panel:** After the AI makes a change, the relevant properties in the configuration panel should update.

Happy designing!
