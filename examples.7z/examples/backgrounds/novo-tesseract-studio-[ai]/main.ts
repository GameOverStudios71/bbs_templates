

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as dom from './domElements';
import * as state from './state'; // Import state to ensure it's initialized if needed, though direct use might be minimal here
import { initializeDomElements } from './domElements';
import { initializeLayer2Config, setupLayer2PanelListeners, updateLayer2PanelInputs } from './layer2Controller';
import { initializeElementsConfig, setupDecorativeElementPanelListeners, setupDecorativeElementVisibilityControls, updateAllVisibilityToggleButtons } from './decorativeElementController';
import { setupDroppedControlPanelListeners, handlePaletteItemDragStart, setupAnsiArtPanelListeners }  from './droppedControlController';
import { setupTextColorsComponentPanelListeners } from './textColorsComponent';
import { setupHtmlControlPanelListeners } from './htmlControlController'; // New import
import { populateAnimationControls, setupAnimationPanelListeners } from './animationController';
import { setupConfigPanelInteractionListeners, switchTab } from './configPanelManager';
import { updatePanelForNoSelection, selectElement } from './selectionManager';
import { applyStylesToLayer2, applyStylesToDecorativeElement } from './styleUpdater';
import { handleNumberInputMouseWheel } from './utils';
import { setupDroppable } from './droppedControlController';
import { loadPresetsFromLocalStorage, handleSavePreset } from './presetsManager';
import { CURRENT_APP_VERSION, SPLASH_SCREEN_VERSION_KEY } from './constants';
import { setupAiAssistantPanelListeners } from './aiAssistantController'; // New AI Controller import
import type { ControlPaletteItemType } from './types';


function initializeSplashScreen() {
    const splashScreenOverlay = document.getElementById('splash-screen-overlay');
    const closeButton = document.getElementById('splash-screen-close-btn');
    const appVersionSpan = document.getElementById('splash-app-version');
    
    if (!splashScreenOverlay || !closeButton) {
        console.warn('Splash screen elements not found.');
        return;
    }

    if (appVersionSpan) {
        appVersionSpan.textContent = CURRENT_APP_VERSION;
    }

    const versionShownInStorage = localStorage.getItem(SPLASH_SCREEN_VERSION_KEY);

    const showSplash = () => {
        splashScreenOverlay.classList.remove('hidden');
        splashScreenOverlay.setAttribute('aria-hidden', 'false');
        // Optional: focus management, e.g., focus the close button
        // closeButton.focus();
    };

    const hideSplash = () => {
        splashScreenOverlay.classList.add('hidden');
        splashScreenOverlay.setAttribute('aria-hidden', 'true');
        localStorage.setItem(SPLASH_SCREEN_VERSION_KEY, CURRENT_APP_VERSION);
    };

    closeButton.addEventListener('click', hideSplash);

    if (versionShownInStorage !== CURRENT_APP_VERSION) {
        showSplash();
    } else {
        splashScreenOverlay.classList.add('hidden'); 
        splashScreenOverlay.setAttribute('aria-hidden', 'true');
    }
}


export function initializeApp() {
  initializeDomElements();
  initializeSplashScreen(); // Initialize Splash Screen

  if (dom.layer2Element) {
    initializeLayer2Config(); 
    setupDroppable(dom.layer2Element); 
  }
  
  initializeElementsConfig(); // Sets elements to isVisible: false and applies styles
  setupDecorativeElementVisibilityControls(); // Adds listeners to new buttons
  updateAllVisibilityToggleButtons(); // Sets initial appearance of new buttons

  populateAnimationControls(); 

  if (dom.layer2Element) {
      applyStylesToLayer2(); 
      updateLayer2PanelInputs(); // Ensure panel reflects initial state.layer2Config
      setupLayer2PanelListeners();
  } else { 
      // Fallback if layer2Element is somehow not found, apply styles to decorative elements directly
      // This is already handled by initializeElementsConfig's call to applyStylesToDecorativeElement
  }
  
  setupDecorativeElementPanelListeners();
  setupDroppedControlPanelListeners();
  setupTextColorsComponentPanelListeners();
  setupAnsiArtPanelListeners(); 
  setupHtmlControlPanelListeners(); // Setup for new HTML control
  setupAnimationPanelListeners(); 
  setupConfigPanelInteractionListeners(); // This will now set initial panel dimensions
  setupAiAssistantPanelListeners(); // Setup for AI Assistant tab
  console.log('[Tesseract Studio] AI Assistant Controller listeners set up.');
  
  // Initial UI state for selections
  selectElement(null); 
  updatePanelForNoSelection(); 

  // Set initial tab
  switchTab(state.activeTabId); 

  // Global event listeners (like numeric input mouse wheel)
  if (dom.configPanel) {
    const numericInputs = dom.configPanel.querySelectorAll('input[type="number"], input[type="range"]');
    numericInputs.forEach(input => {
        input.addEventListener('wheel', handleNumberInputMouseWheel, { passive: false });
    });
    const isCollapsed = dom.configPanel.classList.contains('collapsed');
    const tabNav = dom.configPanel.querySelector('nav[aria-label="Tabs"]');
    // const tabContentArea = dom.configPanelBody?.querySelector('div.flex-grow'); // Now dom.tabContentAreaContainer
    if (tabNav) (tabNav as HTMLElement).classList.toggle('hidden', isCollapsed);
    if (dom.tabContentAreaContainer) (dom.tabContentAreaContainer as HTMLElement).classList.toggle('hidden', isCollapsed);
  }

  // Control Palette Drag and Visibility
  const ALL_PALETTE_CONTROLS: ControlPaletteItemType[] = ['button', 'text-input', 'row-container', 'column-container', 'text-block', 'image-element', 'text-colors', 'ansi-art-viewer', 'html-control'];
  if(dom.controlPaletteItems) {
      dom.controlPaletteItems.forEach(item => {
          item.addEventListener('dragstart', handlePaletteItemDragStart);
          const controlType = item.dataset.controlType as ControlPaletteItemType;
          if (!ALL_PALETTE_CONTROLS.includes(controlType)) {
              item.classList.add('hidden'); 
          } else {
              item.classList.remove('hidden'); 
          }
      });
  }
  
  // Presets
  if(dom.savePresetButton) dom.savePresetButton.addEventListener('click', handleSavePreset);
  loadPresetsFromLocalStorage();

  // Add global click listener for deselection
  document.addEventListener('click', (event) => {
    const target = event.target as HTMLElement;
    // Check if the click is outside of any selectable elements or the config panel
    if (!target.closest('.decorative-element') && 
        !target.closest('.dropped-control') && 
        !target.closest('#config-panel') && 
        !target.closest('#splash-screen-overlay') &&
        !target.closest('#toggle-config-panel-btn') // Also ignore clicks on the panel toggle button
       ) {
      selectElement(null); // Deselects decorative element
      // If a dropped control was selected, this call to selectElement(null) already cleared it.
      // If nothing was selected, updatePanelForNoSelection handles both Element and Controls tabs.
      if (!state.selectedDroppedControl) { // If no dropped control is active after deselecting decorative element
           updatePanelForNoSelection();
      }
    }
  });

  console.log("Tesseract App Initialized");
}
