# CSS3 only Aperture Science Retro Logo

A Pen created on CodePen.

Original URL: [https://codepen.io/kevingimbel/pen/nKdJOx](https://codepen.io/kevingimbel/pen/nKdJOx).

I love Aperture Science, I love Portal and Portal 2 and I love CSS.