// Handmade Retro Aperture Science Logo 
// (In case you don't know Aperture Science, play Portal!)