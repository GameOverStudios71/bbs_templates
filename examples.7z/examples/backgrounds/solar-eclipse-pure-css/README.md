# Solar Eclipse ☀️ (Pure CSS)

A Pen created on CodePen.

Original URL: [https://codepen.io/ykadosh/pen/GRwLKvV](https://codepen.io/ykadosh/pen/GRwLKvV).

Made with 18 layers of linear, radial & conic gradients.  A "rotate" animation is applied to certain layers to move the rays.

The original (static) gradients were made with the help of 
https://gra.dient.art/ which is a CSS gradient editor that I created: