# writing-mode -- Matrix digital rain (static version)

A Pen created on CodePen.

Original URL: [https://codepen.io/yuanchuan/pen/dBGMMv](https://codepen.io/yuanchuan/pen/dBGMMv).

https://twitter.com/yuanchuan23/status/1136446325501911040
