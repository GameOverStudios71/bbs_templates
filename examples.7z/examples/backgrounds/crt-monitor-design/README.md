# CRT Monitor Design

A Pen created on CodePen.

Original URL: [https://codepen.io/rocknrollinc/pen/GqrYVr](https://codepen.io/rocknrollinc/pen/GqrYVr).

A CTR retro UI screen design prototype, inspired by several sci-fi games and movies. Includes wireframes powered by threejs.
Doubleclick for fullscreen.