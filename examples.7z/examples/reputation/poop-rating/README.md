# poop rating

A Pen created on CodePen.

Original URL: [https://codepen.io/creme/pen/vYrgeNx](https://codepen.io/creme/pen/vYrgeNx).

