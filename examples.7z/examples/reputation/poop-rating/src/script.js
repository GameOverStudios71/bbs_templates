console.clear()

const poopClick = (e) => console.log(`${e.target.value}x 💩`)

const poops = document.querySelectorAll('.rating input')
poops.forEach((poop) => poop.addEventListener('click', poopClick))