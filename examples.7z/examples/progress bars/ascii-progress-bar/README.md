# Ascii progress bar

A Pen created on CodePen.

Original URL: [https://codepen.io/moodyjim/pen/bvNpXZ](https://codepen.io/moodyjim/pen/bvNpXZ).

Messing around with old bbs progress style bars. 