# Neon notification card

A Pen created on CodePen.

Original URL: [https://codepen.io/cleveryeti/pen/YzdVdvR](https://codepen.io/cleveryeti/pen/YzdVdvR).

