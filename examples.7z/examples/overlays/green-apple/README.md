# Green apple

A Pen created on CodePen.

Original URL: [https://codepen.io/moodyjim/pen/MKMKzp](https://codepen.io/moodyjim/pen/MKMKzp).

<strong>More of the same</strong>: particles inside a path. This time I'm using 2 SVG paths drawn on canvas using the Path2D API<br>
Verified on Google, Firefox, Opera & Safari

Forked from [Gabi](http://codepen.io/enxaneta/)'s Pen [Green apple](http://codepen.io/enxaneta/pen/rxEaVL/).