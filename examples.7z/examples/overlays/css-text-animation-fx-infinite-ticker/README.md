# CSS Text Animation FX Infinite Ticker

A Pen created on CodePen.

Original URL: [https://codepen.io/mycodepenusername/pen/ZERNvNo](https://codepen.io/mycodepenusername/pen/ZERNvNo).

