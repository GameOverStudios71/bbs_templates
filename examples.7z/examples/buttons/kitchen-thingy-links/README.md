# Kitchen thingy links

A Pen created on CodePen.

Original URL: [https://codepen.io/creme/pen/QmNyKX](https://codepen.io/creme/pen/QmNyKX).

whats the word for these? kitchenette?? sounds weird.
kitchen sink?