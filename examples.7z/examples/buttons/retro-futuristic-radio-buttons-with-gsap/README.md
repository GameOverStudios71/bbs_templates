# Retro futuristic radio buttons with GSAP

A Pen created on CodePen.

Original URL: [https://codepen.io/jdillon/pen/qEWOGxm](https://codepen.io/jdillon/pen/qEWOGxm).

