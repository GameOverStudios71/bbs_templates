/* This demo Uses Acrtext.js
// https://github.com/codrops/Arctext/
// Inspiration from: https://blog.spoongraphics.co.uk/freebies/6-free-customizable-retrovintage-logos-emblems
*/

$(document).ready(function() {
  $(".line-2").arctext({radius: 700});
});