# Vintage Typography

A Pen created on CodePen.

Original URL: [https://codepen.io/zambo/pen/abObmj](https://codepen.io/zambo/pen/abObmj).

An typography experiment using sass and archtext.js.

Inspiration from: http://blog.spoongraphics.co.uk/freebies/6-free-customizable-retrovintage-logos-emblems