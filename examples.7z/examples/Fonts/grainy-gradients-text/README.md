# Grainy & Gradients text 

A Pen created on CodePen.

Original URL: [https://codepen.io/LukyVj/pen/poOjqBv](https://codepen.io/LukyVj/pen/poOjqBv).

# Grainy & Gradient text
### ChromePen: Best rendering in chrome

Using: 
- color-mix: https://developer.chrome.com/blog/css-color-mix/
- property: https://developer.mozilla.org/fr/docs/Web/CSS/@property
- display-p3 color space: https://css-tricks.com/wide-gamut-color-in-css-with-display-p3/

_For the display-p3 colors,  you can see I used @supports feature detection to fallback on regular hexadecimal colors_

Let me know what you think! 