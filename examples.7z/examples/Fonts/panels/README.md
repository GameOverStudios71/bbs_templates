# Panels

A Pen created on CodePen.

Original URL: [https://codepen.io/robinselmer/pen/zpmeXO](https://codepen.io/robinselmer/pen/zpmeXO).

Full page navigation panels with animation options.