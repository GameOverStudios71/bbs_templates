# Funky Retro Text Shadow

A Pen created on CodePen.

Original URL: [https://codepen.io/mirandawashburn/pen/QWELaGp](https://codepen.io/mirandawashburn/pen/QWELaGp).

INSPIRED BY: 
https://dribbble.com/shots/7725993-Funky-Fresh