/*
INSPIRED BY: 
https://dribbble.com/shots/7725993-Funky-Fresh
*/