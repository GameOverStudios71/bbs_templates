# Neon text flicker glow

A Pen created on CodePen.

Original URL: [https://codepen.io/ganceab/pen/YZvKLQ](https://codepen.io/ganceab/pen/YZvKLQ).

