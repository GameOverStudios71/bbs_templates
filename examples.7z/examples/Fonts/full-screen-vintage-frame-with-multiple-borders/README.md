# Full Screen Vintage Frame with Multiple Borders 

A Pen created on CodePen.

Original URL: [https://codepen.io/chris_tudor/pen/OJPeQgb](https://codepen.io/chris_tudor/pen/OJPeQgb).

