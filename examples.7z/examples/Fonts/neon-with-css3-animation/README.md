# Neon with CSS3 animation

A Pen created on CodePen.

Original URL: [https://codepen.io/interaminense/pen/LNWPgd](https://codepen.io/interaminense/pen/LNWPgd).

Neon example using only CSS3 and AngularJS to change the text that appears with the animation. I hope you enjoy!