# Vintage Neon Sign

A Pen created on CodePen.

Original URL: [https://codepen.io/kylelavery88/pen/jWJGoR](https://codepen.io/kylelavery88/pen/jWJGoR).

Retro diner sign with some keyframes for a flickering effect.  All CSS - No images.