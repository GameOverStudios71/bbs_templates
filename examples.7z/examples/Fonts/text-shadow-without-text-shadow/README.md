# Text Shadow without text-shadow

A Pen created on CodePen.

Original URL: [https://codepen.io/LukyVj/pen/yLRGNJa](https://codepen.io/LukyVj/pen/yLRGNJa).

Found this while working with SVG filters, thought it was cool enough to share :D 