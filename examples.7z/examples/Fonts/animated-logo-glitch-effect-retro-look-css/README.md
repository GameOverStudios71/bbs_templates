# Animated Logo & Glitch Effect & Retro Look (CSS)

A Pen created on CodePen.

Original URL: [https://codepen.io/konstantindenerz/pen/mdGpxKg](https://codepen.io/konstantindenerz/pen/mdGpxKg).

This pen is a part of the retro wave scene:
https://codepen.io/konstantindenerz/pen/WNgEqbG