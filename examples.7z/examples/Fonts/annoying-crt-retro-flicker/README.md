# Annoying CRT retro flicker

A Pen created on CodePen.

Original URL: [https://codepen.io/patrickhlauke/pen/YaoBop](https://codepen.io/patrickhlauke/pen/YaoBop).

Uses a subtly animated double `text-shadow` (green on the left, red on the right) to mimic some retro-looking CRT flicker on white text. Works best with blocky retro pixel fonts. The same effect also work (in a more subdued way) without animation, as a subtle static retro text treatment.