# New retro text

A Pen created on CodePen.

Original URL: [https://codepen.io/vlasterx/pen/zdNZZg](https://codepen.io/vlasterx/pen/zdNZZg).

