# Shimmering neon text

A Pen created on CodePen.

Original URL: [https://codepen.io/comehope/pen/GBwvxw](https://codepen.io/comehope/pen/GBwvxw).

Watch interactive video on Scrimba: https://scrimba.com/p/pEgDAM/cNLqJhR