# Flickering Neon Sign Effect using CSS Text & Box Shadow

A Pen created on CodePen.

Original URL: [https://codepen.io/GeorgePark/pen/MrjbEr](https://codepen.io/GeorgePark/pen/MrjbEr).

This pen shows how the CSS text-shadow and box-shadow properties can be animated to create a flickering neon sign effect. Neon text and border color can be individually changed by updating their respective CSS variables.

