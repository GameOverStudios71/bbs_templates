# Dropcaps

A Pen created on CodePen.

Original URL: [https://codepen.io/robinselmer/pen/OXbgrd](https://codepen.io/robinselmer/pen/OXbgrd).

