# Neon "Open" Sign

A Pen created on CodePen.

Original URL: [https://codepen.io/jshwrnr/pen/gOrZVaQ](https://codepen.io/jshwrnr/pen/gOrZVaQ).

