# Neon Flux

A Pen created on CodePen.

Original URL: [https://codepen.io/Trinca/pen/NrvpWa](https://codepen.io/Trinca/pen/NrvpWa).

A pulsing neon sign made using many overlaid text-shadows. 