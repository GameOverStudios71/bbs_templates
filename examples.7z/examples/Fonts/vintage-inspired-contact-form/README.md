# Vintage Inspired Contact Form

A Pen created on CodePen.

Original URL: [https://codepen.io/dfitzy/pen/VepqMq](https://codepen.io/dfitzy/pen/VepqMq).

**UPDATED: Now mobile-friendly.** A simple, yet effective contact form. Validation not included, but will be made available upon request.