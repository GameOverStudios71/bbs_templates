# Text Effect - Mystique

A Pen created on CodePen.

Original URL: [https://codepen.io/jhnsnc/pen/Egyjbo](https://codepen.io/jhnsnc/pen/Egyjbo).

Experimenting with text effects in SVG. This turned out to be a sort of moving neon gradient outline thing.