# #1236 - Retro CSS logo with slogan

A Pen created on CodePen.

Original URL: [https://codepen.io/littlesnippets/pen/avebgX](https://codepen.io/littlesnippets/pen/avebgX).

Retro logo with slogan