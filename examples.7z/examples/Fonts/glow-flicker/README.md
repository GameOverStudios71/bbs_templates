# Glow Flicker

A Pen created on CodePen.

Original URL: [https://codepen.io/KevinOgden/pen/JEwjBB](https://codepen.io/KevinOgden/pen/JEwjBB).

Flickering neon sign. Almost entirely CSS.