# Easily add a dark color theme via CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/robinselmer/pen/gJNBgg](https://codepen.io/robinselmer/pen/gJNBgg).

