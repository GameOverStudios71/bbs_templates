# Show me the Bodoni

A Pen created on CodePen.

Original URL: [https://codepen.io/EricAnton/pen/AzYaMB](https://codepen.io/EricAnton/pen/AzYaMB).

My first attempt at CSS animations. Just playing around with type and retro gameshow inspired graphics. Any feedback would be appreciated.