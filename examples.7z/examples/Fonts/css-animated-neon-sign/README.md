# CSS animated Neon Sign

A Pen created on CodePen.

Original URL: [https://codepen.io/nodws/pen/WNjXbr](https://codepen.io/nodws/pen/WNjXbr).

Revised version with blinking letters