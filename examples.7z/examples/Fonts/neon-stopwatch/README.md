# Neon Stopwatch

A Pen created on CodePen.

Original URL: [https://codepen.io/FacepalmRobot/pen/JBEKoZ](https://codepen.io/FacepalmRobot/pen/JBEKoZ).

Retro 80's-something stopwatch with neon edges.  Start, pause, resume stop and lap.