# Craft of UI: 3D Split Flap w/ GSAP ✈️

A Pen created on CodePen.

Original URL: [https://codepen.io/jh3y/pen/yyLmeJd](https://codepen.io/jh3y/pen/yyLmeJd).

