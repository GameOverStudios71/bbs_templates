# Bootsnipp Minimal Service Section

A Pen created on CodePen.

Original URL: [https://codepen.io/robinselmer/pen/JGgNXv](https://codepen.io/robinselmer/pen/JGgNXv).

