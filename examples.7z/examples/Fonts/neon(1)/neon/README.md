# NEON

A Pen created on CodePen.

Original URL: [https://codepen.io/shalunts/pen/jYLapb](https://codepen.io/shalunts/pen/jYLapb).

anime.js code borrowed from  Julian Garnier  ;)