# CSS Flickering Light Text Effect

A Pen created on CodePen.

Original URL: [https://codepen.io/mandymichael/pen/aJLYVz](https://codepen.io/mandymichael/pen/aJLYVz).

Flickering light text effect, single element with one flickering letter.
Kind of the reverse neon sign! :D

/* The div isnt really needed its just because this setup made it a bit easier for me for editability with the inputs, option without div and nested span is at the following link
https://codepen.io/mandymichael/pen/OJGjXgO
*/

 
Just playing around with different css properties to create fun text effects

Check out some other cool text effects: http://codepen.io/collection/DamKJW/

