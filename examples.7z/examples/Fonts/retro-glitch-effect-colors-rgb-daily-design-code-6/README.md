# Retro Glitch Effect Colors RGB (Daily Design + Code #6)

A Pen created on CodePen.

Original URL: [https://codepen.io/Juxtopposed/pen/MWPmaww](https://codepen.io/Juxtopposed/pen/MWPmaww).

Daily Design + Code #6

This one is about colors, RGB, and retro vintage 80s TV glitch effects.

Check the design: https://dribbble.com/shots/21293580-Daily-Design-Code-6-Retro-Glitch-Effect-Colors-RGB
Check the collection: https://codepen.io/collection/NqkZMg