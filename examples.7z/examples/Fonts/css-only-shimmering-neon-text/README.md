# CSS-only shimmering neon text

A Pen created on CodePen.

Original URL: [https://codepen.io/giana/pen/qmKNeE](https://codepen.io/giana/pen/qmKNeE).

This is so not what a neon sign looks like, but I stumbled on the effect by accident and thought it looked cool. So.

Select the text and type whatever you want.

Edit 2023: Apparently this is still going around. I've considerably simplified the code using modern CSS. The old version required multiple divs and duplicated text. This newer version is cleaner and easier to update. 

I've saved a fork of the original below:
https://codepen.io/giana/pen/MWxONWm