# Parallax 404 Page

A Pen created on CodePen.

Original URL: [https://codepen.io/ykadosh/pen/wvPOdmb](https://codepen.io/ykadosh/pen/wvPOdmb).

Every site must have a nice 404 page. 

To keep the user engaged in an otherwise disappointing situation, you can add some interactivity.

I made this for my website, using a few layers of SVG.

See it live on my website - https://yoavik.com/404