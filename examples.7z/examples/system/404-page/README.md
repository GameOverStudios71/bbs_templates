# 404 page

A Pen created on CodePen.

Original URL: [https://codepen.io/umarcbs/pen/jOrEgQM](https://codepen.io/umarcbs/pen/jOrEgQM).

This is a 404 error not found page that has a hacker's styling.
