# ascii loaders

A Pen created on CodePen.

Original URL: [https://codepen.io/ltrademark/pen/JBZrYd](https://codepen.io/ltrademark/pen/JBZrYd).

As described; Just a collection of ascii-inspired loaders. All CSS, though if you were to use these, they're single div, so no need to shove them in a component.