# "Hack The Gibson" (CSS)

A Pen created on CodePen.

Original URL: [https://codepen.io/konstantindenerz/pen/poYmNxw](https://codepen.io/konstantindenerz/pen/poYmNxw).

I created this scene with pure CSS. Inspired by the movie Hackers (1995).

✅  Works well with lower resolution in Chrome.