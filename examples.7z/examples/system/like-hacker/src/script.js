let intervalID = window.setInterval(updateScreen, 400)
let c = document.querySelector('#code')

let txt = [
  'FORCE: XX0022. ENCYPT://000.222.2345',
  'TRYPASS: ********* AUTH CODE: ALPHA GAMMA: 1___ PRIORITY 1',
  'RETRY: REINDEER FLOTILLA',
  'Z:> /FALKEN/GAMES/TICTACTOE/ EXECUTE -PLAYERS 0',
  '================================================',
  'Priority 1 // local / scanning...',
  'scanning ports...',
  'BACKDOOR FOUND (23.45.23.12.00000000)',
  'BACKDOOR FOUND (13.66.23.12.00110000)',
  'BACKDOOR FOUND (13.66.23.12.00110044)',
  '...',
  '...',
  'BRUTE.EXE -r -z',
  '...locating vulnerabilities...',
  '...vulnerabilities found...',
  'MCP/> DEPLOY CLU',
  'SCAN: __ 0100.0000.0554.0080',
  'SCAN: __ 0020.0000.0553.0080',
  'SCAN: __ 0001.0000.0554.0550',
  'SCAN: __ 0012.0000.0553.0030',
  'SCAN: __ 0100.0000.0554.0080',
  'SCAN: __ 0020.0000.0553.0080',
  'FFF BJDY **** ++home hack',
  'BACKDOOR FOUND (23.45.23.12.00000000)',
  'BACKDOOR FOUND (13.66.23.12.00110000)',
  'BACKDOOR FOUND (13.66.23.12.00110044)',
  '=============================================',
  '...',
  '...',
  'BRUTE.EXE -r -z',
  '...locating vulnerabilities...',
  '...vulnerabilities found...'
]

let docfrag = document.createDocumentFragment()

function updateScreen() {
    txt.push(txt.shift())
    txt.forEach((e)=>{
        let p =document.createElement('p')
        p.textContent = e
        docfrag.appendChild(p)        
    })
    while(c.firstChild) {
        c.removeChild(c.firstChild)
    }
    c.appendChild(docfrag)
}
