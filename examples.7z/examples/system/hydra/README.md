# hydra

A Pen created on CodePen.

Original URL: [https://codepen.io/alex-page/pen/pXNOYN](https://codepen.io/alex-page/pen/pXNOYN).

Cyberpunk 2077, reboot animation using GPU enhanced motion techniques.