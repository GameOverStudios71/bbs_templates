/**
 * Scroll to top button behavior
 */
const scrollUp = document.querySelector("#scroll-up")
scrollUp.addEventListener("click", () => {
  window.scrollTo({
    top: 0,
    left: 0,
    behavior: "smooth",
  })
})

/**
 * Selector helper function
 */
const select = (element, allInstances = false) => {
  element = element.trim()
  if (allInstances) {
    return [...document.querySelectorAll(element)]
  } else {
    return document.querySelector(element)
  }
}

/**
 * The typing effect ("I'm a...")
 */
const typed = select('.typed')
if (typed) {
  let nouns = typed.getAttribute('data-typed-items')
  nouns = nouns.split(',')
  new Typed('.typed', {
    strings: nouns,
    loop: true,
    typeSpeed: 100,
    backSpeed: 50,
    backDelay: 2000
  })
}

/**
 * Skills animation (in progress)
 */
let skillsContent = select('.skills-content')
if (skillsContent) {
  new Waypoint({
    element: skillsContent,
    offset: '80%',
    handler: function(direction) {
      let progress = select('.progress .progress-bar', true)
      progress.forEach((element) => {
        element.style.width = element.getAttribute('aria-valuenow') + '%'
      })
    }
  })
}

// is it really worth it to keep the form around just to have to waste time with this? in real life, no; do it once. but in portfolio life...? isn't it a chance to show off a form? all i'd be doing is string manipulating things together into an encoded href="mailto:myself" for the submit button though.
let email_content = `Hey Sam! I saw your portfolio on Codepen and wanted to reach out! Would you be available for a phone call on {{ Thursday, September 2 }} at {{ 4pm }} EDT (GMT-4)? I think I have a software engineering role you might be interested in. If that time doesn't work for you, please choose a new time on my Calendly link: {{ https://calendly.com/your-link }}. Here's the job description and salary expectations:`