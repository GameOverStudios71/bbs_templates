# Sam Warner's Portfolio

A Pen created on CodePen.

Original URL: [https://codepen.io/hp-plus5/pen/dyajmxQ](https://codepen.io/hp-plus5/pen/dyajmxQ).

~ Please note that this is not a finished, polished product. This is not "released" code. ~
This is my portfolio visually in a codepen for easier development on my mobile phone. I love to laugh at myself so this design gets to be a bit tongue in cheek on the "hacker" idea I thought I was getting into when I started coding as a kid.