# Carousel Lock Interface

A Pen created on CodePen.

Original URL: [https://codepen.io/jackrugile/pen/RxqdxL](https://codepen.io/jackrugile/pen/RxqdxL).

Having some fun with carousels! Use the sliding carousels to enter the super secret code.

This demo was made with:

- [Flickity](https://flickity.metafizzy.co/) by [Metafizzy](https://metafizzy.co/)
- [howler.js](https://howlerjs.com/) by [James Simpson](https://twitter.com/GoldFireStudios)