# ASCII Loader

A Pen created on CodePen.

Original URL: [https://codepen.io/GilbertL/pen/zPxGBQ](https://codepen.io/GilbertL/pen/zPxGBQ).

