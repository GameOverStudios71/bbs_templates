const DUCKDUCKGO_API = 'https://api.duckduckgo.com/?q=';
const GOOGLE_API = 'https://www.googleapis.com/customsearch/v1';
const GOOGLE_API_KEY = 'YOUR_GOOGLE_API_KEY';
const GOOGLE_CX = 'YOUR_GOOGLE_CUSTOM_SEARCH_CX';
const YANDEX_API = 'https://yandex.com/search/xml'; // Example API

// Perform search function
function performSearch() {
    const searchInput = document.getElementById('searchInput').value.trim();
    if (searchInput === '') {
        alert('Please enter a search query!');
        return false;
    }

    document.getElementById('searchResults').innerHTML = 'Loading results...';

    // Execute search in multiple search engines
    Promise.all([
        searchDuckDuckGo(searchInput),
        searchGoogle(searchInput),
        searchYandex(searchInput)
    ]).then(results => {
        const [duckduckgoResults, googleResults, yandexResults] = results;
        displayResults(duckduckgoResults, googleResults, yandexResults);
    }).catch(error => {
        console.error('Error during search:', error);
        document.getElementById('searchResults').innerHTML = 'Error fetching results.';
    });

    return false; // Prevent form submission
}

// Search DuckDuckGo API
function searchDuckDuckGo(query) {
    return fetch(`${DUCKDUCKGO_API}${query}&format=json&no_html=1`)
        .then(response => response.json())
        .then(data => {
            return data.RelatedTopics.map(topic => ({
                title: topic.Text,
                url: topic.FirstURL,
                description: topic.Text
            }));
        });
}

// Search Google API
function searchGoogle(query) {
    return fetch(`${GOOGLE_API}?key=${GOOGLE_API_KEY}&cx=${GOOGLE_CX}&q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            return data.items.map(item => ({
                title: item.title,
                url: item.link,
                description: item.snippet
            }));
        });
}

// Search Yandex API (replace with correct API)
function searchYandex(query) {
    // This is a placeholder. The real Yandex XML API requires server-side handling.
    // For now, we'll simulate it with an empty result set.
    return new Promise((resolve) => {
        resolve([]); // Return an empty array for now
    });
}

// Display search results on the page
function displayResults(duckduckgoResults, googleResults, yandexResults) {
    const searchResultsDiv = document.getElementById('searchResults');
    searchResultsDiv.innerHTML = ''; // Clear previous results

    const allResults = [...duckduckgoResults, ...googleResults, ...yandexResults];

    if (allResults.length === 0) {
        searchResultsDiv.innerHTML = '<p>No results found.</p>';
        return;
    }

    allResults.forEach(result => {
        const resultItem = document.createElement('div');
        resultItem.className = 'result-item';

        resultItem.innerHTML = `
            <h2><a href="${result.url}" target="_blank">${result.title}</a></h2>
            <p>${result.description}</p>
        `;

        searchResultsDiv.appendChild(resultItem);
    });
}
