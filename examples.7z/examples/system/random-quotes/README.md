# Random Quotes

A Pen created on CodePen.

Original URL: [https://codepen.io/umarcbs/pen/Pozqyaz](https://codepen.io/umarcbs/pen/Pozqyaz).

Random quotes generator.