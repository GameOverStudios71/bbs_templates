# Pretend Hacker

A Pen created on CodePen.

Original URL: [https://codepen.io/FacepalmRobot/pen/dGBKJB](https://codepen.io/FacepalmRobot/pen/dGBKJB).

Fool your friends and coworkers by leaving this on your screen at lunch time. Easily add more techno mumbo-jumbo by adding lines to the "txt" array and reducing the p{} font size (in VW units).