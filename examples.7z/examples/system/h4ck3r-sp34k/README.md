# h4ck3r sp34k

A Pen created on CodePen.

Original URL: [https://codepen.io/ceheiss/pen/QqJpem](https://codepen.io/ceheiss/pen/QqJpem).

A challenge in "JavaScript for kids" was creating an algorithm that transformed text into "hacker text", changing  it's vocals with numbers. 
I thought that bringing it  from the console to the front end should be fun.