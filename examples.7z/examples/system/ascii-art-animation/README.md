# ASCII art animation

A Pen created on CodePen.

Original URL: [https://codepen.io/DUCHu_net/pen/rjvqpr](https://codepen.io/DUCHu_net/pen/rjvqpr).

From my old personal web, many years ago...