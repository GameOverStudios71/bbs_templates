# ASCIICanvas

A Pen created on CodePen.

Original URL: [https://codepen.io/0x04/pen/kYrmwQ](https://codepen.io/0x04/pen/kYrmwQ).

A little ascii paint tool. Completely text based. Just press a key to choose a character for drawing. The current character is also used for creating a new canvas.

The supported tools are free draw, line, rectangle and ellipse. To fill rectangles and ellipse just check "fill".

There's still a problem with using HTML entities (= &), which I should fix in the future.

There are also different color themes which you can choose from.
