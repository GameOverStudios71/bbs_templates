// warning for people using this:
//
// InnerHTML doesnt matter in this use case, but you shouldnt
// use innerHTML to anyone looking :) use innerText
// or build your elements with createNode(). innerHTML
// is a good source of XSS injection

const OutputFinal = "DEVELOPER BATTLE ROYALE";
const delay = 75;
const loops = 20;

let output, temp, len;


function jumble(_current, _len) {
  let text;
  _current.length>0 ? text = _current + "<span id='blinker'>|</span>" : text = _current;
  let possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  for (var i = 0; i < (_len - _current.length); i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  return text;
}

async function intro () {
  let j = 0;
  while(j<=loops){
    j++;
    await sleep(delay);
    loadText(jumble("", len), "target");
  }
  return 0;
}

async function blink (){
  let open;
   window.setInterval(function () {
      if(open){
        document.getElementById("blinker").innerHTML = " |";
        open = false;
      }else{
        document.getElementById("blinker").innerHTML = "";
        open = true;
      }
   }, 400); // repeat forever, polling every 3 seconds
}

async function createText (){
    await sleep(loops * delay);
    for(let i = 1; i <= len; i++){
      loadText(jumble(output.substring(0, i), len), "target")
      await sleep(delay);
    }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


function loadText(_output, target) {
  html = _output;
  document.getElementById(target).innerHTML = html;
}

function doit(){
  output = OutputFinal;
  len = OutputFinal.length;
  intro().then(createText());
}

document.addEventListener("DOMContentLoaded", function() {
  blink();
  doit();
});