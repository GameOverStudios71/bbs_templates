# Text shuffle & distort fx

A Pen created on CodePen.

Original URL: [https://codepen.io/funckysoul/pen/jOOagGw](https://codepen.io/funckysoul/pen/jOOagGw).

A little experiment: the scripts shuffles letters on scroll and resets them when the scroll ends.