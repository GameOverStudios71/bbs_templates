# Text Hover Effect

A Pen created on CodePen.

Original URL: [https://codepen.io/umarcbs/pen/GRqJXqX](https://codepen.io/umarcbs/pen/GRqJXqX).

Hover over social media links: Telegram, Twitter, Medium, Codepen, and Github. It will automatically start effect.