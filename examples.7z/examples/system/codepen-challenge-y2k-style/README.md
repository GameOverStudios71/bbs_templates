# CodePen Challenge: Y2K Style

A Pen created on CodePen.

Original URL: [https://codepen.io/cobra_winfrey/pen/oNmqMER](https://codepen.io/cobra_winfrey/pen/oNmqMER).

Quick exercise with GSAP's nifty draggable & flip plugins