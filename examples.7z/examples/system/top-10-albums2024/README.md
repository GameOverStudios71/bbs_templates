# Top 10 Albums - 2024

A Pen created on CodePen.

Original URL: [https://codepen.io/cobra_winfrey/pen/XJrjyvK](https://codepen.io/cobra_winfrey/pen/XJrjyvK).

Built with GSAP's Draggable, WebAudioAPI, and a fondness for vintage Mac UI.