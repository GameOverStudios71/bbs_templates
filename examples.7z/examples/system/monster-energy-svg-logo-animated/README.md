# Monster Energy SVG logo animated

A Pen created on CodePen.

Original URL: [https://codepen.io/TimPietrusky/pen/nKqrGO](https://codepen.io/TimPietrusky/pen/nKqrGO).

A simple animation for the SVG version of the [monsterenergy.com](http://www.monsterenergy.com/) logo. Why? I love Monster Energy drinks. 

Just :hover to reset the animation. 

You can support this with a vote:

* [Reddit](http://www.reddit.com/r/web_design/comments/1hxcw1/monster_energy_logo_as_svg_and_animated_with_css/)
* [Hacker News](https://news.ycombinator.com/item?id=6012419)


This is a fan remake. Please don't sue me!