# Hacker Text loader

A Pen created on CodePen.

Original URL: [https://codepen.io/umarcbs/pen/MWewgYO](https://codepen.io/umarcbs/pen/MWewgYO).

Hacker Text loader animation