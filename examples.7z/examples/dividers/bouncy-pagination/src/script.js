document.addEventListener("DOMContentLoaded", function () {
	const pages = document.querySelectorAll(".page");
	const prevButton = document.getElementById("prevPage");
	const nextButton = document.getElementById("nextPage");
	let currentPage = 0;

	function showPage(pageNumber) {
		pages.forEach((page, index) => {
			page.classList.remove("current");
			pages[pageNumber].classList.add("current");
			document.body.style.setProperty("--shift", pageNumber);
		});
	}

	function updateButtons() {
		prevButton.disabled = currentPage === 0;
		nextButton.disabled = currentPage === pages.length - 1;
	}

	prevButton.addEventListener("click", function () {
		if (currentPage > 0) {
			currentPage--;
			showPage(currentPage);
			updateButtons();
			document.querySelectorAll("#dots li")[currentPage].click();
		}
	});

	nextButton.addEventListener("click", function () {
		if (currentPage < pages.length - 1) {
			currentPage++;
			showPage(currentPage);
			updateButtons();
			document.querySelectorAll("#dots li")[currentPage].click();
		}
	});

	showPage(currentPage);
	updateButtons();

	let dotNav = document.getElementById("dots"),
		newIndex = 0,
		prevIndex;

	document.querySelectorAll("#dots li").forEach((dot, index) => {
		dot.addEventListener("click", function (e) {
			currentPage = index;
			showPage(currentPage);
			if (document.getElementsByClassName("active")[0]) {
				prevIndex = newIndex;
				newIndex = index;
				updateButtons();
				dotNav.style.setProperty(
					"--timing",
					Math.abs((newIndex - prevIndex) / 5) + 0.5
				);
				document.getElementsByClassName("prev")[0] &&
					document.getElementsByClassName("prev")[0].classList.remove("prev");
				document.getElementsByClassName("active")[0].classList.add("prev");
				document.getElementsByClassName("active")[0].classList.remove("active");
			}
			e.target.classList.add("active");
		});
	});
});
