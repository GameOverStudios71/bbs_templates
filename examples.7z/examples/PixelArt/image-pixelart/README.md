#  image #pixelart 

A Pen created on CodePen.

Original URL: [https://codepen.io/Magda_/pen/LByJpM](https://codepen.io/Magda_/pen/LByJpM).

