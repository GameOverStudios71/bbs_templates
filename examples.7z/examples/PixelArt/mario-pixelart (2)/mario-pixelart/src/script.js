kırmızı: #ee3b39;
kahverengi: #986828;
sarı: #ffcc67;