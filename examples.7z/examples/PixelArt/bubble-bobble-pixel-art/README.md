# Bubble Bobble Pixel Art

A Pen created on CodePen.

Original URL: [https://codepen.io/rainbow-ninja/pen/rNeawJQ](https://codepen.io/rainbow-ninja/pen/rNeawJQ).

