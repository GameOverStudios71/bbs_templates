# Pixelate.js - Color Arrays to Canvas Pixelart

A Pen created on CodePen.

Original URL: [https://codepen.io/MyXoToD/pen/oXyPyK](https://codepen.io/MyXoToD/pen/oXyPyK).

Simply feed the `pixels` array with some colors and see how you can modify the pixels. All 2nd layer arrays are rows and all colors inside are one column each.

GIMME YO FINEST PIXELART! GO!