# Naruto PixelArt CSS JS

A Pen created on CodePen.

Original URL: [https://codepen.io/alexismoragaa/pen/VwbbrKL](https://codepen.io/alexismoragaa/pen/VwbbrKL).

