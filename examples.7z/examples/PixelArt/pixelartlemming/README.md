# PixelArt - Lemming

A Pen created on CodePen.

Original URL: [https://codepen.io/mpoelstra/pen/vYZQbVw](https://codepen.io/mpoelstra/pen/vYZQbVw).

