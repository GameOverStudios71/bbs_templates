# Boba Fett Pixel Art

A Pen created on CodePen.

Original URL: [https://codepen.io/Aleix/pen/NWmmoQE](https://codepen.io/Aleix/pen/NWmmoQE).

Star Wars character Boba Fett on pixelart