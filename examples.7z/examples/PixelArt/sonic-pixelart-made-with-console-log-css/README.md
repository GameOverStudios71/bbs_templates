# Sonic PixelArt made with console.log( ) CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/Danny2006/pen/abmxOdZ](https://codepen.io/Danny2006/pen/abmxOdZ).

