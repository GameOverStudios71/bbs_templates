// Made with Vanilla.js

// Sonic The Hedgehog

// Pixel
var OO = '%c  ';

// Colours
var bg = 'background: ';

var tt = bg + 'transparent'; // Pixel Empty

var aa = bg + '#15219b'; // Blue
var ac = bg + '#283fe9'; // Blue Light
var ao = bg + '#050160'; // Blue Dark

var bl = bg + '#fff'; // White
var ng = bg + '#000'; // Black
var gc = bg + '#b0b0b0'; // Grey Light
var go = bg + '#707070'; // Grey Dark
var am = bg + '#ff0'; // Yellow

var rj = bg + '#f00'; // Red
var ro = bg + '#ac201f'; // Red Dark
var vd = bg + '#499b08'; // Green

var ca = bg + '#efa750'; // Skin
var cc = bg + '#f8f79d'; // Skin Light
var co = bg + '#984f14'; // Skin Dark

function Sonic() {

// 23x33 px
console.log(

// Pixeles   1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23
/*1*/       OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*2*/       OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*3*/       OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*4*/       OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*5*/       OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*6*/       OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*7*/       OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*8*/       OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*9*/       OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*10*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*11*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*12*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*13*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*14*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*15*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*16*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*17*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*18*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*19*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*20*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*21*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*22*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*23*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*24*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*25*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*26*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*27*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*28*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*29*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*30*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*31*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*32*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+'\n'+
/*33*/      OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO+OO
,

// Colores   1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23
/*1*/       tt,tt,tt,tt,tt,tt,aa,aa,aa,aa,aa,aa,aa,tt,tt,aa,ao,tt,tt,tt,tt,tt,tt,
/*2*/       tt,tt,tt,tt,aa,aa,ac,ac,ac,ac,ac,ac,ac,aa,ao,ac,ao,tt,tt,tt,tt,tt,tt,
/*3*/       tt,tt,aa,aa,ac,ac,ac,ac,ac,ac,ac,ac,ac,ao,ac,cc,ao,tt,tt,tt,tt,tt,tt,
/*4*/       tt,aa,aa,ac,ac,ac,aa,aa,aa,aa,ac,ac,aa,ac,cc,cc,aa,ao,aa,aa,aa,aa,ao,
/*5*/       ao,ao,ao,ao,ao,ao,ao,ac,ac,ac,ac,ac,ac,aa,ac,ac,aa,ac,ao,ac,ac,ac,ao,
/*6*/       tt,tt,tt,tt,ao,ac,ac,ac,ac,ac,ac,ac,aa,ac,aa,aa,ac,aa,ac,aa,ac,ao,tt,
/*7*/       tt,tt,tt,ao,ac,ac,ac,ac,ac,ac,ac,ac,ac,aa,bl,bl,aa,ac,ac,ac,ao,tt,tt,
/*8*/       tt,tt,ao,aa,ac,ac,ac,ac,ac,ac,ac,ac,ac,bl,bl,bl,aa,ac,ac,ac,ao,tt,tt,
/*9*/       tt,tt,ao,aa,aa,ac,ac,ao,ao,aa,ac,ac,ac,bl,bl,bl,bl,aa,ac,aa,ao,tt,tt,
/*10*/      tt,ao,aa,aa,aa,ao,ao,aa,ac,ac,ac,ac,ac,bl,bl,bl,vd,aa,ac,aa,ao,tt,tt,
/*11*/      tt,ao,aa,aa,ao,ao,aa,ac,ac,ac,ac,ac,ac,ao,bl,bl,ng,bl,aa,ao,tt,tt,tt,
/*12*/      tt,ao,aa,ao,tt,aa,aa,aa,ac,ac,ac,ca,cc,ca,ca,bl,vd,bl,ao,ao,tt,tt,tt,
/*13*/      tt,ao,ao,tt,ao,aa,aa,aa,aa,ao,aa,ca,co,cc,cc,co,co,co,ca,ng,ng,tt,tt,
/*14*/      tt,ao,tt,tt,ao,aa,aa,aa,ng,ng,ng,ng,ca,cc,cc,cc,cc,ca,co,tt,tt,tt,tt,
/*15*/      tt,ao,tt,tt,ao,aa,ao,ng,tt,tt,ao,ao,ng,ng,ng,co,co,tt,tt,tt,tt,tt,tt,
/*16*/      tt,tt,tt,tt,ao,aa,ng,tt,co,co,cc,cc,aa,ca,co,tt,tt,tt,tt,tt,tt,tt,tt,
/*17*/      tt,tt,tt,tt,ao,ng,tt,co,cc,ca,ng,aa,ac,cc,ca,ng,tt,tt,tt,tt,tt,tt,tt,
/*18*/      tt,tt,tt,tt,tt,ng,co,cc,co,ng,aa,ao,ac,cc,cc,ng,tt,tt,tt,ng,ng,tt,tt,
/*19*/      tt,tt,tt,tt,tt,ng,go,co,ng,ao,ao,ng,ac,ac,ca,ng,co,ng,ng,bl,go,go,tt,
/*20*/      tt,tt,tt,tt,go,bl,bl,bl,go,ng,tt,ng,aa,ac,ao,ng,co,bl,go,bl,go,bl,ng,
/*21*/      tt,tt,tt,ng,bl,bl,bl,gc,bl,ng,ao,ng,ac,aa,ao,tt,ng,gc,go,ng,bl,gc,ng,
/*22*/      tt,tt,tt,ng,bl,bl,bl,gc,bl,ng,tt,ao,ac,ao,aa,ao,tt,ng,ng,gc,bl,ng,tt,
/*23*/      tt,tt,tt,ng,gc,bl,bl,go,ng,tt,ng,ac,aa,tt,ng,aa,tt,tt,ng,ng,ng,tt,tt,
/*24*/      tt,tt,tt,tt,ng,ng,ng,ng,tt,tt,ao,ac,ao,tt,ng,aa,ao,tt,tt,tt,tt,tt,tt,
/*25*/      tt,tt,tt,tt,tt,tt,tt,tt,ng,ao,ac,aa,tt,ng,ng,ao,ng,ng,tt,tt,tt,tt,tt,
/*26*/      tt,tt,tt,tt,tt,tt,tt,tt,ng,bl,ng,ng,go,ng,gc,gc,gc,ng,tt,tt,tt,tt,tt,
/*27*/      tt,tt,tt,tt,tt,tt,tt,ng,go,bl,bl,bl,ng,ng,go,gc,ng,tt,tt,tt,tt,tt,tt,
/*28*/      tt,tt,tt,tt,tt,tt,ng,ro,ro,go,go,ng,tt,ng,ro,ro,gc,gc,ro,ro,tt,tt,tt,
/*29*/      tt,tt,tt,tt,tt,ng,ro,gc,bl,bl,bl,ng,ng,ro,rj,gc,gc,rj,rj,rj,ro,ro,tt,
/*30*/      tt,tt,tt,tt,tt,ng,am,gc,rj,rj,rj,ro,ng,ro,ro,gc,gc,rj,rj,rj,rj,rj,ro,
/*31*/      tt,tt,tt,tt,tt,ng,am,ro,rj,rj,rj,rj,ng,go,go,go,go,gc,gc,gc,gc,gc,go,
/*32*/      tt,tt,tt,tt,tt,ng,ng,gc,bl,bl,bl,gc,ng,ng,ng,ng,ng,ng,ng,ng,ng,ng,ng,
/*33*/      tt,tt,tt,tt,tt,tt,ng,ng,ng,ng,ng,ng,tt,tt,tt,tt,tt,tt,tt,tt,tt,tt,tt

)

};

Sonic();
