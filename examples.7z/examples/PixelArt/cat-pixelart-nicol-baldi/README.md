# cat pixelart nicolò baldi

A Pen created on CodePen.

Original URL: [https://codepen.io/NICOLO-BALDI/pen/XJrPBXp](https://codepen.io/NICOLO-BALDI/pen/XJrPBXp).

