# Pixel Yoshi

A Pen created on CodePen.

Original URL: [https://codepen.io/robinselmer/pen/pJwdwz](https://codepen.io/robinselmer/pen/pJwdwz).

HTML and CSS only Yoshi using floating divs with background color.