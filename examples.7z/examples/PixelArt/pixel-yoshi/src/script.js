/*

Take a truck load of divs
spice 'em with some css
put it in a can
spin it around
and voila:

Pixel Yoshi

*/