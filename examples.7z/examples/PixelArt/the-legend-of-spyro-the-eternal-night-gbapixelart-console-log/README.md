# The Legend Of Spyro: The Eternal Night GBA - PixelArt console.log( )

A Pen created on CodePen.

Original URL: [https://codepen.io/Danny2006/pen/LYxzdyw](https://codepen.io/Danny2006/pen/LYxzdyw).

