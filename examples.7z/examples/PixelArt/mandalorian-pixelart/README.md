# Mandalorian pixelart

A Pen created on CodePen.

Original URL: [https://codepen.io/Aleix/pen/eYoaMYq](https://codepen.io/Aleix/pen/eYoaMYq).

Mandalorian "Mando" Din Djarin's helmet in pixel art, made wiht HTML and CSS