var image = [
  [0,0,0,0,0,0,0,0,1,0,0,0,0,0,0],
  [0,1,1,1,0,0,0,1,0,1,0,1,1,1,0],
  [0,1,1,0,1,0,0,1,0,0,1,0,1,1,0],
  [0,0,1,0,0,1,1,1,1,1,0,0,1,0,0],
  [0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],
  [0,0,0,1,0,1,0,0,0,1,0,1,0,0,0],
  [0,0,0,1,0,0,0,1,0,0,0,1,0,0,0],
  [0,0,1,0,1,0,1,1,1,0,1,0,1,0,0],
  [0,0,1,0,0,0,0,0,0,0,0,0,1,0,0],
  [0,0,1,0,0,1,0,0,0,1,0,0,1,0,0],
  [0,0,1,0,1,1,0,0,0,1,1,0,1,0,0],
  [0,0,1,0,0,0,0,0,0,0,0,0,1,0,0],
  [0,0,0,1,0,0,1,1,1,0,0,1,0,0,0],
  [0,0,0,0,1,1,0,0,0,1,1,0,0,0,0]
];


var container = document.querySelector(".container");
var rendersize = 70;
var render = [];

var width = image[0].length;
var height = image.length;

makeGrid();
drawImage(image);


function makeGrid(){
  clearImage();
  if(width>height){
    container.style.width = rendersize + "rem";
    container.style.height = (height/width*rendersize) + "rem";
  }
  else{
    container.style.height = rendersize + "rem";
    container.style.width = (width/height*rendersize) + "rem";
  }
  container.style.gridTemplateColumns = "repeat(" + width + ",1fr)";
  container.style.gridTemplateRows = "repeat(" + height + ",1fr)";
  
  for(i=0;i<height;i++){
    let row = [];
    for(j=0;j<width;j++){
      let elem = document.createElement("div");
      elem.classList.add("pixel");
      container.appendChild(elem);
      row.push(elem);
    }
    render.push(row);
  }
}
function drawImage(img){
  for(i=0;i<height;i++){
    for(j=0;j<width;j++){
      if (img[i][j] == 1){
        render[i][j].classList.add("on");
      }
      else{
        render[i][j].classList.remove("on");
      }
    }
  }
}
function clearImage(){
  // faster than just setting innerHTML to empty;
  // https://jsperf.com/innerhtml-vs-removechild/15
  while(container.firstChild){
    container.removeChild(container.firstChild);
  }
}


// Animation / image update

var image2 = [
  [1,1,1,0,0,0,0,0,0,0,1,1,1,0,0],
  [1,1,0,1,0,0,0,0,0,1,0,1,1,0,0],
  [0,1,0,0,1,1,1,1,1,0,0,1,1,1,0],
  [0,0,1,0,0,0,0,0,0,0,1,0,0,0,1],
  [0,0,1,0,1,0,0,0,1,0,1,0,0,1,0],
  [0,0,1,0,0,0,1,0,0,0,1,0,1,0,0],
  [0,1,0,1,0,1,1,1,0,1,0,1,1,1,0],
  [0,1,0,0,0,0,0,0,0,0,0,1,0,0,1],
  [0,1,0,0,1,0,0,0,1,0,0,1,0,1,0],
  [0,1,0,1,1,0,0,0,1,1,0,1,1,0,0],
  [0,1,0,0,0,0,0,0,0,0,0,1,0,0,0],
  [0,0,1,1,1,0,0,0,0,0,1,0,0,0,0],
  [0,0,1,0,0,1,1,1,1,1,0,0,0,0,0],
  [0,0,0,1,1,0,0,0,0,0,0,0,0,0,0]
];

var image3 = [
  [0,0,1,1,1,0,0,0,0,0,0,0,1,1,1],
  [0,0,1,1,0,1,0,0,0,0,0,1,0,1,1],
  [0,1,1,1,0,0,1,1,1,1,1,0,0,1,0],
  [1,0,0,0,1,0,0,0,0,0,0,0,1,0,0],
  [0,1,0,0,1,0,1,0,0,0,1,0,1,0,0],
  [0,0,1,0,1,0,0,0,1,0,0,0,1,0,0],
  [0,1,1,1,0,1,0,1,1,1,0,1,0,1,0],
  [1,0,0,1,0,0,0,0,0,0,0,0,0,1,0],
  [0,1,0,1,0,0,1,0,0,0,1,0,0,1,0],
  [0,0,1,1,0,1,1,0,0,0,1,1,0,1,0],
  [0,0,0,1,0,0,0,0,0,0,0,0,0,1,0],
  [0,0,0,0,1,0,0,0,0,0,1,1,1,0,0],
  [0,0,0,0,0,1,1,1,1,1,0,0,1,0,0],
  [0,0,0,0,0,0,0,0,0,0,1,1,0,0,0]
]

var steps = [image, image2, image, image3];
var currStep = 0;

setInterval(function(){
  drawImage(steps[currStep]);
  if (currStep == (steps.length-1)){
    currStep = 0;
  }
  else{
    currStep++;
  }
},250);

