# CSS Grid +JS = Pixelart

A Pen created on CodePen.

Original URL: [https://codepen.io/Rosefae/pen/dwpEVM](https://codepen.io/Rosefae/pen/dwpEVM).

Essentially emulates a small pixel-based LCD display. Uses CSS grid to render the image given a matrix. If you want to change anything (for example make an animation), just you can call the pixel from the render matrix using its coords.

Can also be easily extended to emulate richer color spaces, though at a certain point it will be easier to just set the background color directly rather than having a class name for every possible color, and maybe even just populate the matrix with the hex code.