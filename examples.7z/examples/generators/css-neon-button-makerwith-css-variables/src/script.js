const outputCSS = () => {
  const button = document.querySelector('.neons button:first-of-type');
    const buttonCss = getComputedStyle(button);
        
    document.querySelector('.result pre code').innerHTML = `
appearance: ${buttonCss.appearance};
border: ${buttonCss.border};
-webkit-font-smoothing: ${buttonCss.webkitFontSmoothing};
border-radius: ${buttonCss.borderRadius};
display: ${buttonCss.display};
padding: ${buttonCss.padding};
justify-content: ${buttonCss.justifyContent};
cursor: ${buttonCss.cursor};
font-weight: ${buttonCss.fontWeight};
font-size: ${buttonCss.fontSize};
letter-spacing: ${buttonCss.letterSpacing};
text-align: ${buttonCss.textAlign};
text-transform: ${buttonCss.textTransform};
font-family: ${buttonCss.fontFamily};

/* Color */
color: ${buttonCss.color};
text-shadow: ${buttonCss.textShadow};

/* Background */
background: ${buttonCss.background};

box-shadow: ${buttonCss.boxShadow};

transition: ${buttonCss.transition};
will-change: ${buttonCss.willChange};
    `
}

const controls = ["hue", "saturation", "light", "gradient-light"];

controls.map((control) => {
  document.querySelector(`input#${control}`).addEventListener("input", (e) => {
    if (control !== "hue") {
      document.documentElement.style.setProperty(
        `--${control}`,
        `${e.target.value}%`
      );
    } else {
      document.documentElement.style.setProperty(
        `--${control}`,
        e.target.value
      );
    }
    
    outputCSS();
  });
});


document.getElementById('gradient').addEventListener('click', e => {
  if (e.target.checked) {
    document.getElementById('grad-section').style.display="block"
  } else {
    document.getElementById('grad-section').style.display="none";
    document.documentElement.style.removeProperty('--gradient-light')
  }
});
/* 
- them: Nooooo don't do this you can't do this it's not allowed >:'( 
- me: lol, background-color go brr brr :D :p 
*/

document.getElementById('animate').addEventListener('click', e => {
  if (e.target.checked) {
    var i = 0;
    setInterval(() => {
      if (i <= 359) {
        i++;
        document.documentElement.style.setProperty(
          `--hue`,
          i
        );
        document.getElementById('hue').value=i;
        document.getElementById('hue').nextElementSibling.value=i;
        outputCSS();
      } else {
        i = 0
      }
    }, 100)
  }
})