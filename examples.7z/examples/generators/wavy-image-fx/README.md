# Wavy image FX

A Pen created on CodePen.

Original URL: [https://codepen.io/njmcode/pen/QbLyNB](https://codepen.io/njmcode/pen/QbLyNB).

Emulating the classic 'tech-tech' effect seen on so many 80s and 90s demoscene productions.  Uses drawImage() with a calculated sine offset to render an image one pixel-line at a time.  Probably not very performant, but hey.  Are my methods... unsound?