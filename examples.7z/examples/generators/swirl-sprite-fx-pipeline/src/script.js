/* global colors, Phaser, Tweakpane */

/**
 * SwirlSpriteFX
 *
 * @author       Richard Davey <rich@photonstorm.com>
 * @copyright    2022 Photon Storm Ltd.
 */

const fragShader = `
 #define SHADER_NAME SWIRL_FS

 precision mediump float;

 uniform sampler2D uMainSampler;
 uniform vec2 uResolution;
 uniform vec2 uCoords;
 uniform float uRadius;
 uniform float uStrength;

 varying vec2 outTexCoord;

 #define PI 3.14159

 void main ()
 {
     float effectAngle = uStrength * PI;

     vec2 uv = outTexCoord - uCoords;

     float len = length(uv * vec2(uResolution.x / uResolution.y, 1.0));
     float angle = atan(uv.y, uv.x) + effectAngle * smoothstep(uRadius, 0.0, len);
     float radius = length(uv);

     gl_FragColor = texture2D(uMainSampler, vec2(radius * cos(angle), radius * sin(angle)) + uCoords);
 }
 `;

export default class SwirlSpriteFX extends Phaser.Renderer.WebGL.Pipelines
  .SpriteFXPipeline {
  constructor(game) {
    super({
      game,
      fragShader
    });

    this.x = 0.5;
    this.y = 0.5;
    this.radius = 0.25;
    this.strength = 1;
  }

  onPreRender() {
    this.set2f("uCoords", this.x, this.y);
    this.set1f("uRadius", this.radius);
    this.set1f("uStrength", this.strength);
  }

  onDraw(renderTarget) {
    this.set2f("uResolution", renderTarget.width, renderTarget.height);

    this.drawToGame(renderTarget);
  }
}

class Example extends Phaser.Scene {
  preload() {
    this.load.image("logo", "assets/sprites/phaser3-logo.png");
    this.load.image("bg", "assets/skies/pixelback1.jpg");
  }

  create() {
    const pipeline = this.renderer.pipelines.add(
      "SwirlSpriteFX",
      new SwirlSpriteFX(this.game)
    );

    this.add.image(400, 300, "bg");

    const logo = this.add.image(400, 300, "logo");

    logo.setPipeline(pipeline);
    logo.setFXPadding(128);

    const pane = new Tweakpane.Pane({ title: "SwirlSpriteFX" });

    pane.addInput(pipeline, "x", { min: 0, max: 1 });
    pane.addInput(pipeline, "y", { min: 0, max: 1 });
    pane.addInput(pipeline, "radius", { min: 0, max: 1 });
    pane.addInput(pipeline, "strength", { min: -1, max: 1 });
  }
}

const config = {
  type: Phaser.WEBGL,
  width: 800,
  height: 600,
  scene: Example,
  loader: {
    baseURL: "https://labs.phaser.io",
    crossOrigin: "anonymous"
  }
};

document.getElementById("version").textContent = "Phaser v" + Phaser.VERSION;

new Phaser.Game(config);
