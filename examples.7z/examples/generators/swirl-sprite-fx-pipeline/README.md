# Swirl sprite FX pipeline

A Pen created on CodePen.

Original URL: [https://codepen.io/samme/pen/zYWONqM](https://codepen.io/samme/pen/zYWONqM).

