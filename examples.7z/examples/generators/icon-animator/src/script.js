const STEP_LENGTH = 1;
const CELL_SIZE = 8;
const BORDER_WIDTH = 2;
const MAX_FONT_SIZE = 500;
const MAX_ELECTRONS = 100;
const CELL_DISTANCE = CELL_SIZE + BORDER_WIDTH;

// shorter for brighter paint
// be careful of performance issue
const CELL_REPAINT_INTERVAL = [
    300, // from
    500, // to
];

const BG_COLOR = '#1d2227';
const BORDER_COLOR = '#13191f';
const CELL_HIGHLIGHT = '#328bf6';
const ELECTRON_COLOR = '#00b07c';
const FONT_COLOR = '#ff5353';

const FONT_FAMILY = 'Helvetica, Arial, "Hiragino Sans GB", "Microsoft YaHei", "WenQuan Yi Micro Hei", sans-serif';

const DPR = window.devicePixelRatio || 1;

const ACTIVE_ELECTRONS = [];
const PINNED_CELLS = [];

const MOVE_TRAILS = [
    [0, 1], // down
    [0, -1], // up
    [1, 0], // right
    [-1, 0], // left
].map(([x, y]) => [x * CELL_DISTANCE, y * CELL_DISTANCE]);

const END_POINTS_OFFSET = [
    [0, 0], // left top
    [0, 1], // left bottom
    [1, 0], // right top
    [1, 1], // right bottom
].map(([x, y]) => [
    x * CELL_DISTANCE - BORDER_WIDTH / 2,
    y * CELL_DISTANCE - BORDER_WIDTH / 2,
]);

class FullscreenCanvas {
    constructor(disableScale = false) {
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');

        this.canvas = canvas;
        this.context = context;
        this.disableScale = disableScale;

        this.resizeHandlers = [];
        this.handleResize = _.debounce(::this.handleResize, 100);

        this.adjust();

        window.addEventListener('resize', this.handleResize);
    }

    adjust() {
        const {
            canvas,
            context,
            disableScale,
        } = this;

        const {
            innerWidth,
            innerHeight,
        } = window;

        this.width = innerWidth;
        this.height = innerHeight;

        const scale = disableScale ? 1 : DPR;

        this.realWidth = canvas.width = innerWidth * scale;
        this.realHeight = canvas.height = innerHeight * scale;
        canvas.style.width = `${innerWidth}px`;
        canvas.style.height = `${innerHeight}px`;

        context.scale(scale, scale);
    }

    clear() {
        const { context } = this;

        context.clearRect(0, 0, this.width, this.height);
    }

    makeCallback(fn) {
        fn(this.context, this);
    }

    blendBackground(background, opacity = 0.05) {
        return this.paint((ctx, { realWidth, realHeight, width, height }) => {
            ctx.globalCompositeOperation = 'source-over';
            ctx.globalAlpha = opacity;

            ctx.drawImage(background, 0, 0, realWidth, realHeight, 0, 0, width, height);
        });
    }

    paint(fn) {
        if (!_.isFunction(fn)) return;

        const { context } = this;

        context.save();

        this.makeCallback(fn);

        context.restore();

        return this;
    }

    repaint(fn) {
        if (!_.isFunction(fn)) return;

        this.clear();

        return this.paint(fn);
    }

    onResize(fn) {
        if (!_.isFunction(fn)) return;

        this.resizeHandlers.push(fn);
    }

    handleResize() {
        const { resizeHandlers } = this;

        if (!resizeHandlers.length) return;

        this.adjust();

        resizeHandlers.forEach(::this.makeCallback);
    }

    renderIntoView(target = document.body) {
        const { canvas } = this;

        this.container = target;

        canvas.style.position = 'absolute';
        canvas.style.left = '0px';
        canvas.style.top = '0px';

        target.appendChild(canvas);
    }

    remove() {
        if (!this.container) return;

        try {
            window.removeEventListener('resize', this.handleResize);
            this.container.removeChild(this.canvas);
        } catch (e) {}
    }
}

class Electron {
    constructor(
        x = 0,
        y = 0,
        {
            lifeTime = 3 * 1e3,
            speed = STEP_LENGTH,
            color = ELECTRON_COLOR,
        } = {}
    ) {
        this.lifeTime = lifeTime;
        this.expireAt = Date.now() + lifeTime;

        this.speed = speed;
        this.color = color;

        this.radius = BORDER_WIDTH / 2;
        this.current = [x, y];
        this.visited = {};
        this.setDest(this.randomPath());
    }

    randomPath() {
        const {
            current: [x, y],
        } = this;

        const { length } = MOVE_TRAILS;

        const [deltaX, deltaY] = MOVE_TRAILS[_.random(length - 1)];

        return [
            x + deltaX,
            y + deltaY,
        ];
    }

    composeCoord(coord) {
        return coord.join(',');
    }

    hasVisited(dest) {
        const key = this.composeCoord(dest);

        return this.visited[key];
    }

    setDest(dest) {
        this.destination = dest;
        this.visited[this.composeCoord(dest)] = true;
    }

    next() {
        let {
            speed,
            current,
            destination,
        } = this;

        if (Math.abs(current[0] - destination[0]) <= speed / 2 &&
            Math.abs(current[1] - destination[1]) <= speed / 2
        ) {
            destination = this.randomPath();

            let tryCnt = 1;
            const maxAttempt = 4;

            while (this.hasVisited(destination) && tryCnt <= maxAttempt) {
                tryCnt++;
                destination = this.randomPath();
            }

            this.setDest(destination);
        }

        const deltaX = destination[0] - current[0];
        const deltaY = destination[1] - current[1];

        if (deltaX) {
            current[0] += (deltaX / Math.abs(deltaX) * speed);
        }

        if (deltaY) {
            current[1] += (deltaY / Math.abs(deltaY) * speed);
        }

        return [...this.current];
    }

    paintNextTo(layer = new FullscreenCanvas()) {
        const {
            radius,
            color,
            expireAt,
            lifeTime,
        } = this;

        const [x, y] = this.next();

        layer.paint(ctx => {
            ctx.globalAlpha = Math.max(0, expireAt - Date.now()) / lifeTime;
            ctx.fillStyle = color;
            ctx.shadowColor = color;
            ctx.shadowBlur = radius * 5;
            ctx.globalCompositeOperation = 'lighter';

            ctx.beginPath();
            ctx.arc(x, y, radius, 0, Math.PI * 2);
            ctx.closePath();

            ctx.fill();
        });
    }
}

class Cell {
    constructor(
        row = 0,
        col = 0,
        {
            electronCount = _.random(1, 4),
            background = ELECTRON_COLOR,
            forceElectrons = false,
            electronOptions = {},
        } = {},
    ) {
        this.background = background;
        this.electronOptions = electronOptions;
        this.forceElectrons = forceElectrons;
        this.electronCount = Math.min(electronCount, 4);

        this.startY = row * CELL_DISTANCE;
        this.startX = col * CELL_DISTANCE;
    }

    delay(ms = 0) {
        this.pin(ms * 1.5);
        this.nextUpdate = Date.now() + ms;
    }

    pin(lifeTime = -1 >>> 1) {
        this.expireAt = Date.now() + lifeTime;

        PINNED_CELLS.push(this);
    }

    scheduleUpdate(
        t1 = CELL_REPAINT_INTERVAL[0],
        t2 = CELL_REPAINT_INTERVAL[1],
    ) {
        this.nextUpdate = Date.now() + _.random(t1, t2);
    }

    paintNextTo(layer = new FullscreenCanvas()) {
        const {
            startX,
            startY,
            background,
            nextUpdate,
        } = this;

        if (nextUpdate && Date.now() < nextUpdate) return;

        this.scheduleUpdate();
        this.createElectrons();

        layer.paint(ctx => {
            ctx.globalCompositeOperation = 'lighter';
            ctx.fillStyle = background;
            ctx.fillRect(startX, startY, CELL_SIZE, CELL_SIZE);
        });
    }

    popRandom(arr = []) {
        const ramIdx = _.random(arr.length - 1);

        return arr.splice(ramIdx, 1)[0];
    }

    createElectrons() {
        const {
            startX,
            startY,
            electronCount,
            electronOptions,
            forceElectrons,
        } = this;

        if (!electronCount) return;

        const endpoints = [...END_POINTS_OFFSET];

        const max = forceElectrons ? electronCount : Math.min(electronCount, MAX_ELECTRONS - ACTIVE_ELECTRONS.length);

        for (let i = 0; i < max; i++) {
            const [offsetX, offsetY] = this.popRandom(endpoints);

            ACTIVE_ELECTRONS.push(new Electron(
                startX + offsetX,
                startY + offsetY,
                electronOptions,
            ));
        }
    }
}

const bgLayer = new FullscreenCanvas();
const mainLayer = new FullscreenCanvas();
const shapeLayer = new FullscreenCanvas(true);

function stripOld(limit = 1000) {
    const now = Date.now();

    for (let i = 0, max = ACTIVE_ELECTRONS.length; i < max; i++) {
        const e = ACTIVE_ELECTRONS[i];

        if (e.expireAt - now < limit) {
            ACTIVE_ELECTRONS.splice(i, 1);

            i--;
            max--;
        }
    }
}

function createRandomCell(options = {}) {
    if (ACTIVE_ELECTRONS.length >= MAX_ELECTRONS) return;

    const { width, height } = mainLayer;

    const cell = new Cell(
        _.random(height / CELL_DISTANCE),
        _.random(width / CELL_DISTANCE),
        options,
    );

    cell.paintNextTo(mainLayer);
}

function drawGrid() {
    bgLayer.paint((ctx, { width, height }) => {
        ctx.fillStyle = BG_COLOR;
        ctx.fillRect(0, 0, width, height);

        ctx.fillStyle = BORDER_COLOR;

        // horizontal lines
        for (let h = CELL_SIZE; h < height; h += CELL_DISTANCE) {
            ctx.fillRect(0, h, width, BORDER_WIDTH);
        }

        // vertical lines
        for (let w = CELL_SIZE; w < width; w += CELL_DISTANCE) {
            ctx.fillRect(w, 0, BORDER_WIDTH, height);
        }
    });
}

function iterateItemsIn(list) {
    const now = Date.now();

    for (let i = 0, max = list.length; i < max; i++) {
        const item = list[i];

        if (now >= item.expireAt) {
            list.splice(i, 1);
            i--;
            max--;
        } else {
            item.paintNextTo(mainLayer);
        }
    }
}

function drawItems() {
    iterateItemsIn(PINNED_CELLS);
    iterateItemsIn(ACTIVE_ELECTRONS);
}

let nextRandomAt;

function activateRandom() {
    const now = Date.now();

    if (now < nextRandomAt) {
        return;
    }

    nextRandomAt = now + _.random(300, 1000);

    createRandomCell();
}

function handlePointer() {
    let lastCell = [];
    let touchRecords = {};

    function isSameCell(i, j) {
        const [li, lj] = lastCell;

        lastCell = [i, j];

        return i === li && j === lj;
    };

    function print(isMove, { clientX, clientY }) {
        const i = Math.floor(clientY / CELL_DISTANCE);
        const j = Math.floor(clientX / CELL_DISTANCE);

        if (isMove && isSameCell(i, j)) {
            return;
        }

        const cell = new Cell(i, j, {
            background: CELL_HIGHLIGHT,
            forceElectrons: true,
            electronCount: isMove ? 2 : 4,
            electronOptions: {
                speed: 3,
                lifeTime: isMove ? 500 : 1000,
                color: CELL_HIGHLIGHT,
            },
        });

        cell.paintNextTo(mainLayer);
    }

    const handlers = {
        touchend({ changedTouches }) {
            if (changedTouches) {
                Array.from(changedTouches).forEach(({ identifier }) => {
                    delete touchRecords[identifier];
                });
            } else {
                touchRecords = {};
            }
        },
    };

    function filterTouches(touchList) {
        return Array.from(touchList).filter(({ identifier, clientX, clientY }) => {
            const rec = touchRecords[identifier];
            touchRecords[identifier] = { clientX, clientY };

            return !rec || clientX !== rec.clientX || clientY !== rec.clientY;
        });
    }

    [
        'mousedown',
        'touchstart',
        'mousemove',
        'touchmove',
    ].forEach(name => {
        const isMove = /move/.test(name);
        const isTouch = /touch/.test(name);

        const fn = print.bind(null, isMove);

        handlers[name] = function handler(evt) {
            if (isTouch) {
                filterTouches(evt.touches).forEach(fn);
            } else {
                fn(evt);
            }
        };
    });

    const events = Object.keys(handlers);

    events.forEach(name => {
        document.addEventListener(name, handlers[name]);
    });

    return function unbind() {
        events.forEach(name => {
            document.removeEventListener(name, handlers[name]);
        });
    };
}

function prepaint() {
    drawGrid();

    mainLayer.paint((ctx, { width, height }) => {
        // composite with rgba(255,255,255,255) to clear trails
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, width, height);
    });

    mainLayer.blendBackground(bgLayer.canvas, 0.9);
}

function render() {
    mainLayer.blendBackground(bgLayer.canvas);

    drawItems();
    activateRandom();

    shape.renderID = requestAnimationFrame(render);
}

const shape = {
    lastText: '',
    lastImage: null,
    lastMatrix: null,
    renderID: undefined,
    isAlive: false,

    get electronOptions() {
        return {
            speed: 2,
            color: FONT_COLOR,
            lifeTime: _.random(300, 500),
        };
    },

    get cellOptions() {
        return {
            background: FONT_COLOR,
            electronCount: _.random(1, 4),
            electronOptions: this.electronOptions,
        };
    },

    get explodeOptions() {
        return {
            ...this.cellOptions,
            electronOptions: {
                ...this.electronOptions,
                lifeTime: _.random(500, 1500),
            },
        };
    },

    init(container = document.body) {
        if (this.isAlive) {
            return;
        }

        bgLayer.onResize(drawGrid);
        mainLayer.onResize(prepaint);

        mainLayer.renderIntoView(container);

        shapeLayer.onResize(() => {
            if (this.lastText) {
                this.fillText(this.lastText);
            } else if (this.lastImage) {
                this.drawImage(this.lastImage);
            }
        });

        prepaint();
        render();

        this.unbindEvents = handlePointer();
        this.isAlive = true;
    },

    clear() {
        const {
            lastMatrix,
        } = this;

        this.lastText = '';
        this.lastImage = null;
        this.lastMatrix = null;
        PINNED_CELLS.length = 0;

        if (lastMatrix) {
            this.explode(lastMatrix);
        }
    },

    destroy() {
        if (!this.isAlive) {
            return;
        }

        bgLayer.remove();
        mainLayer.remove();
        shapeLayer.remove();

        this.unbindEvents();

        cancelAnimationFrame(this.renderID);

        ACTIVE_ELECTRONS.length = PINNED_CELLS.length = 0;
        this.lastMatrix = null;
        this.lastText = '';
        this.isAlive = false;
    },

    getMatrix() {
        const {
            width,
            height,
        } = shapeLayer;

        const pixels = shapeLayer.context.getImageData(0, 0, width, height).data;
        const matrix = [];

        for (let i = 0; i < height; i += CELL_DISTANCE) {
            for (let j = 0; j < width; j += CELL_DISTANCE) {
                const alpha = pixels[(j + i * width) * 4 + 3];

                if (alpha > 0) {
                    matrix.push([
                        Math.floor(i / CELL_DISTANCE),
                        Math.floor(j / CELL_DISTANCE),
                    ]);
                }
            }
        }

        return matrix;
    },

    drawImage(image) {
        const {
            naturalWidth: width,
            naturalHeight: height,
        } = image;

        const scaleRatio = Math.min(
            shapeLayer.width * 0.8 / width,
            shapeLayer.height * 0.8 / height,
        );

        this.clear();
        this.spiral();

        this.lastText = '';
        this.lastImage = image;

        shapeLayer.repaint((ctx) => {
            ctx.drawImage(
                image,
                (shapeLayer.width - width * scaleRatio) / 2,
                (shapeLayer.height - height * scaleRatio) / 2,
                width * scaleRatio,
                height * scaleRatio,
            );

            this.render();
        });
    },

    fillText(
        text,
        {
            fontWeight = 'bold',
            fontFamily = FONT_FAMILY,
        } = {},
    ) {
        const {
            width,
            height,
        } = shapeLayer;

        const isBlank = !!this.lastText;

        this.clear();

        if (text !== 0 && !text) {
            if (isBlank) {
                // release
                this.spiral({
                    reverse: true,
                    lifeTime: 500,
                    electronCount: 2,
                });
            }

            return;
        }

        this.spiral();

        this.lastImage = null;
        this.lastText = text;

        shapeLayer.repaint((ctx) => {
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.font = `${fontWeight} ${MAX_FONT_SIZE}px ${fontFamily}`;

            const scale = width / ctx.measureText(text).width;
            const fontSize = Math.min(MAX_FONT_SIZE, MAX_FONT_SIZE * scale * 0.8);

            ctx.font = `${fontWeight} ${fontSize}px ${fontFamily}`;

            ctx.fillText(text, width / 2, height / 2);

            this.render();
        });
    },

    render() {
        const matrix = this.lastMatrix = _.shuffle(this.getMatrix());

        matrix.forEach(([i, j]) => {
            const cell = new Cell(i, j, this.cellOptions);

            cell.scheduleUpdate(200);
            cell.pin();
        });
    },

    spiral({
        radius,
        increment = 0,
        reverse = false,
        lifeTime = 250,
        electronCount = 1,
        forceElectrons = true,
    } = {}) {
        const {
            width,
            height,
        } = mainLayer;

        const cols = Math.floor(width / CELL_DISTANCE);
        const rows = Math.floor(height / CELL_DISTANCE);

        const ox = Math.floor(cols / 2);
        const oy = Math.floor(rows / 2);

        let cnt = 1;
        let deg = _.random(360);
        let r = radius === undefined ? Math.floor(Math.min(cols, rows) / 3) : radius;

        const step = reverse ? 15 : -15;
        const max = Math.abs(360 / step);

        while (cnt <= max) {
            const i = oy + Math.floor(r * Math.sin(deg / 180 * Math.PI));
            const j = ox + Math.floor(r * Math.cos(deg / 180 * Math.PI));

            const cell = new Cell(i, j, {
                electronCount,
                forceElectrons,
                background: CELL_HIGHLIGHT,
                electronOptions: {
                    lifeTime,
                    speed: 3,
                    color: CELL_HIGHLIGHT,
                },

            });

            cell.delay(cnt * 16);

            cnt++;
            deg += step;
            r += increment;
        }
    },

    explode(matrix) {
        stripOld();

        if (matrix) {
            const { length } = matrix;

            const max = Math.min(
                50,
                _.random(Math.floor(length / 20), Math.floor(length / 10)),
            );

            for (let idx = 0; idx < max; idx++) {
                const [i, j] = matrix[idx];

                const cell = new Cell(i, j, this.explodeOptions);

                cell.paintNextTo(mainLayer);
            }
        } else {
            const max = _.random(10, 20);

            for (let idx = 0; idx < max; idx++) {
                createRandomCell(this.explodeOptions);
            }
        }
    },
};

let timer;

function queue() {
    const text = 'naïve';

    let i = 0;
    const max = text.length;

    const run = () => {
        if (i >= max) return;

        shape.fillText(text.slice(0, ++i));
        timer = setTimeout(run, 1e3 + i);
    };

    run();
}

function countdown() {
    const arr = _.range(3, 0, -1);

    let i = 0;
    const max = arr.length;

    const run = () => {
        if (i >= max) {
            shape.clear();
            return galaxy();
        }

        shape.fillText(arr[i++]);
        setTimeout(run, 1e3 + i);
    };

    run();
}

function galaxy() {
    shape.spiral({
        radius: 0,
        increment: 1,
        lifeTime: 100,
        electronCount: 1,
    });

    timer = setTimeout(galaxy, 16);
}

function ring() {
    shape.spiral();

    timer = setTimeout(ring, 16);
}

document.getElementById('input').addEventListener('keypress', ({ keyCode, target }) => {
    if (keyCode === 13) {
        clearTimeout(timer);
        const value = target.value.trim();
        target.value = '';

        switch (value) {
            case '#destroy':
                return shape.destroy();

            case '#init':
                return shape.init();

            case '#explode':
                return shape.explode();

            case '#clear':
                return shape.clear();

            case '#queue':
                return queue();

            case '#countdown':
                return countdown();

            case '#galaxy':
                shape.clear();
                return galaxy();

            case '#ring':
                shape.clear();
                return ring();

            case '#naive':
                shape.clear();
                return elder2();

            case '#elder':
            case '⛱':
                shape.clear();
                return elder();

            default:
                return shape.fillText(value);
        }
    }
});

// prevent zoom

shape.init();
elder();
// shape.fillText('naïve');

document.addEventListener('touchmove', e => e.preventDefault());

const upload = document.getElementById('upload');

upload.addEventListener('change', () => {
    const file = upload.files[0];

    if (!file) return elder2();

    processImage(URL.createObjectURL(file));
});

function processImage(src) {
    const image = new Image();

    image.onload = () => {
        shape.drawImage(image);
    };
    image.onerror = () => {
        shape.fillText('naïve');
    };

    image.src = src;
}

function elder() {
    processImage(
        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPsAAAEOCAYAAABPWmG4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAKTWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/sl0p8zAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAJETSURBVHja7H13nFXF2f93Zk67/W5nYWGBpQiINAErYMGKscXEFqMmGhPf13TTTDXF9J+JGmPyakximiUx9hJjF1SwgKIISF+27+2nzczvj3Pu3buXLcBSFryPn/Gyt5wyZ77z9OchUkqUad/TR06+ePw/Hvvz+g/K/V5w2sen/PXhO1eXn/z+I1qegv1D9fX1536Q7jccDk8tP/Uy2D+QNG5C1XUfPuW08R+U+z3znJPv+egZH5pffvJlsH/gqLm5+b4LLrhg3Qflfl3XxezZs+8pP/ky2D9wJNxc8ugjD8eV55934Qfhfrlr4eij5jeUn3wZ7B84qqqqWtDZ2YlLL730rsaKaM1Bv7kJgZEjR+Laqz99R/npl8H+gaEJNdEaQnJ6zmxD04Q6HH3k9FFzmqoPasArzIVtJnDKSQsvLa+AMtg/EDS2slJf25ZsSyQSUxoaGrB582Z84hOfeI1zflDft6ZpSCaTmDp1Kr7ymctuLa+EMtgPetrQ2WlNGx2PxiMKgjpHUOeYNnU0RjfEZh7M920YHJpigiKN4xcd/qkzF00bX14NZbAf9GSa5qjx48dj69atmDprFlpbWzFp0qQFB7UYrygIhULo7OzEYYcdhrq6uiPyn41SK/TyqiiD/aCjMRF1psKcaFPTKNRVR7Bm+bMYUWXgY+efcd1Jh086KPX2Dx8/r6GuOgRds1BZoQAyiSPmTb/r0Dpt5qE1kZqtTpdVXhllsB90RAjBpEmTljLGkE6nIaWEEAKVlZVoamo6fWJFPHrQ2SnGjr0mFAqBUop0Og1FUTBx4kQ0Nja+xjmPAECjevDddxnsH3BijFhzZ8+CRgnMTAKGSiGsDOIhHfPnTr1DU8xRC6aOO2gW/rHTxukzZkz8cjDEoSgZ2HYbILoxeeIIzJ0zEQoxGxZNHDlFV0RZlC+D/eAiwzC2Tps2DYwxAEA4HIbjOBBCYMqUKZg2bdrbtm0fNPdbUVGByZMngxACKSU0TUM6nUYgEMARRxyBioqKZ9LpNNbkkm3l1VEG+0FFI+vrMG5MIzSFQNcodJWCSRdwLVRVBbBw0Ww4ZteUWSOqDgruPmb0iE+NGBkDERkIkUJNhQ7udMPMtmLG9AmYPKkB2UyqZmHj2Jry6iiD/aCh8ZWV+qxZs66rrKwEYwyKosCyLGiaBsYYNE3DjBkzEIlElrque1Dc87Rp024MBAKQUoIQgmAwCF3XkU6nUVFRgTlz5kDT8IwQorxAymA/eGh9Z6e1aNGiL1NK4TgOVKbAzOYQCgQBIREKMFRXRjD5kPGIxozqA/1+Lzt18eLZM6eCChcOT8MIUDhuBvFYAIKbSGe6MHPWNIxrHAEpzOryCimD/aChj5588vjDDjsMtm3DsiwwxiCEgKZpsCwLwWAQADBp0iRUVFQc8Pc7atSoS8ePHw/XdeE4DgKBADKZDEKhEKSUaG9vx+jRozFu3DgQQsoLpAz2g4e+/sVPrMt1r4NBW1EVckHsBGIGRbK9E1bKQq6jA/XVERy/YA62b1879aTDxk2ZVBGtGR+pPKAs1aMj0ZpT50/Xj1s880LBO9DRthYVQaBl43pEVIr177wNxm2MbqiARBtOPH0WbNpaznUvg/3goE+fde6luq5DVdWCZVoIgXxZMEq9RyGlRCgUwiGHHPKAEAKKoiTXpzoPqKCTzalk23HHHfdafX090uk0xo0bB9M0oaoqUqkUdF1HJBJBNpsFpRT19fWorQ2VK9mUwX5w0BlnnnhHKAhomgvCTAhkIJCCJGkQlgNTTVDFAQhHNGzgiHlz4LiW/nbbgQX0OiPU8NHFx41ftPCoKeGIBqYIBAIUCiMwdB0521NXQqEQrJwJIoH62jpMappQ9rOXwX7g0w1f/Pprs2fPhq7rUBRlh88ZY1BVFZqmAQBUVcX06dNh2zam1hxYkWUtZmbLhz70oXU1NTVIp9OIxWLYvn07YrEYACAQCMAwDHDOC7EGlFJMmzbtmvJKKYP9gKZLTz9n8fEnzJkZDDlgSgaUpkBoGoSmQJQMqJIFVdNgaga6JkGJDSFzqKuPI2jQ16QwRx1I93vFuYvPPXzuZDCWBmBCihwsKwvoCnK5DCKREAiRSKUSCIUDoERBJpPB1GmTMa+xruxrL4P9wKXTTz/98ZEjR+6gp+f97HldHfDi5imlkFLCMAw0NjZCUZTUgXS/F1100T35uIGKigp0d3ejtrYWbiaDfGSgEAK2bUPTNFBKwTnH6NGjC9y/TGWwH3D0hY9/4vrZcyYiqAtoig3Bs5AyBwoXCvOGZDYEycJFGg5Pgqk2FMWFrkscNnMyQmHlgPA/zxlXp//suk+sm3v4eHDRCSlTCIQkCLNhBChS6QQURUEymQQhBLquw3EcEMoRDKgIBlSMGlU1c27DiOjUynJSTBnsBxB9dPHZ488666zrgsEgGGOF+Pd8JBmltKCzCiHAOYdt26CUQlEUKIqCpqamgu99uJOUEqeccsp4QghUVUUul4Nt24jH40ilUgU/ezKZBGMM4XAYuVwOQgiEQiFwzlFTU/O4pmkJznnZWFcG+4FBVbRSP/3Uk9ZNGD8K6e5WEGRhWylA5kDBAUi4roDjuAAIiMLANAqBHOxcNyAzINLGmNG1sMx0zewxVcNel/37P/5oVsQokt2bodMMImEG7qRhWxnkzHRBPQmHw8hms34EoYTKAO6YINLFUUdOh3AzCAYRKa+iMtgPCOoQnVZ9fT1UVYVhGHBdF67rorjVVl5/z3P7vmLDCSHQNO3x4d6i6+NLTlqws/r2QJFykUgEjDGUW5KVwX7A0P9e9KlrRo2qAmQGhsEheAIas8CkAyoEqI9rKYg3JAAQUHAQYgHSBaMCCgMiIQMS7rAWa48+au4zkQjzvAwkB0IsEGKBwgXggkqgb/gKAAIEAgQOqisDUHUXQlo1xzSNKevtZbAPf5o+ffqNoVAIqVQKUkpIKREIBEApLQxCSIHL5f+d/1tKWdDpo9HosOd006dPx85k6fXF1YvvLR6PQ1VVCCGWlldRGewHBI1trAFlaeTMVgjZAcg0dN0GVSxQxkGZ6AV4wiiowsCIBJUet6MUUFSKeDwKCHfY6rBnL5jZUFtXgVR3G5gwAekC0gYEByEShBZvZgyEMAAUEgIQEsTn/iAuAmEVukZAIUCkU86CK4N9+FNlZSWklIVoOSllgfMVc/BijpcHf14SyFvlY7HYsObsI0eOPF3XdZimudvHyN+fpmkwDAOappT19jLYhz+duXChHggRgOQQjjAw1ePoDk9CCBOQJiBsEOlASBcSHFIKeFqtBIgAJIdCCRgjCIUDw3rhN40de52mUGiGCgqx45DEX2Z0h41OQkBCgECCSAGdUYQiGoIhFYTIsvutDPbhTZFIZGbeomwYBhhjoJQWLO99jTw374vja5oGKYfvwq+rq2vI+82HSowxGIYBXdfL+e1lsA9/ymXb12cyHaipiqOjfRui4RBUlcO2kgDS4MSEoA4EdTxOBxWSByBcA6YtIQkDUQLIWgK2JUGgg4Alh+v9plIpCCGQSZsQqAJIAJKokJQDxARYNwhrB2HtEKQTTM3CkWmYThpCAVxKkJMcXFWQMlPIOTa2bO+GGohuLa+mMtiHNWWz2WRlZSUymQyi0SgSiUSh9tpg3CofMy+EgGmaoJSira1tWHO59vb2Zy3LguM4O6Wb5yWYUk9E/vNMJgNVJQvLnL0M9mFPjyx90wIMJFJZqFoYOcuGEAqYEgSICgYCBgkGCRAOEBcEDggcSG5BUwAiBcxcBpRSbNiwAYQMz8c0p6E2un379ns5d6DrGiRsSNgAcQv3BnBI6Q0iOCA4AAHKiOdflxIergWytotEdxq6Fko+ufLdZHk1lcE+7Gnjxo0ghCCbzRZyt/Ocr5SrFXO8fI63oiiFWPlt27b1yowbVouHUmzbtu3GdDrdbwx/X1GDxdl9eU4vpURnZ2ehkk2ZymA/IOiNN9e0xWKjkEhwhEN1cFwNpi1BfH3Ws0wzUClApA1KLFBigYAD0oWh6dCYgo6WLqQTWRDo7cPxPgkhaG1txYYNmwAivLh/4vnNJRxI2GBSgEKC+p4GIVwwIqFSBVL2RA9yLrFpfTMsS4UkWnt5FZXBfkDQqlWrPu04Tp9W9r787Hmul+foiqpCURS8++67EEKcNFzvU1EUZLPZppUrVyKbzfbJzUvvsZiz570RAMA5x9tvvw1CyE7p/2Uqg31Y0O/uvvve1157F6FwLTo6XShKHJAxSIQgZRAcIUDqgFQBqUIKAkgK3QjBtjWA6JBCwZtvrIbCgm0rtrYNS/31xXWbk7bLtr66/C20bkuBSwopGAAFkAogdXCigEsKLikgNQhXh4ThDa5BuBok18FdBSvf2gyFRmDmRLkVVBnsBwZVsUjNyy+//GA4HEZ3d3chkq40Br6UdF33Iu18Drhhw4Y+a9YNJ3Icp+add96p3bZt2y7/Ni/55Dn+1q1bT2KM1dq2XU6C2RuSWHkK9jx18FQbgDN+84Pr5UmLjwRYEDZ3EY1WgogcuJuDdEyAcCiKAl1VQFQVa99di/HjpmLb1gT++vfH0NHtwHK01cP5Xt/tSG8BgDmN1bW3/ub61rqaIAJBFY6bBpiKSLQWhkZhWRZ01cCmDS1Q1AgcrqK7y0LjmLHY3taKX934e3R1kWff3Lat3Ku9zNkPPHr66aebnnzySTQ3N6NuxAi0t7cXglA0TYOqqnBdF4lEAu3bt2PC9Olob2/Hk08+iVdffRWJROKA8jc/+eSTy95++22YpgnDMAB4QTepVAqu62Lbtm0Y29QETdNg2zamTJ2KZDKJ++67Dxs3bvy+qqrlRVPm7Acm/f2J/6z/8PGLRitqYLPCQlDUEbBdC5YjAO75o1WEwBQKpjKsfrMDLzz/Oh55dDneW9cFRYktW7Gt5YDgdMs3treN1dlnTzp54VJC6jF9xiToWhyunYLFOVRVRShUA25XorvLhmsH8d57Cdz+f3/Fgw8/gimHHPrg8o0ry1x9LxIpZxftfTrvhCMbJk8Y/eMFC4+4sCoeQF1dLSpjYRDKkelOoqOzHclkEnf++a/fb97WuWXL1rZ229VfM4z41pfe33zAAODYCWOjppWojkSNmtmHTzv3xBOO/PJhh05EIKDCNE2EQhEYWgytrZ145KGn8Mhjj6OzI3GS7Tpoa01b72Xks+XVUgb7QUFjwsHxm9LZ9YtnTdUroyFTSo5EIoHO9jYkkymEotWx4Wp53x2aUqFP0Q28PWnCWEyYMAFtbR147tllUJiO6qoRtRs3b6/W1MD6d9NdZY5eBvvBSfObGnTpmDWcOxoAMIIopRQ5m6x/Y3vnQQP246eObbCd1KhcJrHUNDkALKyqrLakUNo62hN4O5ldn//uhEA8ujbXXQ6RLYP94KcJoQp9bebg43CTotEahQldUZTNlmU3vVsE8DLtWypb44cJHYxAB4A1yWSbpmlJ0zSnhkKhchhsmbMfnDQ6EGpQVTW5PlkWT8tUBnuZylSmshhfpjKVqQz2A5BGKOVmhWUqi/Fl+oDSEaNG68XhwKqqQkqJ5zasL/vd9wKVw2X3AV1+zrlLJk6ceF19bf38gBFBJBLzMty4iUQigY6OFqTT6dVvvvH6ZalUavW/nn/uA2HQ87vYFgrO53I5EEKM8oopc/YDgiZXxqJjx422Fi8+7u2Fi44aP2LECEC4sG0bY8eOh+M4sCwLlmWBuyakdAHiFXRQgwrWr1+P5a++gddWvH3R+xu2PPvEq2u3HAzzctwh42osO13N4NYQKaIMvBoQOoBbGTzurhkR5LLOSWkrZ0lBk6oRajf0kPXf99aX89vLYB9e9NkLLvrysQuO/MmRR81DIKCiq7sVtm3D0BQ/V10U8tkppWBUgBABQr1nYER0MMbAXYKO9jRWv7MWr7688okVr7354X8+88IBy+1//a2vJRYefWS0pjYOBhdECijEa3MFAP7tw7QlNDUIJaCDu8CW5la8+sprePr5l076w6OPPlFeYWWwDwu67Ybr5ILDD4GqC2iaAkUFQBxIuF4lWW9Z+6/+IicS8Ou2EUIgAgycc5g5F4Kr0PUYMmkXr6xYjZeXvnHtK6+89auX3tk0bPXZsZFYdEMqkQSAY6eMqZk3f9Y1Zy455bqmCQ1wchkEDAqFCBDqgAmvI4wiCQj12l2BhmFbBI4rYHEJqhjIWcCFF182eumG1i3lVVbW2fc51bFwQwv3ijZccc6Sc7/ylWvvOeKII1ARIRDIQQgXruulsBIqAOmBW1FYfo/1X6Vfr8173bx5G0KhEAJGBKqig1KKWCyGo446CocdOvcn48a9dA2A0cN1XjakEsmmylDDYYdNT372s59tnTlrGuxcCt3d3WgYUQszl/DuWkqv0GRRqr6UEuVK8WXOPqyolqkzW7nz+vRRkZrTTjvxus9+7qprOjvbMXZ8PeyOTZBuBi63IaUDprq+Ecqb40L9dyF9qOc7mHotoERAgaIoYFQDdxVkcg64q0A34ggFarF+YyuWv7Ia//rX47F/P//6sBPrzz6m8dyzz/nQPQuPORpC2shkk4hHgjACDGY6AcPQoRCvbjyTPRIOI34fOCUM2+ZwXMByvc44OQu44OIrZqVzYutbzamy7l7m7PuGRmoV+jHHHLN17vgG+bWvfQ1nnHEy3lz5ChobR2PDhg2oUCwwOKCMQFFUMJX4NdF7+rmhN0Pr2XUJKXSQSeWyUFgIjHm6ayaTgZXrRDwex+LFi6GqscQ5CxbW3vfsM8Ni8X/u/POvmzNnzvU33HADjIAKBgnhAuFwGKrKYFk5mKbpN5LIN4XYJXoNQG15BZbBvs9om91lTauLW3++63cYP6EOW5rfxLgJMax/fzmOmj8T29e9DcIkmEpBqYSEBV5ULpkSv4Wzz+Ep4T7Svc/THV1IdnXBchzE4xyhYBQ6I8g5OQjXRqxCwbYtLTjxpJmorg62HnVIQ2zzxs7qzbm9n0l2zCHjdDPbPUqBqAmGtOjE8WNrFiw45q4FRx2Nn33/ak8yUVqxafN6WDkT9SNrEQ4HkUi2g0kLI0dGYWZTgG+gFASQwi/ACYASCrAMJLMhBYNkDGCAoAoEtSAJjQAoc/Yy2Pcd3XLLLYloNIpgMAjGGNasWYNFJx2P7Rve9Tu2esD1aqK7hV7rlFIILvusLFv8XjQaBSiFpmngnMOyOLikUBiDqqrQNA2BQACzZ8/GWWedtfTaG26aurfv+awFC6LhcNg66cQF6444fDZmzjoUQV1FNpuGdFy0tLTAsix0ptdgfNMYxCJRtHe0YNOmTYhEA4jFYjscU5Yq7WUq6+zDie797a3ysJlNaJowAi+/+l/UVBtomliPlW+9ipEjR8L1k9sIzevibsHNRikFt7lXT93vVe51T4H3XQDcAQKBAFSNgHOOrG2Ccw4oChTFgJQqauomoGV7Ctk0ABrHX++6f9nf/3b3GW9s7d4rXO8X37x28+mnndBQXRFEV1cLwgEKQyGAa0PCgc5UMIV4RTRDWaRSKZhmFpqmwQh4vMR1Ha81dfFmJ/N8hoESBYQQKIYD27ZhcQnL0UGVELIWwwUXXYF0js7S9YrVb6xrKUfXlTn73qcZM2ags2szXn11C8aOHQvudmPDhg2YOnUqbNtGLpPzRHYiQAhDwR4nBGzbhkr9hhAgRdwNBQOeZdkghMDl3m9AAcMwICiF6wqk0ynU1HqdXl3XQkVVBEceeeT899asmwlgr/ih4/F4g6ZpSKfTqK6uBrdTkMJBwDBAqArXtOE4LjRNQ1dXFxhjiEaj0HUdlHkqTCBggCgKulrb++xDX6Yy2IcVrX3pQalSC2MqbSgMQGYbKHWgM4Gu5lYwJuHY3VBVFZT67Zcpgaqq4NyBaToIGAydnQlIQVBdPQKGXolM2oTjSBiGATW4GZaVhiNVr8+rLaAxFQZjyLk5BJmDTWteQHVVA4QmsHX1Zkwb3YQrLjj98TOnjzupOZdb9vLa7XvUSl8ZiyAeViFsC1ZyOxgsCGoj51qQcECFCyk5bEsCKiAkgWlZsOxMEajz3oi8CC8A2IVgIkkIJACFKBDEAScApxKEMijQwcBBOUGZqw+NyllvO0G/+v43Erque24xxkAp7dWBVQgBzjkMwyj0a7MsC67rglIKRVFAKUUmk0EkEkF1dTVc18X27dvR2dkJKT2wm6YJTdO8KDrOPS7vushmsxBCFDrCZrOemFxZWQnDMDB69Gice+65j+dyuT1+70NR8wb7bf7zsipZBvuwoHMWH9tw2qkLo4TkwJgFhdmg1BuM2n731SwgPXALIcCoDk0NAiIAM0tg5RSAR8FoJVwnjEyGwXUCqK5uxOjGaTCMOLZt60Q2FYVrVcO1K+A6ERAaBxcGbAuQkkBVGHRNheumIGUaRsAEl22IxLJYdNyhiMeVKQumNu3hfsfC580uBOGQNB/mKkClhCSiMPLALXYz9vV3mcpi/HDV02+vr69Hsn0TJJeQ8CLeQPzebZQWtkwppd+rzetQ6rqezqqqKnQtCMdxEAwGoWkashkLW7duhWVyaJrm9TenOkzTBOey0JOdEOL3e3NhWRbC4TBcl8O2bBDJYNs2QIBQqBJz585d+sJzq/ZZ1pgXQ7AznF32ein9Tr4/e5nKYN+vdOyxsxen09sRDklkMzkQmQGBAxALhPr9yP2Fqus6uEuQy9kwcy4UpoPREDpb02hva8U7a9bjvffeO6K9vf292traKVOnTv3QuHHjjq4fVXGoqlfFQqEKtLe3w+EmDEph2SY05kLVVQgnDdtKQtciABOQqgVGAMfJwnUE1ICLxccdjueeeH7mvDGVbS9v6txzvnfigFBvgOQA2IDkEMRzLUJ4gTISKBvfymA/8GhUrEI/bclxl377ui+go2MLwiOingtNUkASwDcqSSnBBfdebYGAEUEsFkMwICE4QWtLsvO5557/+X+fevFW20UmnU7jsbeFtfgQsuyGu5a/AACXnFAbmjlz5gUfueiy3wkhPEs2OCzbBQOH4vvqVdXrrCKlhKqqIJLCtnPgrgQNUUyZMgVVVVVLtza3Nu1J7l0KYC8QhhQYdZ4z579X/NoXxy7m+OXNoayz73famuiyJk0Yd10ooELTBHK5LlBYgDRBpAUCCwQOiJSgECCSw7Y9ETxghBDQK7F5Q3LTIw8s/fqV33/0h399Mdl578tJ67G3hQUAT7wj8052/PE/rZkv/Pzx3999z9P/s63ZeR2Ig/MAVCUKAg1OTkBlGoJaGERIMEhojELwHLiTASUmOE+gIgQcPmciomF5xNFjaqfsmRViAdQFFBOgFgi1IagDSR1IyiEphyACgoheLamLAV8M6IHBX6Yy2PcTjR49ukFKierqajiOA845OOdegEg+zr0oaCYUCsFxHKRSKTQ3N7tPPfXUDz9344O/3dnzff6Hv7158+bNy/LnyVv3bduGoiiFCLpQKARN0wB4fvhwOFwAzcyZM1FZWXmX4zh7jLNjF8TzMqcug/2ApMkTJ4G7bqEFcaHohEJBiQIqGYiggKAgksGxBGqqRiAarcWqle/983O/fOq3u3rO8//3O1e1d3S/P3LUKJhmFkJwBIIaFEWBlbMArsDMCKS6LQjOoCqhQjSa4BnMmjUOya5mgOYajm4cVTPUOaiqqgJl8IyOUoIpOnQjDE0PQtUC0PQgmKJDYkeXZK/knz5E/NJRyuGLf8sYK/vYy2DfdzSQ+4gQL4Amm8mgo70dq1evfnh3z7N+/fpnstls4Tx57t4fgPLXlI8DIASQUj6+J8Rj0zSRy+WQy+UQiURACEEul4NlWaCUIhAIIBQKed6EskheBvsBC27Qgv8YhHt55/DysQEK4Q8QFRIKVCUI25JobenEmnc2Pr67512xYvmfE8kuSLiQcGBoKuycDe4yCK4AUgNBEEQGQaCBQwcHA1McaMwFpQCBAwk+ZJ+7YwNEBqGr1Qho9QCPw84F4ZghcDsMxwzCdYIgiJV96WWwH3ycvT+dlvrZat3d3ejq6srs7nlu+P1D/8lkMp35Y2uaBtu2/Uw6MaiRi5C+rei7Q6qqIhwOo7qmBhs2bEBnZycAz81oWRa2b9+O5uZmJBKJXlJHmYYflV1vA1qbXAAckjiQxPHyqn3/cm8gSUAqoMSAEYgh0W3+O5u1zL4OeWT9LEUyrz7V0i2v9KuHCleaKlHAiASjnjAhZR7AFJAKJPX0XEkEJABHuHCl63kGGQA29Clobc5h0/oUIkEdAX0sNqxbgzdXvoq33liB9zesQyhk4OSTT8aSM06BlBt3UC+8f5c3gDLYDzTs5yNHSjkq6YkEE0LANM3kQ285AxmUzMHqo1NKFcYYIAHOuedXL+LYBH37tHtz+KFz9ueff/6q995duUSlsubPd93xWZXKaCisPa6AI5F0EYslkEqlQCntFQ3Xl8utbKcvg33YkqAOBHUA6fpc3vWi5sC9oBof5BwSoBKuw2HnbISCkcp+jwlASAk6CBBVFtQZkRCCwrGlX4raKdgSQIQfpw7P3y0lFKr5wOpJ0Bkq3XLPP34L4LcA8PWbf4/ZlXW6rgSgM4IMaUYuLdHZJtDe4qJmJPpMYS2L9mWd/cDk7P1wTCklHMdBNptFdXX1xLNmhAfaSAeNX2eMKfnjuq4LRVEGdFMV+/sBQIg9A/a+KJfLjbYsa5aUcmE+qy/fuqlMZc5+QFK6owPBMTGkchZcZsOFgKReIowCAioBQjR/EhV0tLfA0GMYP37UxEsvvfAOAB8rPeay5tf8Mjb900O3fO8fp3/o2FBnYj2kyEEJULS1tyMYDPqx6IavkHucnApvUzBNIF5ZAaYDNEcQ1A1tT8/Jis4WC8AWAFvm1o+IMt1BfGQY4SoJkCpIwn1NxwUkB5MuCKVg0rN9AADJ180X+Vp83ubJJAEXHJRTUC4hmFcIxMuxK28kZc6+F2nVqlUWY6zgwx5MB66uroaue11dJk6cePzXL1qwcFfP+duvfPnaQw455LSWlhZks1kEAgFQShGJRAaUNgDPcu73SytnkpWpDPZdoeXLXzsjl7OgaQYIYYCkgKSg6GlZRIQDKl1Q6UIyCzZPw7S6MKaxZuSHP3Ly72749GkX7Oz5fvK/H794yYfm/3hEfSDU1bUFuuJA0wmy2RQMQ/VaRRHiVaMlAkS6IDIvKLigqoL2ziSkJGBMhSuFvT/UnL5UnJ15r0xlsO832rJly+p3330XmqbBNM1+v5dfuI7jFHRXx3EwduzYiWedddZNv/vmFV+/dNHcWH+//+plFyy89zc/ueOss866sbq6GplMBpqmIRqNwrZtpFKpHfTv/rLRtmzZAiFEoWLO/rJrDATu0uCbMvDLOvt+p6xp4rnnX8IhU8+HaREYugZCXFCpgsAFIAscHrARDBtQFA2CU3R3dSKXakVVdXXl6WfM+8Fhh4097+8/v+qFNe+uf3z9+vXPhMPh2hmzp18wY8aM8674xAnjOOehxtEUqe41cHkGlVUMjpNENtcFVVHAXRdE+nH4kJ7JnfQGWM4UWLtuExwXUBUd3OLDaj4HapJRBnwZ7PuVHMfB66+/ju7uUxAJhcDdgWs5CiFgWRY0NYhoNArXTiGbzSIYrsDkyZNn1o9qmLlwwQlXBwIBaJoGSTlc14XjeiWturq6YOeyqKyKQjMkWrZvBKiN6qp4v5Z1QohfPQdIJpNYs2YNHAcIhJQzhHD26XwRP8c//5oH8UCmjnK12TLYhwVlsrxty5Z2vPXW+zj6iOngjgNILz5ewgKVLkghVt5r06SqAbhuEpoaRO2IGJKJDFKpzVCVAKKRGIQw4bqe/1xVCTRFQd5m3tXdDiPEoekqKJVQFQHOGaQDMKpAgECCgUsCgIFICgIFREpAMnR1deH995th2QCJ6m2vbmnZ551Piw2DpXXoShs5lqmssw8fsGcy49Pp9NSVK1cuy2Qyg4qolFJUVlZCCIGWlhYIIRCPx3vqzmWz4JwXKtQ6joNczuuD5rou6urqEAqFCtVka2pqoCgKurq6dspnns1m0dnZBdcd3nnlZaCXOfuwow3t5moAOHvx9Ksq4i+8tviE+WgaOxktze/D5QL1dXVeGxfCIV0XdjaDjs40QHTEKnTkchkAGWg6BeBCkwDAIaUJIWTB3+zaHK4NWKbnfmcgMFNeSquu6NCpATvnRdFlLQtV1SOQSZvIWRKW6WLUhElo2bAdN9/8J4TDI+HyLFpaMqv3tVHO4+D5arS9w3ZLy1j5X9pjCTtlKnP2IdPk+mjNhg0b8PzzzyMWi2Hz5s2orq4GYwzZbBa2beP15ct3OVptV0s35b8XCASQSqXgOA7C4TAIIbCTSSSTSXR3dyOdTp/kOM6sfQGgsjW9DPaDit5tTrZ1dpGtb67cavzmt/fCdGLYvC0L1aiH5QSxcXMHpk6fh0SaAyIASM0XmIqEJuL2PSBAiOwJdfUz5D2rOwGTFCzv1wfACEFAV5BOdUG4HIZqQKNBpBM23n+vBYkuiVRGWfbqxvTrK7a27dP+7WXAl8F+UNDG9mQbIQT//ve/p957773LCCGwLAu2baOhoQHpdLpQB253uPvOBqNQSgv57JRSpFIpaJoGx3GwfPnyZZzzhXsrHr5MZZ39A0MrN3ZaAFafMGfSSZFoVeKUxQvQOLoe6WQbtrW3oZ7kk8iLfNv5KjfI9zTz/iYAIBkkQVE3U0AReZD7xxD58lN+TDllME0ToTCFQoHW1u0YOWIi2jsTeOP1d+5dvtl8dl/PS5mjlzn7QUudnZ2488478fTTT2Pr1q1IpVKYNGkSurq6dgso/VV36es913Xhui5CoVDhb0II1qxZg5aWlv02J+UKNWWwH3RUG4pF12zomKkFKmv/eNd9+NmNt6GtK4dNWzpQVTcKVMKPm6egMs/VeZGeLvw6dl6fCUm8bC4BAi7h1V5Hz5Bwen5LLdh2N3SdQ1E5HDuJeEUYXFh4/oVnCqWly1SmMtj3AAkh9IyUz2azWWSz2VlPPrl04Q9/+MNvbtq0CYztWg2ovpofDiYmO44DXdcBKWFZVqEb7BtvvIVoNLq/pmVWeWWUdfaDjtpzqTYAeH1dRxuANv/tZwF8HwD+dOM35OGzm6AHFaQTrQiGKVQmQJnAiOoadHa2ezuslIAEKM1Pf76QZNhLdCdeFxYKCRCveyoAcKICLI6sSaAGIkikFVx//c/R0gFURJ31+3o+Xt3ekjxx0hiLmxRW2oYa9yUXKQHieRYkzeekuwCRYKJ3ZS8ppVehF15F3EA0ADftgioG0hbB9rYkTEfCMoVeXoFlsA8b+vGPf3zE9GkN849fvPDGI+fNQDgcBCM2TCuBdevWobIy3m/2V1/17UopFovBzOUQDFXDsVy88+67WL9+PRgDEonEfrlnXdcRjUZRVVUFiw8tOjeZTCLgOHC5Ci45wuEoakQUuq5DY5Gt5RVWBvuwoVXb3GUTIqrV2vY0Xl36NiqqNBxz1AwsOHYe6qsYurs7IKQApFczjhSywDz9nlMCVuw5I159epav6CJ0UDWKrg4bFdVN+Nvf/g8Wj6M7kUYgGHtiX9/vMWNH18SirIYyx6vNx/O6oUDxzkUgvIaYvq0Csu9svEi4ApRSmATIdecQ0iqhMopElwVDY5EiaapMZbDvfwqHw1ubm5tnbdm0KVo/ij4zrrHa66YSjPX41CV6c/SdJNu2oWieyL/6rbfw5ptvflPVa5dJCUvX972USwiB67rP5GP8yRBXEwuFANuGsL3jaWEHAIPrAtQom5fKYB9m9HpzVxuAtoVTxjSctPhozJ93DCiNIJeTgNTBhA0hJADXt7oT9PjmCTj1OCOD8KriSI9XQjIoNILuTo6q2iZ8+7vfRrRy0r3/fPmt1fvjPheMb6zJ5NrGu9yGQA6qJiCkVxhHQgCSFJLciFQgiFtkDe4buGZXBpxz5CwHKlWhUgKqMFRXACqjDQsm1euQ+tZn39uQLK+0XafydrkXaGJFpT569OhRixYtwuTJk6FpXmPGodZ1VxRvb161ahVef/11pNNpTI5W7jOWXq9Ga0q4+lIpJYLB4G5FEJaSlBL5mn+RSAS2baOjowOMUbS1JZ9JJBJv7y/bRJmzl2kHGqHHotutRPI33//i0sax9XDcLBLJdiR4FobOQOH52xUJED+irpApRvMl4wQgvEg7CeZz9hBsO4Bs1sKf/vQAmFaDd9a1WZut7D7pbjq3qV6vqiLWwkmNNZadro6FlaY4pQgZDFTJoaNrGzQGryeeL6kQuJ7KQoXPV3qH8gp/r2P++4GIt2GIdAqxiI7W7gRsy8TkphqsFS0AzwFCLDl6bKQNUm/jULYu3bi9rMfvrNpVjnza83TtFZfc+PGPnXvNyJEhCDcBVbUAnkUumwSTXrELJgHK8tZ4r+c7FKdg4GKiJ6wWoIAIgbAIXl2xDt//0S2fTZnaE1tbTWuzld0rLrePnHrWlFENNZfVVIYWqBqtoULCzObGBxQNHZ3bURU3QJgNQxU4/qRjMXnyWHRuf99L95VFYAdA/GYWNF9BW/Rec8wX+A3DK6f/3qYtGD9hGjpSGRAE8PTTS7H2vc3QWBgQOiRUQOrgUJ7lhFmSwOJEsb53400fLq++Mtj3Cc2fOrLmyk+e13rssUfD0ByoqgUr1wYpLIweWYeujhb46x6sj2lnutceuXbUaGx8dz1GjWiAaytwhYruThvvrtuG3/7uH9jSkj3ixQ1dy/bmvSx/4gk5qqESZq4NobABJl3YZhaES1/ecAFigVAbIA4YXAie9VeVnwNApA9y7rfG8sGPfpJ1hON12CGAoAoEVUGJCsZUEBiwsy4gdQgwQOhwqQJOFO/70DFxzofKifFlnX3PUBWLDximdv755781ZcoUqKpayE7TdR2qqmKwSjcA0NHRgdoJE/DsE0+g8bDD/DJXKpqbmxEIBPDQQw9h8+ZtV7muO2zmZGeZxc58T1VVaJoGVVX9PvMEnHNYltWrHn5/o0xlnX2PUQfv7tMKfNai06KLFi1ae8Lxh9XEIhyalgB4FkKkoFAHmuGACBsENiiBb2VnO+y5YxsasWH56zhi/gJsXfU+RjVNxbLnX8f0GUfhVzf/AUtXbEHaCT60si2112vLMWJDpWlwpKESE0Q6UJADoz02Bk9M56CS98T+A6BS9Nm9tX84isKGQAgBoYAKDkgHggoIV0JKCpUZgGQQUCCoDkEVALpvE9AxfUJNdOXatrKlvgz2vUNnH7ckevHFFydmzJgBy1oOy8pC072ac5kcB7gDTWNQCINtD9KzIRCAYRjgnGPUqFFY/uKLmDZtLu655x489NBD17qusjoWqx52c1BaQXZ3uaxt217BSsXrWUco8TrxMM/1KF0CgPT8R3q/lqkM9r1Khx9++ANTpkwF5wJhVQWBCsYJVMKgE9Xjeo6A7VhgQO8IuRItKtucwoiqRiRSLlxLQV3DTLy8ohm/vu3+ha9sFPs0V51JCwwKKEmBSQYGDlATlEuA+O2ZkQ90dwHB0W+8b97snr9f0pujF2aDqt67QkLIHl2fUQ5CXe8UhEFIDZxwCKoBxIEg1LMP0NyU6ROqPIOlVJIr17VY5RVa1tn3GC1btuykxx57bIvjOKiurkZlpdetOZfLQdM0BAIBOI6DVCq1U5wtlUohVlmJTZs2gRCC66+/fpcz6vYE9VcXb1e59q4YgA3DgK7rhb56Qgivrr7jwLbtQpfa/gaApQBa/VGmMtj3LP372UesL3zvK6NfffVVbNvQDdgaiG3ASnMQ1wCDDnAFAT0CxlVA+qNQWa7nEegshEisEe+s3IDK6iZ88vIvw5VxJNLqsn15TwsnjY8y2KDSBoMDhhwobBA4IMQBgw0GGxSuP6QXD09k7yEkyC44e7hQwYUKAg2Usl4NKimXoISDEgFGHTAC728QUCK9DEFwz89POEDc6PSmunKmXBnse54u+/yV5IUXXkBLSws45wVulOdI1TU1gx4jUF2NRGsrxo4di5/97GdIJJKfbW9vP4JzPmwXbXFU4FAt4rlcDrZtF3rUMcYKFvpycY49IK2V/ex7jsZWBMef/5HTr73g/I98qrGhAq7dBU0xEQwCcLOg0gT1RXLuujBtiWzGBmEU4VAVmKjEpve78ae7/oyHHnkOzIg2Ld3atn5/3EvbiqWSsRyCBgfnndAUG7bVDQYLIJ4uTfJWeT+jzWGDqwYDU0nzTOnXoyfU1+UFCFQQ4jXZgC++exKAgjmnftqr8AsA0hj9xtrOLeVVWTbQ7RXa0JVdf+QhtT9JdHcuPf+80+6YP3cqJOdIpToRCTB0d3cjm82iYfRosEAAibZmVMRrEIjHsG71+4CTxt///gieeuopcE4R2I/cLJPJIBwGOOfQdR2S22CMgYEBxNfppW8Jz6evDgL2wSrfMqYMCPZsNgsCAsZIr80jX4q7iI4or8Yy2Pc6vfRO6/pZ4ypTUnK43MGcmYdA0aqRzqagBUeAqA7SORWKbSASHYNsjqMzmYCQMfz9H0/ggYefQkenxMjRNXClsl8KNhzROCp61x9vBdMCyJjdIApFJtkFCavA2T0dsLeVnWKoZayF/3+6o7YpGWybAHAB6vvjwXoBHlIDpAEAW8tcvQz2fULBYBDLli2bJdzETCu7+I7DDpuIyqgBQ9fQ1taGaDSKTNrC+vUb0DR+ErKWiVtuuQXLXnwPnJMzGhrioIqyLp0y98v1W5YFy7IQCFTCygkwpoJSCi7y1nVP9RMFfV3mlcIhifH5YJ0+twxJCll/wt9kpJCl0sJJAFaXV2AZ7PuMXnhrSxuAtiMOqd/a0fUQjl90NM464ySoOUANjMd777dCUQyMnXAsXnjpFdxx5x/w7jsb4FpBNIwa+8Sjb63cb/7hIxpH1BghRbddC1QhcLhE2rTgQoGihwFigAjeqwy2lJ7FXB1qYItf/YIVc/QiTi/8BBpK/G8QT1+X+dPy6LI31pUj6Mpg309676pV2xfaZipqZbt+c+EF5zV0dnb6nV4p/vnPf+Jvf70b697vWsgoEI+EVu9vg6lt26iMVaCjowPZbB00TQMhLiorK2FaKUgQEEELQPdyADy0DQb2wTi72EHp7xvs+c0FkpZr1pfBPjxo5eZkoQrt3HEjnm3rVBOXXXYZtrZkcNttt2PFihVYtq6TNMXDDe92p/e7jllLjCkMVs2K5s5nv/HJi//QlchcGqvQAWGhtq4K27a+74ENPmcXHugk8cR7fRDMDRYc5HLSJ9h7QJ939XmGQyE8ox/3k47KXH0Qwam8K+4bOqQ61NDYONqilMI0TaRSuaRpmuAusLq9a9iFdR7VNKomGjGqFc1t2Lp5k15RGRzlOtlb0aOhI98HIy9Gq3yQxTaIlC92WIoEAL4JUAsAHM4tKWF53N0rn+//zgaAV7bKv5RXWhnsZRoizW8cpUvBTW+9+FlqvksMeRccHZo1nvcdWx9bvrG1zLHLYnyZ9jHF/Nd8RJ9V8jpgvv9gjIVQUk5cKXP2MpWpTEOlcmx8mcpUBnuZylSmMtjLVKYylcFepjKVqQz2MpWpTPuRyq63MhVoTv2IAYtk7G3PDYfjnV/2dsG90dJRdsmVwV6mPSrmeTnh5v4CO/IJLrJXqJ2R/8fUmkr97bbOMvB3d3rLfvYemtVYozuOo1uWVe04To2uKsnq6ur20aPqq6urqxfH4uFZiqJEDE1tUBQlShl0zrklHNdyXTepGcGaIT0MMUjQicJ0KaVV2hySEKJ7SSYDa2WDPWsmXQ1Aw/6a/9IuOX48Xlv+vmzbbhdCWLbrtGWz2fXdXcmlra2tq9va2pBKpdCddnRKCBSVWpoaXK/ruqUw3Vq2eYsFAE2ReHRdqjtZBnuZsOSomfro0aPN6dOnY8qUKRg5og6BQAAQLoQQENLxqqIg38xA9gKp5XDsTbCD0QJgi3u793RFYQMCe9BKMXJonWaGWoOuH7AXNrGuri6vLp3udY2hxOuM6zgOXNcF1Qxs2bwdK1e9gbdWvYtNmzYh0Z028mAvc/YPGNiPmlDfoGqIVMXCDeObRi+eOevQL8+aOR2jR4+GojGYpolMJgXTNAEhoaoqjIC3uBzL8kAmOfIx4h74/SqoRAwNDHkgD6rb7sDZveuQA3P2fCHHnQXbbqoBu69T8t6/F6T33+Fw2Cvm6XK4rutnvglw7j2PlJWDroWgBQwwqiObzaK5uRUbN21Da0tH8v77HzjDtkRSSJpUlUDKK1mtWIQx6/FVb1llsB9EdO6iY2omNTVcP3vO9E/NmHYI6kdWQ9UILDODTCYDRWP+wvEKKirUK2wo4S0qybkP7t6NC/MFWhxuD+0CBwF7vqzy7oJ9cDF+aJx7yJzdJQOCnTEGIQQct6f6rKZpUBQFjDGYwoXgFI7ggPTeY0wDiApIhlQqg7XvbcDLr6zAiuVvYv369Ugk0hDA6DXpzJYy2A9gmlAbqRlZW2Udf9wxdy085oglh82YDI0CQA7CNsGFCaZIaIpXsLAz0dlrAVEJOI4D08zCtm1EwkG/9pkoLOziskxMGdpcStF7sUvSN5gKojzp3cyhtCpUMfh2BoiK3L/lmqngA4rxBU7u59ZSSsEYAyVeUwnbV7MIYYBUIEHAOQF3AcEpJFGgqgFAUiSTGWzauAVvvvk2lq9YcdH69Rut/6ztvLcM9gOQLjz9pJnHn7DwtbmzDkNVZQQMLhw3jaCmQFEcEO5AwoaiAoqveyu6UuhC4rouwD1QqyqDoihwbNMv2uAWurR6QPLBRNwhcdbBwM4Y61WZpRjshJBeCeG9CjHupJg9GNgHrTQjxF4Fe74XHCgpdHnNz5sQAsxQ/Oo5HrhdLgAoIFC8EtRMA2M6pCCwbQ7XEXAciVQ6jVQqiznnfJKUwX6A0HGzaxZMntw0fu7cuXdMmToJVZVxBFQKlVFoDGAKQLgNIVxQ4XUdpVz2VF6hbqnFzFtq0geq5L0WPi2dOzLEVsq0b0+o7GcJluwNoEPVuTkdEtgHswkMuhjV3puFLNkg8+WvBOlbaiH+ZiEI7alrLRXkq9NyTvz3KQhUeE0iVc/WIhXYJIxVb76Hx554/KcvPL/s3paOhB4MRF9f2Z5IlsE+DKg+EBjfnMut/8jJi8Z//OOnrquoiKCmpgbhSAAEAsLOgUgBBg5CBQi3ISUvgF2RpAB2opQuNt4bRJKXgEv2BsAQwS4JG9ZgH9zkMMQLUPgOYO99/L0PdkaC6E4m8Pprq/DIE09ixfK3Ylnb1dd0JdvKYN+XwKaVOqhVE41qbdU1ET1osOpITG1YsODYez505sk1gjRDIwyK6hnWKOFgjEFRKHSmwLa9LqRC8kI31eJF47iZ3pNTopPnXWNkBy7X22C3+2DvG8T9Lf4dHuYQ55cJOiQxfajWeJfZA25myDejIH1LGUwWXZ/MS0n+q/SMr/n3iV/J1gO9R5bvZdE0A4YWQ3t3Ei++sBz/fuA/ly19ee16RVWSghhb3+tOtZXBvg9pwdRx0dNPPTFxwUVnIxaL4r21q1BbL8EEICH8VkGuZ1VXKDTKQIgEcUUB7MV6rZQSfkmzHl28BGbFYO/NVQ4OsFM+WF13uVfB7nil5grPZSCw96Ve9NL5+wC7EGJAsLsUfvdYAEKHZCrMnMT691uw7v1tePqZV/DHx58njcFYdGP2wBPtDziwzxtZVzNtxsSZl1x81uOzZk1Ge+dGZHMZjGqohpVu890t/mqQDqSUYMy32jKPOwknb+Tq3ZaYSFEyOb0XeV5MJkWmo121eA/I2fqB886L8UMzkA3Vzz7U++fgJcdjg2xytGQeRJ+f512SgpcaMGlJW+oUDMOAAEE66cB0JQw9BlWvAIGBd9duxeOPPoNHHv3vwvbWFILRitdfb+lMlsG+l+iPP7xeLjzhSOiqBdPshB5wEQwFoKgcrVvXQlEUqKpvqZUOKKVQVQWqqoJQWQC7EAKE9H7YwnX6BHse8MVg72thD3mxE+xXsFMh9yqYhwL2vPTVF5jzcQc7Sla7BnZCMrBtG6AMkVA19FAUtkXQ3mkilbTR0HgI2ltTeOq/L+Jf9z2C1e+tn0pgbH33AAnBPWDAfsXp55/71a9ec09VXAVVs3CtTmgBGwHNQcbuRi6ZRnW8AlJKuK7XKtmys76F2AWlFFpA6xVxBdoTZkoIgSL7DjfNryG6w+SVAoAOEexil8C9A1jlnnV97fvFqOxodCME0p/X0rVaerWDmBwKNgeKUtek935AN/2usBTcVZDOOeCugkAojnCkDslkFtGqBiS7Unj26WX47zMvYNXK905q62gFgdG2vCX9ehnsQ6Qffe47S8847eT5quqgMqZAC9gQTjcESUIhWUB1EFA0WJms74f2retU+IEXEowxWK5VCMyQUoKwfMtfXxJwZJ86al9g97qX9i1WHqhgZ4P8fjAD3VA5fynYC350nwOXdn/Z02DnTjsCgQAYU2DmJBxBoWtREGbAtRXowSisHMCJCkOLYcu2Vvzrn4/gsSceRVdndtaK1kwZ7HmqJKGGTrnzYYkfmnOEft45p5unLF6AkEGQSDXD0AQ0Q4AyBxwmXJ6BK22v15gkA+rRg96rdIa0mOWQa4GI/bwcDvBaJsQuPOfSoKK+1YCSTUXuuKFAKh4zgALH4SDSAKQKhYXAqI62tk48/9yLePGF5T/9z8tr//JOyh62gN+n+ey7AvSzjjwh+pnPfCZxyMQx6OjogIjqXggrdQF4nFlIz+ouUc7cK9Me3DOKNobiDV5RFEAwcNfrdMsoEIlEMG/ePIxtnPzlNvNftxYfZ4ReoW+3hk+3n2FZvOKSU05f8InLzn1mzqwJCAco0gEN6UQLqqvDINQBiAMuHLjc9iJE82I4+LBeRIM2SSBloO1f4ii4WQvPwoLn1FQhJYWQDrik4JJASg26FkRDYxRjxtbhmuB56y5aNP2kNWvWIBKvW7fd6lr/geXsO0MfO+WM+R+/5JJn5s6ehq62ZmRTOVRXh6GQOBiTkPDioF3uggvuW8n8HbjM4Mu0F4kxBu5y3+jrJd/kQ4QZVTF37lykMnj8j3/8I955b1PTB1pnH4w+f/7Z15171qnXT5g4Fk4uA1UVcK0kQCw0jKlDLtUFIWxw4RnaXN+gxZgXMQee3as6+6Cce4g671CDcso6+9B0diG4n9AkdrChSMFgGAYsy4XjOAVdHtJbe4zq6E7m0DB+Cpa++DJ+89s/f3/Nmi3rbG68bjrK+rda9r97btiA/X/PvvSaT37q7BtrKkMglMNMJ8GYi4AmoWoCAU3CdnKQ0oHwDXIu8YtHUM9aS0SuDPYhnZ8NazVnf4PdW2sqFEWBFAyOw+HY3hpkVAeXCgKhSlDFwNKX38Kdd96NFW+sBVEixopNLftddx8WW/nnP/Lx684/b8mNMw6tgbA3QaedGFlLANEMpiQQr+BIpDeDiw4ImYSECRAORgAKCukSCGc43IkYcHguwf5Hmfa7oO4NyQppsYVEGiJgOyYkbBAiQKgNymxQJQdJsnBEJypGKEh1vYtsYi2OPHwsrvrEOTj5uFmojGDB3DG1NR94sH9myfmfOvPMM6+fNm0atjc3o6qqCoQQZLNZNDQ0QNM0bN+2DcFg0It+E2KHHVlKOeT0yjKVqS9psPjfhmGAEALTNJHNegFbhmEgFAohEAhg+4YNqBk1CgDQ3t6OuUcfjY9+9KNobGx8fKh5Awe8GH/W/NnR737z64ma2iqEdBWO8xYUIkCIhJA2hPBEdkrcXgUeIamXyCApAAXIly+i5k6J8aXv9SS+DDFFdQ8usg/i3j/U+y9OZOpLjB/8AEaJ+J5PjfTWhes6vcuA+epjHshMAtu2bUMoEoemVCCbFaiqHYc3V23E9T+48cNvr97S9l5WPvuBeroNaqgBAK688sqEbduorKxER0dHL069Q3BDmco0jDh+8TrNR2R6eRgqDMNAJBIBpRSpVApjx47FF77whXtmzJjeNrWyUv9Agb2iUmq//vqViUMmV2DMGAXZ7FqEwh1QWAqgGUiS9vRymCC+79xzrVFAUlBJQaUEhQCFDQYHDE55NZZpD8KiaEjF192ZnxpLABBI6dUIFUJCCAnb5QiEwggEAqABAj0gkMs0Q6WdOGr+OJz1oSPfHjvaWHzC1KaaDwzYzz///DtOOumkaDabRVVVFdLpNKqrq/sWrQkZBuJtmfYFFUt0uzP2JWcvPbcQAo7jIBgMerXsMxnouo5AIIBMJoOOjg4sXLgQixcvfqCrq+uDwdkvOnXuzPMvOHWBHkijZgRBe9cq1NRYkNgCyUwImoOgDgQRni5OKEA0b0jVG/7OSsBBwEFhgWL/RyUW63O7M8q0vx+gXTJcf4gid1z/G5QtGKAEYNoWupLtALKIxjiCoSxU1o6aahOnnjwTc+c0XDB3VHj+QQ32sxbOj15yySWvFe+S2WwWhBBkMpleuyeltDDKQCjTcNHZB1qLXnq161ckVsE5RzabhRACgUAA2WwWY8aMwaWXXnpjbW0tplVV6Act2E859bjE/CNmwna7EI0ryOW2IRoV6OpaC6ZaIDSvn0svNplRgGog8Lk6FAAKBJRCeimTLigc0OGgs+c5wO6OMu3n5+f0HuD+6B0v0SONAX4NXAASTNORsx1wAgSDOiTJwrS74PJOcNEOlSUB2YHZs8bi9NOOXvpWx75NktmnYJ8/fz62bt2KKYcdBtd1MWLECABeIwZd13fYQQuRcWXOXqZhzu0JITAMA7ZtI5fLgXMOSilCoRCi0SgURUEkHodpmkilUliyZAm+esnZY/bpte4r99bbzz8qNT0DTc1AU00wmgWVNigvrsfu+TOp7z8nMl8OKl9Tzud+vgSQ938Kwv1wyJB/nFIuKQqclxCyQ/OBvAhGJO/XILNTRhvuDqkmnZSB/FMpeUiicI35qy7tDgP0FL/I32dPIUx/FkSeK9HC/XtNL4hf7KMnjqG4UGMpicJ5eK/5ZWL/5lXloxDz9yFL5qG/SIh8URBSVP2ir+fYU7wjf1zZ63wOl5CCgvg6PAXrUUeJBj1gQAlFsXnDVtSNnIjX31z74LwzvnbGQcXZf/W9HyQcpycgoVdXkz4CXYoNH/3pRjurRw3024He6+v9vq5pIGtwOU5g/3Da4cDlS2NG8htty9atUFUVXV1dmDRp0jG3fO+yK/bV9e31rfgji88Y/+OfXhelJAEhswCxAGpCwoQgFihzACpBBCBdHYDi9zfMczNaaA5AClzG93MSVviut4nkHzQr4ZB+DTM/0SH/dg8DzZeSljsuluKNpeS90u8KaCgt6Jz/+c4sQrFDszbR68Q9l1LEbUnxpjJUvb9HMsgzQUJJgcP3VNmlJfPnF36kQ6yBN+Tqtnn9OV9+qjTtue/2WgWBBqLoWcmeddPvpk16HYgSBjAUODv8mn4SLiRsMEWDdDOIVNUikcqCkHD8hOOO/CSA3x0UnP1DH/rQOk3TChFGxZy9lEPvLGcv/e6e5OxD4caDWWr3hJ94b1S13VOSyP72kw/VlTlU+1Cxrckrac56eZRs20ZFhVcUVVVVrF27Foqi6A/d8dWbDnjOfuV5H7vwC1+8GqlkOxSWhWZwgLjgcAHiQFIBwAEhHJCApAoY9y3TvXTFvK7OClzG2zR6K13CT3Hsqwpsjy4KsJKKjvk2T6KfFM++9OO+FgUv+X3pAh5sIVFi97MH52P/CSQ8+/AO10QIhshY/WmUYMg3qaSe1FSQtMiAHJgMkTXzIab40l3MHBz8dCUTWlg3FKRISsj/m/g2AuKLE9SfD+4fJ5nqQjxWhXQ6B8oURIIhEGDGjOmHhQ94zp5IJJY+9dRT6OrqQkNDw04Dqb9dtr9de29wxr7OtbPvHej6eqkd5UDxiOytAKWdXV/5rMx8rPwO1XB9v3sgEICqqpg0ZQpyudxLd99993X7ZH72xaL86dc/t+T00xZ8NxylsynSkCQNheRAmA0QExIuKJfQuNZrgqmkfpcSv9g/7WnYJwUrWFHzRSOE0l2y0+d1/d7NAgqLGL2t3JzQ3RKP899zBO3XsFe4/oHELGL1uQeXFsWQtO+NJd+eanet8Ry9s8UYyVv//eOW1JUv5YyCDk1QdIeYN6iWSBaDVdamJeeThO6kWkcLTSa8deStSS7TOzy/whqSDJTpMB2KSKQG3SmBtjbr+aeeXHbrNT/5w10HDdgB4H8vWjzly1+5+nEf7A0KyYEqDkBMCOmAuAK60EvASv0uJb74zRhk3j0ilUInEOGDWqqJQcHeiysXVyKREpzsWrRe6Xf7Anvxvw92sEumDmmNOEOse6+xkrnfx2B3eNL/TR82JckQjVWhK2lBCK25uTWz5v/+7+5P/Oqe19btM8lnX4ubv/za5eefesrCz49qqJpHiAPTSkBKDiNIIM0uSId7rZQVBRQuOOcgUkBVVVhZq2exFzXoy98BMbrBGAMREo7tiVKKYoBICtfxDISKokBjGiilhe4wrmt7PlQtOrBOyfmAXF9jdECJoC+VpddmIHqX2QK8gob5xhaqqkBKCYvn4DgOKAVUVYWE6/9t9FjTe+mcpW7OnsVaEDWlAofnQZ4XiTkI5aD+8QxDg23b4I7lp3PqXhFGzuG6LpiI9wsSKWWvwKm+1h1nQ2ssacPuLbmJ3ps3I16x0p55c7x2T8Lr9pvJ2oW6CV5ii1Uwpum67n23GMyS9uooZBguTNOEFAoY08EFBYECpgYghQaiqDCztPVvd//7a1f/6J7b97masz90y+v/Z8ni05ec8OW6uorxuoEmVWXIWd0wE9tREYlB1ZhXl5twBINBcMdGIpFAQAsMCHboXeCcQ1dUKExHOp1Gd3caoUAYdSMaAFUFLAtW1oJl9TxIw9BAVRWWqwyqkw0EZCJ2PiinLzA4uVyv3yqKClVVQVUVYAzNGzcgGo0iENG9xAvb9IDGLbiuC00LDwnsrq8XlYKdgPvWZBOGYSAQ0AFKIR0P5HmphfJYzz2XvgLgzsAhzVIdWg08qZbYfUTvzde1bWQyGWQyKQ+cAQWBQACa4lnOk6lcIbjIs6L3xLsLIcAYGxDsmmZ7mx41ACjIZG1wFwiEYggGKvDamysfvfOOu6+66YH3N+4Xm8beAPs580+puW/Zo20jiUa2SbvfE9x/y/W/OObYIy8y7Uyt7aZQG3NBpYtMJoNUugsqA2KxEBQGZHNJKErvhyfzi9YX08HS0HUdZs5BMpFFOBxDRc1I2GkTGzZsQW3NCCiKDk3ToOk6wDRACHDbhuM4SJi7J7736IxiwO8NFryjSALGWIFj5hea7eTgui4kd6Gont/WsjKQcBEIqggEdKiqilQ6OySwy3wEnB+RSEg+Is17DQaD3vVYAq7rR5TlvSZSgYbYDvdePAeapvU5N/l/5waxpg+mBtnEKShoXkRk7+/nMkkYhgHD0EAoB3dsf6O0vRJTulrYPL3uv9LvNcd9sBeJ+TLfq0ApXD8jHJqmwbUZclmBYKgGoVgdtm7avm7pS6/d/a8HHv7en55Zl+vv+meNrI7Onz//nFv/+dAfDgiwf+1j19562IzJn3pp6fPX/uqeO3462Pd/8aWPnXf2uR/6VqzCODTT+R4YPG4eDGkQroVMJgECjlBYh2lmBwQ7UTKwLAuaGkAwEEUuZ6OrM4VgIILqUY3o3NYC1/UAJKUEJUrB7y+EgBxEjB/Mkq+xgV1zg821sByfo/RcF+ccXHhqhkIJKBMA4aBUQDcUaDqFEJ74SPIGst0Eu5dshKIwWD/81w9Lzmaz0DQNhh6Gohi+vu9zN6iwUnSHyMji13xGWH+bgTWIL2ywOoOiwNn7bnRfXRnz68hJpDPdSCW6wYUNRfH84gWDra8+Ai4URYGier5yzt1iA0Xe0lIkueQ8HzsJgtEgmBJFd1du46OPP/2Ly7/3918NhoX/Oe/Ma0488cQbn3r6mWt/9dd7fjrswf7vW34t58+fh/Xvr8FLLz7zkS/84vd3D/abjx03L3DFlZfcPmX8yIXCzdQTQqAbgMI4hMyBEgeKxmGaGYC4hZLL0hc3BfE4i041uK6E4wKCE3CXQHAVXDJA6utyppVo2d6xbv36DS9veH/zitb2tnXZbDbB/VXEQrHdkiOJX4NZSu84pJ+azHKAErKEEKYoHutTKNEikUhV3YiaSWPGjJkxevTIQ6srImM5t+xIUJ+tGwCICwkTiurp2BIOhJvbPbD7oKC+oUmS3huTAIUXGqbCygG2JSGFBtvBio62zOYNGzau2N7cvmbDhg0rSgDOi/7tEq/MSynYC3NlUZnamXnuV4xX8obZ/DVQSCk5kYJ59kWHN45tmDFtysSTxo9vnFtbV3mMbiiwLAuZbAIKzUBRPEOwt6ECTJFeTUQhIAs1CumOoJcKYDEQaSAUqYRtqnhp2eu/e+iBp3/8q4eWDWqE+8bll0w++dRj35kzZw7+89Qz+PWvflP7xJtr2oYt2D9x2oeWfP0rn3tgzJjRaG3bBkh73SuvvPLPBx944IbfP/ZSx2C/v/+XX/pF07iRc2tqao5xeQaQFsIRFYZOYLspCOEMCHaNeC16urrTSKdyiEYqwWhwywsvvfLnhx/6z89+/9+tHTiA6eavnH35pKaxR0+a3Hh5LB6CkDlIuNAUBlUjsM3UkMDOfCyKou9LKQtgl1BApNHRsr1z3QvPv/rHxx7/7+/ufiVhH4hzeep0lTVNaGyYN3/OefPnzz+vaULjvM7290GI1wGYCxuMEagagZQcjuOA5QWnfN94X5zPS0YK1xEN16A7mWt96sllv/vXvx/73l0vNg84Px9dcCS74IILfzFlypSF8UptRnV1Nd5dsw4/+fEvTvrDI/99YtiC/ZdfvWrzZZd8tCEQ0LGteRNq66qgSIKXl75699NPvfS7b95+/6AXf+1ZJ8w440OnfmPK1PELVdWpFU4aAjkQaoMprqdP+jqk7JXFpkAVcbRuT0BKCU2NYNVb7976wL8fv+HmJ9/diIOELjxuPFuw8IjL586edt6ohtrFmiGRy+WQS3egNl8LYTfBrrDiBCUGISWkZOBCAaTe2taR3vD8s6/98ZPfv/tmHET0qTOn148fM2reSacedk00Gjo+HA6DUO65hAkHoRJSuoUIwR7fOfVzNzikYEi1EqS6yRPLV7x+/xU/unfQOfr8xadOueDC834xc+aMUzZv3oxYJArb9jwDf/zD31ff9Zd/LHy9uattWIL93lt+KOcfPh0VFTHYThaWnYXBVETDcWTTPPebW+64+Mu/ufO+nTnWH7/1yS+dcMKRV0WCrClndYMyB5ouBwS7JisAoWPdunXPP/bo07984cWXn/rnW3Y3DkK67KT6+MJFR1125NGzz6+vr5+nEBturmPIYO/h6L3A3iqFhurDP1u35FA18OAqJ3cwzukt3zz28ilTJh0/bdq042PxUL1lZ2FZGYAIUCrB/U4k/YB9y5vLNjzywL+e+fGvH14/uNj+iY8ceeHHPvrzUQ11RyaTCQSDQRiajtbWDjQ2NuKxR57G967/Ue3S95uHJ9g3Pf+sJMwGU2ww1YUkGXCRBYgLSikCRqT76f++9Pt77374W3968r1BF8zvvvPZq08+8dhrujqbJ42oDYKIDGob4mht3oB4RQRaNICWTZsQDIcRqa4GtsaxetXGl2//y11X/vSR19/AB4D+8qOrv3HOWWd8t7X9fabHuhAIqOhOdCKoKQiHg7CzOR/MzA/+UHpCiZgE4EL6m2dIC4NzAsvmUFkYhAbR1pLEQ48+/YnP/PDe2/EBoc2v3bM2HCVNkGmEIkAyuR1MkeCug8rKSnS2ppBJuYhG6lARr8f2ba24/59PfvpT3//LrYMd+8qzjq5dctrir86YPumUaEyfQqUJx81BOhZqKoJwslkwLYJtLSl88Uvf+emate3PGuHKdS9t6lg91PvaY7HxV114waVe/3TaY0X2g0HyG0oikYgvXLjwS1/60pce+c6VZy4c7JhXfOfGm7/97W/PHzNmTMf27duficfjSHR0oHb0aEgpkWhtRV1jIwKBALpbWvD2W2+9dNddd33ugwJ0ALjwazf/4A9/+MOno9FoN6UU6XQa0WgUmqYhm83CMAzout5vtl9fVVK7u7uhqioSicTGf/7znxe8+OKLfx7oGhr3d5O4PUzXXXfd4evXr38mH0OQj2evrqvD6tWrEYvFUFdXB9M0Nz737LN3f/e73x390ksvDRryesu3P3v5ueee+/3DDjvs8/F4fEpxF1hKKeB7K1zXRTgcRlNT05cVBQ/sqW5He4yz3/7Ln8gzFs2HKxLghbz1DCQxQYjwOLseQibtQlMikELb8tILr/3trKt//OWdOf5dP7r6G0cdM+d8jbmH6kEFkaAGRghaW1th2zbGjhuH//nE18be9J91g+rnHz12QaRuRFVDRXWkNhQy4mpQiTHGdJm1siXW312aAzHEp9LendgYj8frjaAe7+7u3vbee++9cOfDy1I789uHb/3CTQsXHXZ1KtGCyupKCDuHTLYbFZEgXO4Fk2hq0LvOQhq28P/2LltVghDc89fHo6Pw1DNLf7Xkqls/uzPnv/Kko2vHNk2aTQhRCJUghDA/C4xRIpnnt+9d9ob2SswHBCUDzp8cpCGe7OdxCb+00ZtvvvlIKBiL3/qv/zQPdj+fu+DISd/4xmefVjRen8t1IB6Po2XbVoybPh1b33kfmhpp/s8Tz996/pd+/72dmZ9Hbv/JbyYfMv6YaMg4NKBJSMeCZSUA1wKTnjs1HPWCe9JZwAjV4J//ehK/vvlOZG1l6vLtqdXDBuwvPfqAnDgiBod3wxUZgFggLAtQC/AjsFxbgNEgiDT818CWTRtbVj388CM//fbv/vXUYOf45ClNVV/+wtUPGyF1XiSoIZtOw7ZtjB49Gg8++ODPzv7C3/rdOM488mjtlMUnXVNfXz9l3Ngxh1bXxOcxTYJzG44fZomcjaGAnQ4x2ypeXYPW1lZ0J7sQCoUQi8W2dHYkNy9btuxvy5e/fv/Ndz/c70Z2wdE17Ac//NLrdTWRQx3ueIU4GQdcC4pKYds2KNH6BDv3XUoEGrirIBKN4+1VG5/63e13XX7z/Rv7PecVJx9be+KJJ149d87sc8LhcJXpiPp8uKkXL+C/Ei84JZnsHlCsJOrAEYyDrdUBwA4AfgxG8I2WlpZ1y5a9evfnf/zrvw10vD///LKvLjr+yE+6brIpHA4jZOjYsGHDy/UjGif9+Ib/d/KP7nzz5cGe6bc+/ZGFH/3oeT+qq6puymS7a1UqwWCBcAeEWFDAQYUXSxGKUOihEDraMgjH6rFy1QZ86zs/Q3NbZuprrZnhA/b3Xn5ORvV2uKLT68/GHBCWhSQmID3xRAogFKyCZQLJbgvRUAXi0Tps27Zl1ZtvvPvEmVf/6gsXHjeN/eW/b/W7g19+6pz4wkXHfPLERcdflU2mmsJGABRkS92x54zu7zfXXHb27EWLFl1xyITxV4UNFYEAgxA2MtlumFYanHoW0Aqq7gDyoSTG7Cq1bGtHVVUV4pWV4JyjI9mNbMaGbkQQDsW3/Pmuf3zhiz/7Q79xC7d88aOXX/mJi/4vkWyHkDlUVQXQ2dWMiniwEOtdDJp8Lbk8w2R6NcychBGI4He/veuCz/3yiX7B8Ncff/dbh0xpWtjYOOr4ysoYurta0Z3qKsSWezH+fuKN/8r6CZohhTwbMsT5HTiBqLZ2BDrau0EUBoUZqZUrVz7xwAMP/+CGPz+2or8jvnL/LY/UjoidEg6Hkc1m17z//vsrFnzk6xfkPx9FCNvaj8Rx60/+9/OLT1h4la5ikqEQWGYGmnBBhAsDAqrCoFEJuByOkwOCDFosivbtXaBKHB2dFn5ww6/x5tsbZ63Ynnl9WID9inM+fO5Xv/75ewK0GQLdnkGuBOyetVcFd1VA6mAkCOlScEeBolAEjHjqnXVbX5i75OpTBzpXDSFam5T2L7940flLTjn1y4QLdtutv/34T/71Qp96+reu+fjiU04/7asjR448nnDH20mpC8YkmCJAmYBgvskqkR4SgHsKEu4ehQMxLxzV9QyaVFdBoMJ2ANsSUNRg8z/+ft91V//gpn6NZesfvWllTW38UNtJIRQiSKXbC2Dn3OkFdo7eBSMjtU2wUg5Wrnrn0Zt+dfsFf/hvW5+ejNu+8dWrPvLRc35kWqk44ALCwcZN6zBmnLff5sGej8AjfhjxYGDnLvYq2AOBELIZC0RhCAaiXk24lvbVDz/88M8+88Pf9TmnX/nY8bM/9elL72xvb9/w+uuvP3Tlt/64gxFuDCFsUxHgLz37mPrLLv/YbaNHj5zu2tnGilgQTLqAdEFtE9w2oXIHjBKoRIBJQAgbJKRACRhIpWykMgS2o+H2O+/BI0+8OOuVrckhg32PVKqZcsjE/ydFDpJmAZrzkieYAyALKXMAccAYQ6K7FaPqx4NRhpbtLZCcorpyFLiwsHXL25GJ4xuPcN5/RH7tm9+e/rM/v7yqr3O1SWkDwOd/ftffvnnpxVsmjZt0TH9A//wnz513yccv/P4hkxrntbVshWunQYgNRZFQmIBCAEgX3PISSaKKsUtiYymxISZydDZv9WK3QwYYY7BzDnKOgMspXKmhumJs/ZIli7504zc+aX32B7/v0yB0/79f/8FFHzvrF3ogUt+dakMwPAKJXAqarnmVbqQsqmnX2yUH1wAlYbzwwso/9wf0X1zzxUvOPue0qw1DjWcyScTiBkJhA7Ujm9Cd6PLdon5qbSFXwEdxAQ99z2uYDa1ngiB925u9szGozERlXIfDc+juaoaq6hjbOHLKccdO+dTXLzx81Q//8uoOYvmP//TUitu+f+3NK1eufOLXf3+kT5daMdB//JWPn/fxCz9yTm1FcEkkIABNQKEpxKNBdLW1Q0gLgANOJKQQkAJg8OLsdabCMjMIBiMwbRegDI2No0CpiM6sr4q+3tyR3O+c/R+33CxnHz4ZQbUZYEkvyo3aECIJgRwo41AUBXV1I9HVmoLrEETC1RAuQWd7BpQB1ZWjsK25AwoNIRiNdzz82NO/vPjz/+8HO3B2RrQ2LncqauvOm67/7rELjvyWpnCEgxq4lQGVJsBNuDwDCQeKCuhBzUu/TNr9gr24DfDu6pSDkQoDjuPAEV4lXkVVIZkGl1OYDoWVA+JVI7HqnbUP/uNv//7az/58f58b4uoH71zWOK5mXnv7BowZV4PW1o2oqIzCzKV2uNbiV8cNgyLc+tWvXzf9d49uai0+5liisgvOv+CYs84661ujGqqP13QJxrKwnRTSmU5MnDQGnV0dvcCeT6jZWbAHpDEkyWkwsIfjcXRs74ARDCAYiKC1td1Tk3QVQpB1DcdcPmEoz2/FE/c8HYvrtYxgihEgALFBRA66QZHLJKASDgUcKiFQCfVEGYeDCK+6jhLRkMykEK0ZjWSnDdtV8eLSlfjRT29BzlZjQwX7HuHsEyeMhQoBVzhgxPVCDuGCUK9aFwMBuMD2zVtAiQpGA8jlukC4Cl0TcByJlpZ1iMciyOVa4Dpm1SknH37NM/ddP+NfDzx+wy/veK6gU+0s0K+78qIjP/2/n7zcdlIIBSmIk4I0OwFYAEzo0l+UtgvH5nAAMB7o1XYqDwLOeaFg5kDkOM4QORPzxVUPFA4HOAEkVBAZgqIaSKdbUV8bW3LmWafnAHykr+NsaXPeqRwVnJd2Qkg7AYSrm0B0BsigXwEIgJRFxSf8IhUsiJVvrH++FOgAsEE6fPl9D3w/GNKOAbEgiQ1XpECUDGKVQEdinRevX1QZGOD+oX0DoOytNvQSwIUCyx7SWoails5nQf4HoCDd1Q5dY3DdBBKJNqi6RFSlkNKEFCz42QtOn3TjXx9a09/xq3WitVs7rr/r/ufi4y++4MKf1oeVKiJyjYRKUMvrKkOoDZ6xoBELEjaEBCwJuPn9UFHAfKcEBYHCgO62ZrgiAC4NjB03GpadAReBKID9D/Z8Fc2d4Ws9PniACi+KK//7fG35XC4H6rLayZMnn/fxyvqGn37r4lu//L0//3FXrmn06NEzCCENmqbBcXJQqfB9mtwrDCiFZ5giHJJ4sQBqUV+5PBcp5nyDcW5FGeJ08oGPTymFgFd4IRwOV/X3vUQisS2RSKxwXTeVTCbHujxjUSaZrtEgABDhu8BEoRInCCFIJ62OVCrV2t9xo9ForaIChDj+5kcAPzvPy+OWJZy75FXKfjm7N7dDM3DmPZ+FZ0iKz+bXppPEi/2XtHA6z65A65uamuYC6BfsfQH9Nz/66jUXXHDBxwHMLr0fQnq/DnZ7xTEp+euilCIQCMDNDr2u3pDBfua8WdGf/uxHUIkLR1JIUK+6pqR+zq8Cki+GQCUEl5DchRQCQkpQokKhKiilsKxuT5yWJlKZbhCaQWND9ZFLTpkXvP+Oz877x333f/uuBzbsVDLL5IlNxxCRQygskU12wTA4VJIBgwUGG1T6NcYl8h3gofgLF6XFAqVn6iGDiJGuGFrwA6P5+uO2v1glKAEEXBBQaEyBKxlANVRVhneo4HnilCPYk6uX8g9/7otfA/C1XT1/FYDGY/rxO5/z4RnXfuXzuoQJkBQEyYIpORCa8SIlOYdSWM3+POXrQpE83PqfP0l71bnYLZKFOu0y7wstcslZ/t7GIAkBiAJQ4ie1eAkth82ZeA6AnaoHd84JM9nln7j4tjPOOPpU007X6wzQzazHTCAB4YIQG5AcnFhejD161geneV4uC14RTXqeEUpVSC5AqARjBPGKGNK5hDZUrA45gi4Wi81U1cFrj/Uut7RjJU7AK27glZJSCn2tm5ubEQqFZpxwwglX//a3v23/9AVzJ+3MdY0cOXKKZVlQVbWQR52v5e0ViPCqwGiaVhj5yqT5clX5CMCd3jkVZUhjZySoPIcPBoPx/z3/5Kbiz59cvXTPhFr1QZqmBSmljaW2iV2p6Lqv+6v3d+wdDJM+TZgwYd7OHPd7137mnG9+85vPNTU1XQ6gPhqNorOzcwePwe7eV/455zFTVVW1R+ZnyGCviIXmazRvjGH+Ib1BZf5fpKC7K5SCEb9Bq99fXQgTnOd8Q4kLSjiqYwGMqY+gNipBnRZkOtdC4W244bufXfbcfd/+x6DGLoMGLDcFIk1ImoPCLBBmQiEOVCJBqQRRGAjTwJgGhYUA+KJ9yWvpv/sbpd0+d3UIMAgwcELBiYSg+f7gDkBzoIrl6YHSBiOojcdC9aX3fdLUI/ZK6OrIhlijKxKQtBtUyYKwDCRJQSAJKRMgJAUpHUjpeIY4yT3OLoVXqFJwv4+PVwDUG8wbQvVKSMmBB/Hj+/sfuj+0wqBEByUqCBRfysxz855CFQIcgnBURPXa/u7/tPlHsiVHHcEevOO2//v4+ef9JKLLIyuDEproQrpjHcaMUCCVFISSgGApCJb2o0gtr8uw9Fxs3qDeEBRMCjApwYrArCjUd18CTCGorq6EEFw/fGz9kNwVQxbj4/H4fFVVIWD26QvttfP7Fm3G/CYP6KnnxTmHaXKfw3o16IjKEAwGQWwHqWQWyc2bEQ5WxZuamua9+cRvn37yv8tu/cIPb/9b3vfeS6R2XZtQAsdxoCgKGGOw8tJEoYS0V+BfEoCAFgxxpZb3neVcQ41hZmTwvTefe+ByF4FAIDyUuIBdoW3btq32qvt43Aa9bBui17n7qOdTorPvHeq5d/86aEk1nMIL6bvg5QAPcPz48fMuvOijLwZ1BfF4HIyo2PD+WwgHJepG1CHV3QK1VHogpdcld4Gzi1LO/jYAY7+CPRKJzFJVFQ6nAC/lVn2LVV6svAIogBQERHhaVi5nQVV1KIQilUvB7DIRCAQQiUQQr43B4hxGKIDt2xONFRXRxprqyKPFvvdiMnnOikRUmNwEUwFBOSR1IKVXn1xK6Zu6BThRPF2rOIWR9H5IciceFFOGJiiJQsFLp1e/dkkAKl0QuFAZYLsOHDeHgKbGS4/x2Fsv7RVRfvIhYxcyxQaYCdCcN4gFSh2AClAh+20xn68FJ0s68/QIlhRMDC5nDvYEiF+KvNAoKB+5mY/Qy6f6+s8XvQx4CoRp99svffrkaYunTZgCK9uF9i2bEAsTTBk/Gp3tG9C+8V2MbqxFa7I9fyFgAnCJ8LoPEeLZM7jfTSdf2tx3FBRWGfWkDMo83T2vs8dikSF329kjYDcMYxRjDFxSgPe/4xJCwIUAihrn+FbQvB0FqhRIpVIwVA2RSATBYBCmacK2bRjBKLo7OhCWGhzHwajR9aioqGgYyLIZCATh2t3QFAbA65eddzvlF5+UEsI3JJFCXfXd6/IyVM4+GE8u7pcnhICiKBr2EW3dunVVXhrzquxKUEZBFQWgCqiQEPaucd7i1+JFP9D978znspTBFG3ZPa64ojXoXwPn3B7Au3Mo517cQCQSAXcTaGvrQjQcQk1NFFxk+l73vhegpynUwNdfbCPyODtBIBDYIxLbkMC+cHKT/pFzl8ByslAUBwpMjyMRCSn9ErvQelxtVAEk8xITiFfoCBCF7qUqFVCphKoQ5LJZ6FoAClVBJEV3exsiAR2M2KiIauju2AYm3H7105AI6CE7DCubg6q6gG1CgQpI09ctJSQ8q2z+IFzxFoQA77Mg4mCrcchGFJJPSMnbPZQeY7akUFUV3YkENL0KUjjY3tb6Xn+HeuiPN/5G1e2IJCbCEVbLGGPJVHcHE+CQGmdCB+EBxrjOID2OqOpK4Lbbbrv0/556YQePh+OaNpdpKEiBUBMMWRDXBnUALg1A9sqULxQCLZQNG5BTC0gC2CW94Hfokkv6b+/tie1mv4zGm0evWYOnP+Z9B8xbh5Iha2/vN8PQdlIdwt0GyE5I2QWoSYBaSNgSna6X1anlNxvhqYGEE4BSUEkgiefyk5SA+V4fRwgAEgr1VFsIioAagLBtgFsgJAdd15FMbkc0osO0nSiAtv0Cdn8y9R0nXu7w90DVVg+ANmLDgortCcWejVK65LTj4p/93FWTwlFyPKiFYMhb8OlM1BOXpQYf7GBcRx7sqUxyIFsBKzyznfAZ7zn9e9/O75689j11D3vqOMqQL6IoBTlvlMgD3BObeoIKZEFx63F95Esm9zfp/blJdvU6PU4zvBdoj8BZavegBTVBSglQAuo1NuhTjDdULRCPRo+PVqqQxIRueJVRuZv2itNIeBneUnhdc6UNQAFhYQjRtzKmqqpGpCdlEAg/9JUDAlAK/nS6S2Dqzw4y0Dz2V857bzc7Ufo3OyI/LxIlHW7Jzm0kkvixALK0fBjZoxuHsicXeYGrF8BdFD2Uh3gJpy+WBMge3mV39xilvtJdbfC4+9c7iAFPCI+p+pw9z237um/OORwHkMQBoV74sicZoBA0VPwKSBhGAEL0HRmkaVqwtx7sb+h7kMkP1jaL9LvmsE8286GsoQOes+8MyPLhgrsDxD3B1XeFs/c3qUNpB71rBrp8jqe7o25LSlgBBKgE6/s6GHNdG67NQJgJqlMQ5kBRud8VV4IKjzuzvFFR6HA4QBWlz2MywTQG7z9ICSY9Ix2DC+bHvHMSGCJCRD9z2jvMtvi9YmYy2PPt2dhQErord8ktSIvkr/zftIir59cB3c2NUGLv7FvKntrBSv3SUu46AHo9jINAB9zT5OnpPbXi+uPCxZFbXgNGFUwlsCxWaIFNCQMkKyRhgDDkLDcfc99desx0Ot1R2DQPAJVoT59zdxhOqXqxu3e0p1SUoensFHppL2rZhxW0r81gILm1v+KIBz/1jiXPz60gBBAaKNMh800MOAcXbp+uIoUS6JoCQ1e8gCFhQzgZaNTqOTxVQKUFsJx3HqFDZA1U10YaAeyQt93W2rGOgnk+c8lAKfGjwsSAMe8Hks5e3LFmx0cjOSkRBqjPm4Q/pwXOXrre8x1qBtnACnXpqQSI8CL74HU1lkNsZ73HdfZSwPfN/fvoXU12lML2lAi/L0nugwixnt50/cddB4PBeDgcRiBAYLsmODfhOhZsqwjs4F7/esl9sAOEBBCLxfoMGe3u7m4mhLQSQmr7fIYHuQS2r1S5vbmuhhTy5RmBHDCFoLgMV3+BKf2VLi5OiMmHg6qq11Ez3820kEZbZJAZKAiCc27lj5kP0c3/XWrt3Nlw2L0upkN4QxIfiN6gQoEEg2Vz6IEQLItDCrZ67fr1L/V1nFH1NVNSiU64ZgZtzVugKhKOnfHLg5mQJAtJkuAkA07T4DQJTpMIxwSEzPWpGvz5+ZV2Jm13SKHA0KOIx2qgqSGoqo5AJAbLcnolGhW7BvPPuXS+dxwSA+UOeFG6vb9TnJfQXyDUziakECEHUqEYhPDzPQiIBJgkUEChEAoiZOF97xIlIHpqBuzU+uqDUXpBXxJcikKB0P0C9gNND97T/s99TcFgEOl02ivxlUi0/vU/fRfmHDdu3DxN09De3o5oNArO+aCFNwAgmUxi9uzZZ/b3eUdHxxZN0yCEKGQSZjIZwHURr6gYkBsdCHM+0IYw2PUfCPe3B5pEuAeUuD2QpLHfr00WqevwWlJLaH7svgJIBY4tQTUDmzZu7bcRxuTJjUcbOpBKdiAeC0LYOWgUoMQEhQsKDgoOENvLqCMOQE1wkcbUQ0cff8GCsX1a5Neu2/ISYCCbE0ilHIAFkbMJbJsCWnQHKW3X53XgrMC+sgt7c/q9/2yI7LG8k3ydA3/QnRyDrc/83ezpNfmB4uwHOiUSCS8um3O89dZbfdbZ/8Qpx1ZVVVWNJoQgFApB0zSYplnIkR6IwuEwVFWt709vf+211x5KpVIbbdtGOp32iiTqOjjncDOZ/bZW9pQaxgaYJM453x/q3p5kRnRPXtTOPpT+xr4W1Xa3PvzeFbSKc7i9XAIiVEiporM7h1hFNbZtbX3m9ddff7CvIxx59MzzXWk2CJ5D/cgquFYajpPx6wfkM628nuMkrwNTb4RDBLbdjomTR/dZr+ZHf3n05Q0bW5YzLQJJIjBtBXqgCpyEkDJFvwu0WH3a389/ELD3m1hU7OYU3k324vZkDzDhvBW+cB7il9YqSC/7mbPvi1DFPQ30viqtHCjXb9s2Xnnllfv++szaPvX1mTNnLrEsC5xzhMNhZDKZnY4CzM/FnDlz+tXbX3vttYcopVsCgUDBfkApha7rBaPc3prPva1uDWTw7StasT/GMRyklL3A2YW+B4WDfSYS7csJ3n1SQCSFIBSSeK/BcAjr12x4/rnnXrijr1986oxj6kfUxibqCiDBkU0nYDk2GPMj7vxB0LdvnDAbisYxdlz97GsvOnZGX+e4+qd/vr21tXsDiIZE0oSQCmxoCISi+4xT92X82xPnM02z36w3wzAizE/PZrL3tTAQX4ffPQ6/g8WBCJ/D5ysYARwSIFLfj2A/sKgvg9xwEiMHo2Aw2L1u3bpX/vDomlTfhrnJxzDGmgzDAKUUnZ2d+bz3nTp+3t2pquqUiRMnHtPf9zZv3vyGZVnrTNNLKXVdF0RVd5jLA82mY1lWbgCwh3dFZR2ONrChgd3lOhEODCYhXBtUaKDSy9+lEN5OJxQQoXvDDYG4YVAnCOoEAa4DghV8kpSpkKoKqVEQxkFUC4yaYNQEJTmkUx3QCUXrlm2I6AFMn3LI4v4u7fH/PndzW1cWVfWNyDkKsg6DJFFYjgoJHSAGHJeAMgOGHobgFEWu7d0bkpQMuUuDqi6CEQVaSIMej4BrIWRFCNQYA1OMwMuvddx35tW//kJ/93zSgsOvkVYKjKSg0Awoy0JRTCgqh2maEESDIBqAIIAgmNTAwKBIBgUSppMB1RyE4wzzj55+XunxxxCDAcBpn/rx/yx7advdM2eeAtOKwLIVQAZgGHUgNAwhDbhcQ87icAQHUwCmoMfy7w+v0q8FBgcMDihLeoOm/ZHtGcT/ruTedwUHFdKrkMMFCBeQMgApAwAMgKhedVnmVyiiDtq7mqEFKKjiyTfxilqEQjUAQojHmvDi8tX9tqZuGlM3hzEHRHHAFRcuFXAp4FKAEwpBWdHf3ij1J3ApwUtCmSmlYISASOmVNCeeL18VgMYBjStQXQomGAiU5H4D+752XXHOoeg6RowYgc7OTnDO+dcuPq3PiqCrV69+ilK6yrZttLW1QdM02LYNx3Hgum5Pc0PfZzwc7A66riOTycC2baxevRpdXV3QdR1r1qx50HXd1bfffvuV/f32zh9d86Xq6uqxhmEUKuP2jrgb3MBjmiZc14XlR9rdc9NXv1/8+SZpFuwETz/99O/Xrl27wnVdT3KIRpFMJr1NxZcm8nq8bXsto3d1Pe3p9TV27FhkMhlkMhkwxpDL5bw1pShob29v/u9///v7vn731bM/PFvTtEBxteFSKWZ3rm9fR4nuXTE+r3uQwQqM9dZa+tOrA0EDrpVDKGzANNMIGuzQWTOnnt7XEW+579EtmzZte4O7BKFwBVyXAUSFpgdhhCPQQwFQlcB0U8i5neAk51X7HMLwpJrioXhDaCVD73NkLYGO7gxa2rpx2KyjQUgI2SwwadLMY8bN/cjUvz25qk+j3MdOODxw2imnf6GqLtygBh24IgMhc15zTWpDwhvEr+ZL4PY5cpkEDI3CsdOIRPSFRx896+L+ntivH3xu3W9uuf3iNWu3311XNxkt77YgZxM4QoUjNNicwoUCQXRQGoQRCEOC9mq2KIjwhwtBXBAeAHHDIDxYMsIgIgDCQ56EyEMgwuiRGPODWCAkA0IzIMT0/gYv2Cg01at6FDSCIJKgraUT2ZQFO8fx7up3nr/zsXV9qkfTZ009NRpVarnIQsgcCDFBCfc8HMSTSiUXu8wk9zXghxVn7w/keYrH4+jo6EAymUQkEkEoFMK4ceP6rfX92GOP/WrLli0rxowZg2w226t+fN5ynN+tNU3b75zdMAxks1k0TZiA5i1bwBhbI4RYfd11183s7zcXHzdPO/3007+sKEq9qqqFJJleVXx38tlIKREKhSClRDQaRUtLy7rH7/jJbf19/xf3vbB66dKlf2tpadmi63qh9r5lWcjr8/nKvjvj59/bnD2TTiMQ8Fp8ZbPZQt+A999//9HHH3/8V/39buLEiUdofjzBnuTs+5r2MGcvxP7seGji7oSf1UuNJZJ4mV6SghMKSb2uGYQBlptGKtuNYBAw3QQaGqJTfn3tRy7p62p+dOd9Lz/x2Is3d3S4rSBRcBmG5QTQnRToTtuwuQKi6oCiQjD4NdqHMix/2D0DolBbzpNw8lk/StHQAKlh05Y0psw6Ae+s7URl5SQkUqx17Lwrpt509/KN/c34YVMmn3rCscd+V/IcMlY7LN4FyTJgugWq2pDUKVyfFz3n+vxVFuqVM8nBJEc8EgRcGyp1AJ4Ekcnj581tOu/6q07v1zby5ZseuO/73711UWensSpjhuCKSkhSA6LUQVXrIFGBrKkik1MhZBjC16sl1MLw8rEUQKqFufBGfn78uIMdYtBk70Fsf47zOeq00JkIQodjKWAkjGyagJEoRo2eAivH8MJzr915/V9WPN/X/d3wqcuXTJw88kjb6YIkaTBYoLBAwf2a7z1jZ+MI+vr3vjBm7hE/+76wZufjsIPBIHRdh+u6SCQSqKioaDz55JM/29/vrv7xTbc/9thjvzJNE+FwGMFgsOCvzud6c86RzWb3+847YsQIrHrzTdTU1LQ++OCDN/zyl788AwDqCOmTLX7rsouOWbx48TU1dXWF+XEcZ4fGlHk/+2Aj75cnhCCZTGL69Olobm6OX3jhhT/93LknTBpIpL/ttts+vnbt2ruSyeTL+YSlVCqF7u5uAEBtbe1+n998zEEoFEI4HEZna2vHI4888uXnn3/+/v5+c/rpp3+lYuTIqkwmM2B+wc7GMfTlLtxXXgtl3053PhKI9ivG9SUWyUL6O4eqKlANBsfKgZAMhEiifmRw4g+uPPmUb9z22KN9HfeRh577hZklqcOmN51aUxc9JWCEwagJAgrhOuCODRAOThNDMyBSseNeKv0plgwA83qMFf72OTwRgFTw3ttd94+sP3TK9df/8oz/97eX15x7jfeVluKUQp++cPaSKVdeddHPm8bWzoPsACVdsEUKVPF0SUBCCsfz+xLmN+MgoIIV1W3PX6Xf8MF2wYgNhQgo1AVVsjD0LMaOGzvjtFPnfOmyEydde8eTa7r75IB/f3IFgIu/d8W5xx911FEXTT5kwjHVldFJyVQXOjtbkUqZiMfqfI+x63UQgu2f35s3l9h9V3ggYqdA4ZKQP6fF9+ffr9QhKIfFK+G6BOvXbr3/2WdfvOPam+65/5Lv9X28G/7nsiVf+vynjoHVBqpkQGCCyhwksTxBwl+YjCgAIeA7ybSK13iZs/dDgUAAtm0XeqOFw2F0dXUhl8tFTjnllH5dUn96Zlnu8u/89FePPPLIL1avXn1rNptdXazLGoaBysrK/cVwWvPj2WefvWPMERdM/n9/e3nNQD/4+HEnVJ133nk/mjx58rxEIgHbNKHreq/00rwFflcMQKlUCuFwuFAbffXKlRg3Zw7a29uxcOHCK6655pp7P3HijKqBjvGt39371ImXffETN9100wXPP//87aZprq6qqkJdXd0ur6c9vb5GjRoF13Wb161bd/9DDz30s2tvuuf+gb5/1llnfVPRNDQ3NyMYDO6QtttXYcidBfq+FuEBgAzFsLBwwuiGD59z8uZPXH4xMrlWSJICaMarOEssr4tl8c4iNC/Wu1CIxQHg9zLL78JAr1bC3s7pd+fMd+UUDFJokFIFpA4JBRDB1lffWHvfKZf/4NODXff/Ljmhad78OedNmzbl+Orq6kZFpboQwg1GE02Duf5KH1LxA3Tze7skOwpPkoFzvsUyeSoSidTmsk73yy+//M8VK1bcf/3tTz6/s3P+pXOXHPrhDy/5/vQZ489UmInO7s3g3EuQsfLnJw7gW92l7LF/56vM5Du00F5dVl0QWsSbpAJBvAo2EgyQBiprx+D5/7509933PHzdjf9avmZnrveiY+dqR82fd/HUaZOPr6utHK8bSjBk6FWaTgOUoEoIG0J612mrwp/Lvi3b+Q4vPeAQvYCXtTlUVYWu61AUBVLQVsvkqVzOStgWzy5/deV9y5a9evdv7n12y2DX/befX/etY44+/JKA7jS5IolISMK2kqDSBCV2Ud07L9KREAKXloBY9i290j7WEAAoqpcxSImGRLcJPRiDaQfx57/9G3+99wlwEo4tf79tt33tCg4eqp05c+aS33/nM6s++Z1bbh7oi79+8D/rANzgD8/Q9JETZ6TN9zp29aSySMQu9DjoB+yapgV/fc+qQsmns+d9GGfvwrm+edEFxyxatOi8hoaGM03TBHc9tSPf/XZv13Jv3rwZM2bMOC8SHVH77Y+f9u3v3vnwM4P95q7nXrEB3O6PAl22cEI8FAzEdJ1FVI1plFKl00puLgYxKbFVCOnyIpAwL+3Vm38pJbjXuJH5G7Nt5pzUXx7bXIiKm348cOlO3OdN133hkiPmHnYkgCbXdcFUBiHsfqWjgari9hnauwt6/vDV2XvF9O64QxcKShYYd96Kynt0CslQWqJP+PXIC3U8iACI7X0qqW/xpkh1tDV88tIzbvrnL64ee/YXbv7yrlz6T//x5BvDeSf74rnHHPo/n7nqN5GodijQCTOXhK47CAYJuDDhOCkw6heQINR/DoqnF0pvXkneRtCj5eZlFt8a3nvxUSkAkvOXiYOKiggS3VtQN8JYeOWV5/zfX3/8qT9e8JXffm937ueOZ9Z2o4/ClvubbvvOp6465ZTjrqquDM3I5NrhuBkwcK8GHLUAAXB/V8/XnJNkYNG9OGJOSon9FUR8UMXGjxw5EmvefRdHHHHEeS//7ecPXHb8zPiBfk/XnHls0/3/75u/+NKXvvRgY2Pjofn8dEII8jHwQoidqkQzVMrbSwBA1/WmRYsWXf7cn37yj2987IQjD4b1889bf/jTo48++pK6uroZqh/rP5ifv6+uxX1Z3vtS+/Y17WMxXvhliGn/n4P2sVPSXjp8r9KUxPV1UBtmuhmTDhuPTEeycezYaOOPb/ji2zd/6bzrrv7Z3bcfaAvvihMm1y750Ilf/e53Pn1JRTxclc2l0Nq2BYwBRoCDKRJccuQyOUg4CAaDcCzew7El/KqksjDfpQU/JSEeV8/bRKTfdLggafm956RnJadEIGCoELkccrlOhGPVjUcePbaxccKZMx77/eeeue8fD337t4+/13ygzfXPr73yvJNOOumaBQunTqKwanO5zeB2CoCNUECAMu7VkxPSrySrFFZroS0kISADeA2GR43Dg4gCgQC6tmxBKB5HLBbD9u3b688777zvv/3o71+85qwjmg6IhfeZj5731gO3vfjzn/987cKFCz8vhKhKp9NQVRV5X2++DpzjOAVOkY9Y25uk63rhnPF4HKqqIpvNoqamZtLJp59+xS9/+csNz//xh//41scWHHMgzPV1V5x35H/+csudH/7wh79bXV19DOe8lnMOy7KQyWT8TsAB5PMNBhLVd9K+s19LoO1ZazxNeNZ4cD9irnfGIBUaAAYi/D0mb40vrmcuFa+PdlFHz0I97XwVDykhBfWjrJjXqFAC0bCGzZs3IxKtRTxejdaOJKhqoKKqFpm01b15+5ZVK5a/ef8LL7xw12//PTw40CWLxgTGjBkzc9KkSUefsGDRVYQQRdF4YzDEEI4YgM7hprrR1dUFKSUMw/A6gDoOVNVzszmuCc45NFXvxZl9A5ZX7UQqKC2LLgveEP/7POrbRrwMaupH/xHfam9ZFmrq6wGion17O1wAtTUjwaVA87ZWVFXUwtDDYExBR3uiddVba5568YWX7/rab59+cLgA/NLFsyOnnLr484ceesjiquqK0cGQ3uhVHrbR0bkBkSADoRymmQFlLmLhACgFnKwJzvPrsqcnjNd2vFgyLeoIg94xIwXdvR+Rf29b4w8qsEOYiNXVQeQkLIsjEKtGLmejpa0TuhaCElCRSVvIZrMvObawTdNNtbV2rt+6pWV1Z2fnloCuhnfBCg8pJS96kJyR0gB70es1GNLjtbW1TYpCtUgkUjVufOPsYDAYN02z3jAMSNsFYwyKxkGoDcFNEGYhHNTBwmF0NzcXFoZXYpsjl8uBMolIJAIzZ+1VsEerqpBNJCAkQzAYRc5x0NGeAGEUVZW1UKiOdMpEJpMFpAIjEIWuhVKuYLZtidzmLc2r0imzo7Oza3N3V7o5Y1odruva+Tl0mW33JXgWW+CllFyKHfVkQggLKvG44zhZx3FsKSXXdTUcjUZr4xWRkcFgMHbooVOPF9LmIHwSpQKESjDFk1gMQ0F7x/sIByhUjYBzG7aTBpUuFIVCpwpyOatfsHv6fe9W30RiB7Af0K43KSW4pL5v3K/8Sbhf9RNFVksF+fpqsrAVMh/kfi0O4npWdqn4bTSUkmqwTtETVnpaZ8IBlwoICaOrvSeV0uzYCgCIhQAgCelIRHUgquPI/PknNtYAc2v8RR7s5yZpr4dW+pC8V4aexCfRAzrioqdxpVuyCaQApBAOAkACCOZ6PpUAqNfIMZnJAZlugPo9VIgohCKoAc8bkbXSEHmdu2D0YCVeD7v3+UXvLrECvdNQecE84n3e3tFV+L2Z8ryUwbDXdy2bawFDBQgFwhG1cH9cpiKEALoBNDWRBiAAb/QxzSK8a9pmie1nxz7wvb1BQm4u2Hzy/nwiCJwc4OSAkNINuASOWwwOBcIBchAQoD5HKkof9haAbyKRoH0lc+XvwreZeJ1wizuj5DvBMFBJQahXU4gTCk4EBJOglMAVvFypZn/TB6M11cFDA3VY3R29elef/0Fijc9X0abAXgjy6DVJhPs+Y9IzyGDRyYM9FGeQPbF3tVRZZOH24r396ytUCOUFj0FfnKbwtyztCzpYDzzZD+8QA97vjr8vCfgY4gOTxB3sCQ44v4Qmh8TZ6SCcHX4E3o499XwxXJT83c987xDbTgSkL0cVe5J2ph7dvgT+wRRBt085QpkOrudXGuzSW2Xbs8+/tNrvQZr11genJXuokwdxd+JYcvc+J7RfTiXRR1fawpYu+uG4JZyJFMe0D8TRZJ8cbfDrH+Q6Cmcb2rOQxB7kPvvj2P7909wgIBmkBVOh/XR/EpTsex7870vXKAGf7P1YS0Hpc/T+JKL85ZZyeEm8DrYUB3K4bFlnP6jv40CXbAaq2pPn7Ltzj7tSCaivrfkA4+x+ZZp8NREpAeqWcCYxZA6/gw4luccufDcdIfbQOHtB56cDLnYpyMAqaX/3Img/HBe9dfsddPi8C4r2ZhUlHF72m1FdGtkl+tahh7hpEer2w7lF7+cnSzh64WrcwUSHQcDM+zFpiF4ieek6kqIU6AN3DZI7lbneN4cvBrwodCuXwz+fvaz7lelAf36707l1d59/qb99X0uEQ+LsnHO4rrcbK4oCp3jDk2wHxtETm12k2xLp78gEsg9d1JsQUaI699oqi69oSJxdQuzwQItfCxyd9BhtevHPfH64LN1L6c5dH5G9dcgCJywJKvr/7F1NcBzHdf66e2ZnscDuYgEQNEiKFCnKEUkVSz7JP3LkUmKllErl4qqkrIuV+KJKVSqXHOObbz7pplPsm5RUlJTLdH4UKbRSNktFKyHlQE7CgiiYBAkRi58F9gc7M/3jw+wsZmZ3thdoLIcStlGoXWBn56e7v/e99/r1e0ixgVMznMqhiJsaCrHehDopmlLyObonyGnujx1Mne7D9CTC9N1ekv1j23sYXaX0b+T+onkEukkuOssFVMXn1l5ac9XdGReG50YTiGYK9ljqqEfAbj2sezhoBpHe40nslexTFD1qdfR095L++ZD/1z6qOqTxTzvucHakDcJF4BvoTUv1mbDZ4ypJx24n/etld/ezxzpd9el8OsDjnLRl5dDeZv3DhGmHVH+blsi+tvIeOFl/KyncdQYMtNlln8EP1nGTvoo0P4jEZ7kp6Jh7sNU5NGwUG2zzJwU3kQMZPQ3YIhEL32Xwjo1OEjXjFNJTiB2G0D8UZj/0vPFdoRCf5KOWgYPWPod5vt5j4mp472RRPbN10BrsOFLv4ftj4sLfTAsapKmF1wk+JyOptnQozC5lEMC/Z4JR7M/3J/fsJ2V13pAeNRg6bzOY4UAPF6nVw9yIYDrKGiphs6skU8RtdAzILx47QUqkIDmouzWM/desiOiX5thQ/ZTav5Rrrk90A7iv5+11mfTR5PqeU+5LaET1xNiY0sD5Q/AZWXqLSp+HybyR7usjFB7m9ZNoH41mMZQP4cCPT/YHlqH7Z9gbG/b65IDXH+48RCM89s5PDjamfT4jUbCrRxjsUW+ilBJ7FX5kwu6Oejmjki1Q1eODRPQgjtpQkcw3xs6OhC23x2Q0ZbiSsdk03qUh1Xa9r4kILhI/T3Q1IMw0E/4RV+9lX5sfPZrNkP0Rev+1WNOBjR2IUbtznWniJLQRdGbCAtxJ6df9+URSq7+kgD2MwlT8EbbZD9uOJIQMBDshSQZIHKeGH4T+z2LG7JQkHYsJsPfY6PENNrJfgQylhhb5Ws0DZljI2megFeYZuzRIqibQea/Sg3VC0Ic2ex9f2IuZgn1to5b7rxu38NK9Oo7PzYGyKhQAm1lgNgcXDoRsIV+wMFkuQLrtvUmjGJRyAGUFiSgAcN4YbNlryg5bsmT0fdMQo2C/8zBHhgxox/9LieH1TWPbMwaLmsj0+oyyFA1pWDTxgZIoLSmo6vxwZmOq/AU06nWsN9p46uwT+OiX/4s33noHlJVu/vcnG9XMwL6wsHBveXn5sTfffPPud1/5NmanbLjebpAyyWGYzE9it+1je7uG9Y1Pkc/ZESnHArVPWZ33BIz5ZsxCciNlJl0lUmPme9SZc9TXB3mkn990fPXfJ9haW4MnJSqVCpaWlnD9+nWUy2XkJ+ayVeP/89Zt9/LcbPXf3n0PFy89hW/+wZfgekHtMuJakEpCyilYFoFtl+Hz3Y6pTgBYIJ36ZwQMSgE2tY06SygNGDV6HtOMhe8NZk6hi+0e0nbObrZbRxrsnjLtf7PVoPX1FiYLMzh2fAG5wjR+/JO38Ytrv0Sj4WH57tI5ANkxOxDkat/YrJavXLly7vwXp2/kJwimigUo5WNrs4bddgM5ByiVJjFR6KhpUgGwOuGne4UGpfSMwK6kMJOshja/MTNmzKxHfRU/a81mZmYGgltYXFzEr28t48o/v4vl5RVUZh+76Ev7trmZdIiq46XZ3DNfunzxxosv/j6++rVnMXeshN12A63dGgABZu3VwFKSdQC6tyav5I4RWC1mNpimu4Ik8Y25LdPGs2V2mfHjS8s3Ewaa2H69mp/HneU1/Ms7b+P9azdQXa9BEucicwq3P7q76T5SYH/2zMwF7jaPUQqnVJ4slcr5ucmpvFMq51+bmppAbXuzC3bScU6RMBElAEqaRtenhmqwDuyDcocDgKI8U7CbjiUR9pEGu9As/ZmCXff9jz66A3cX2G7h+ckJ5jx+9vyOJ6zbV64tVg/j+ciol1O+fv7xkuu2t6Xy4Hntjs0exqB3XsOqotQ3nOzNkU42bYklIgx7i2YKdiiGo9wkM4sg1PWfDuwWm4SSDL4U5V/d3+qquQv50rHV9o4x4Eeqt50vTJ6Sypsrl0vl2bnp0s5OLRf4ocJ1xE62CUXdIDDHO2nkHmHMqOoLIRioKumW7giBY9hlbpaTnVLqHmmwm28k2jH5su/71Zxt11lCJqy2d6pzrHhsXdSNAE/GmyvGbdw+H61EJs7tqN3bY7CP27gd8TZOSzVu4zYG+7iN27h9nprWQfe1S6dLrVbDqTdqF+bnZqsAQCAdQkjEqx60lue6QQaOwNET3akVPY4iDGKXgUOLBK9E5gY6OHThqlIMdnDpvKFMGTrYFBt4fb3JZNXNvm8o+a2Mw1UVclleX3IxWrBZ1uDx7OAgckexvyV6UlHH5pvFqCOEABfSVYrVhVKulMS9fnd1J9Vm/+Pf+/qxEydOfPvkwvy3KqXCs4wRRyof7VYThBDQzlZN1gkPDM/R5p164X22MkYLIdLultdE8gbNOq9u6Utp1s506+TMFEuapRedsNLJ3lGD3Rde1mAf7fl1S190tEuP0dWcvmNJBqcZIyyZOjze2rst3Lt3D0sf38ba2iY8zmHb+fIH9x70gv0H3//r7YWF+dKZM2cwW56Cgg/lu2CWQt5msOwAECFwaaIkLS3QBJuHUXKh5PS7DxHWyIqCnmhyjOmWviiZMALbhGEAnI4XdcIG0skUbCLj2HimZKZg58QwKEoj7KNk1S8pper5fjy3ouxuhQ7BHsfLbLGC1ftruPmrD3HtF9fxwc0PUV3bvJhzJtev3blfjYG9urKohPCC9NDchYIPpgQok6BKwOe7XbAHzE5ie26boplg8jjY99YPw9TQKgZ+Hdj1zG62623UYNdGYGnAPmpml9T+XINdu5GKiocC9mjuxvj8sAeCPaxcmQb29ftrOHf2STiVaXy8+P/4u7f+Ee++8zNsbtXnb1S3qtaXL59znv/GV//21b945WVGWiDCg4QAgwSlAkRySL8NKT0Q8JiqJSJWOAAUlZ+pmpa6a0zp/JC0v1407Pl7+gP7vI8wKYcwkybG/cczBTsftck+8v7TCFM1+HgtPBIJjpKXsyotOMfz+M3S+6gsHMdLL12GElu4dv1/LnzjwhOuRQjBCy+88LIQApQp0DAnltp/1ljtrrCRG32GOdCOeMxB9pVuxpV2TJpt27i9tATHKqLZbKJcLuO5557Dz9//8L1Wyy1bZ86cfebJJ5+CIg0Q5YJAghIJqjik9KCEDwIOCg5AdDgwWdFDdIaqPzNRNdwQH0Iy6s4LGejo6F1xDNUkmnI8NP/XyBpdRZhkNdeMGs14k6sk3hixBm1mZhLNhguHUghQTE1PIseKmD9Wwb3Vj0vWpUuXXm80GihXrCDhHdmzb6SUIFKCEtXJeX0wZhg2DeA4mu9oMzsZM7tRa7VamJs7jpVP7mN2ugzbymOn1sTly5fxyZ0NWIxZDiW5TraYNghRnRJsHpTyQOADSnY85rxbdbIf0yXrTafZ6DS1JJfprq006yeF6ZM2tNZmVRpmTKlhlmT0NM3DVNYZOkVIxknoqHE+gKPdqCQQbgvCb4N7LVDFQMEhBQcEL1q3bt36Xrlc/gfP34KFSHE7GS9yqNR+SioPxoYaFdj3LRzUkGr40WhZa1YKY83OTI2fxYNP1zE7O4t20wWjBRSLRSwuLqJer8P60d//5K2f/fSfcOr0DAgFlJBQSoEpBUJoEDijJKiiAAmsOpIK/P0W6htSCuzD6hz8dxqzdvhVJoJ80q1LzePTfd7nYaHFbOmKZJ0Dbxy9bdS8XQ+KM1h5C4xQeG0fWxtVbFbXMVkoOBYAXL169d9f+fM/+WbogZdSgigJysheLveD1DobsoLu4TGLgtENjJl9zOyf4dZsNnHq1ClUP63CcSpYvb+B965+gFarBc5pEEH3p3/0h888cf7U33zn5a98a8LOgVoUREgo5cOxbExO5VGwHdTr2wnmS9jsggzETjQYp59TSFGzhI7p4bJhQks5EOWu3wRjDJZlwbKsbiE+qfhePbuuFiAhhOj8rzdIoluTO3LPjFk9n0dfPZeDUtr9Da8TvTYhBJTS2H1algXGGFq7dS2Y+wV0dO9RZZu7gktlNP6mcRwSpj4PQ2G3T7JJCmeXA45TwNyJx7GzuoUf/fANvP2v72GrKeAL67FYBN0br/+lOn3iJOa/MI8JOwfGFPJ2DgocfquNiQlnINiZpAPB3g2rTekUoskYqQuX1YGdc95TeTb4DY7arK31gMm2bVh2AD7OeSe/PQOltHsspaT7+SCw9+x7SE5eRXsqd3brgRGCqakpKKXAOQfnHL7vw/d9cB4Io8pMaajJkcbgjGYbVANqNv6mYEvGnj/qYE+Oa26iiJWVVdy/8yk+vPl/uPof13B/ZQPKLj7vC+t2F+ynZ4vHzpwszJ0/e+7Xv3PhKZxeOInKTBmlicnAac0FlOB9wd69yQTYkqDuTmDVf8L5YvBkS+4aSpd0/QeN+xKe56HVamFnZ6f722q14HkeFNw9M4YQWDZDLpeD4ziwLAtPP/10RwjQGKuGzMq51xdMYdiw4zjwfR+tVguNRgP1ehONRgO7u7vwPA8PHqxCCAHf97tx9Iwx2LYNxhjK5TIcx0GxWMT09DSmp6dRKpVQKBRg2zZqtU0jsAvezhTrhA6OoNPtbaCGHlafmwk7UytwP7Kin5azvLKKj5eWcfeTZaw92MZ2rQkpbFA7P//zOyvx2Pgn58nv5hh1S9Nld6ZYdrjwnGZtp8SVcKfyEyUleLglNQfghwmwvyp5XA+kiS2j3dh2qZzIBHyt8/avqDV4iyjnfJjJ/HoH7H/WewD1oltuo78AIOTunJTyNSkDJyWIiqnVnIdqNmLMHjK9UiKF2YPnrtV2EC1XFwqBrnnDArMhMA86WhANNAlCCCzL6rK+lBKccwihIESgNVQqE/sCe7IWPFS2S1/KcNefKdiNVz4fItj7AV6x3KubG/W68uFOlyvI2YWd7Vp7peXy9ZubtepvBwDU3lOl/jG8WAAAAABJRU5ErkJggg=='
    );
}

function elder2() {
    processImage(
        'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4gPGc+ICA8dGl0bGU+YmFja2dyb3VuZDwvdGl0bGU+ICA8cmVjdCBmaWxsPSJub25lIiBpZD0iY2FudmFzX2JhY2tncm91bmQiIGhlaWdodD0iMjAyIiB3aWR0aD0iNDAyIiB5PSItMSIgeD0iLTEiLz4gPC9nPiA8Zz4gIDx0aXRsZT5MYXllciAxPC90aXRsZT4gIDxnIHN0cm9rZT0iIzAwMCIgZmlsbD0ibm9uZSIgaWQ9ImdsYXNzIj4gICA8cGF0aCBpZD0ic3ZnXzEiIGQ9Im0xMzUuNjI1LDE0bDQ2LjUsMGwwLDMzbC00Ni41LDBsMCwtMzN6IiBzdHJva2Utd2lkdGg9IjEwIi8+ICAgPHBhdGggaWQ9InN2Z18yIiBkPSJtMjI1LjYyNSwxNGw0Ni41LDBsMCwzM2wtNDYuNSwwbDAsLTMzeiIgc3Ryb2tlLXdpZHRoPSIxMCIvPiAgIDxwYXRoIGlkPSJzdmdfMyIgZD0ibTE4NC4zNzUsMzEuMDE0bDM3LDAiIHN0cm9rZS13aWR0aD0iOSIvPiAgPC9nPiAgPGcgaWQ9Ii4uIj4gICA8cGF0aCBpZD0ic3ZnXzQiIGQ9Im0xODYuNzIsODkuNjk1cS0zLjk2LDAgLTYuNDgsLTIuNTJxLTIuNTIsLTIuNyAtMi41MiwtNi40OHEwLC0zLjc4IDIuNTIsLTYuM3EyLjUyLC0yLjcgNi40OCwtMi43cTMuNzgsMCA2LjMsMi43cTIuNTIsMi41MiAyLjUyLDYuM3QtMi41Miw2LjQ4cS0yLjUyLDIuNTIgLTYuMywyLjUyeiIvPiAgIDxwYXRoIGlkPSJzdmdfNSIgZD0ibTIyMS4yOCw4OS42OTVxLTMuNzgsMCAtNi4zLC0yLjUycS0yLjUyLC0yLjcgLTIuNTIsLTYuNDhxMCwtMy43OCAyLjUyLC02LjNxMi41MiwtMi43IDYuMywtMi43cTMuOTYsMCA2LjQ4LDIuN3EyLjUyLDIuNTIgMi41Miw2LjN0LTIuNTIsNi40OHEtMi41MiwyLjUyIC02LjQ4LDIuNTJ6Ii8+ICA8L2c+ICA8ZyBmaWxsLW9wYWNpdHk9IjAuMiIgaWQ9Im5haXZlIj4gICA8cGF0aCBpZD0ic3ZnXzYiIGQ9Im03Ljc4LDEwNy44NzVsMTIuMjQsMGwxLjI2LDEyLjZsMC41NCwwcTYuMywtNi4zIDEzLjE0LC0xMC40NHE3LjAyLC00LjMyIDE2LjIsLTQuMzJxMTMuODYsMCAyMC4xNiw4LjY0cTYuNDgsOC42NCA2LjQ4LDI1LjU2bDAsNTUuNDRsLTE0Ljc2LDBsMCwtNTMuNDZxMCwtMTIuNDIgLTMuOTYsLTE3LjgycS0zLjk2LC01LjU4IC0xMi42LC01LjU4cS02Ljg0LDAgLTEyLjA2LDMuNDJxLTUuMjIsMy40MiAtMTEuODgsMTAuMDhsMCw2My4zNmwtMTQuNzYsMGwwLC04Ny40OHoiLz4gICA8cGF0aCBpZD0ic3ZnXzciIGQ9Im0xMjYuMzgsMTk3LjUxNXEtMTAuOTgsMCAtMTguMzYsLTYuNDhxLTcuMiwtNi40OCAtNy4yLC0xOC4zNnEwLC0xNC40IDEyLjc4LC0yMS45NnExMi43OCwtNy43NCA0MC44NiwtMTAuOHEwLC00LjE0IC0wLjksLTguMXEtMC43MiwtMy45NiAtMi43LC03LjAycS0xLjk4LC0zLjA2IC01LjU4LC00Ljg2cS0zLjQyLC0xLjk4IC04LjgyLC0xLjk4cS03LjU2LDAgLTE0LjIyLDIuODhxLTYuNjYsMi44OCAtMTEuODgsNi40OGwtNS43NiwtMTAuMjZxNi4xMiwtMy45NiAxNC45NCwtNy41NnE4LjgyLC0zLjc4IDE5LjQ0LC0zLjc4cTE2LjAyLDAgMjMuMjIsOS45cTcuMiw5LjcyIDcuMiwyNi4xbDAsNTMuNjRsLTEyLjI0LDBsLTEuMjYsLTEwLjQ0bC0wLjU0LDBxLTYuMyw1LjIyIC0xMy41LDlxLTcuMiwzLjYgLTE1LjQ4LDMuNnptNC4zMiwtMTEuODhxNi4zLDAgMTEuODgsLTIuODhxNS41OCwtMy4wNiAxMS44OCwtOC44MmwwLC0yNC4zcS0xMC45OCwxLjQ0IC0xOC41NCwzLjQycS03LjM4LDEuOTggLTEyLjA2LDQuNjhxLTQuNSwyLjcgLTYuNjYsNi4zcS0xLjk4LDMuNDIgLTEuOTgsNy41NnEwLDcuNTYgNC41LDEwLjhxNC41LDMuMjQgMTAuOTgsMy4yNHoiLz4gICA8cGF0aCBpZD0ic3ZnXzgiIGQ9Im0xOTYuOTIyLDEwNy44NzVsMTQuNzYsMGwwLDg3LjQ4bC0xNC43NiwwbDAsLTg3LjQ4eiIvPiAgIDxwYXRoIGlkPSJzdmdfOSIgZD0ibTIyOC42MiwxMDcuODc1bDE1LjMsMGwxNi41Niw0OS42OGwzLjk2LDEyLjk2cTIuMTYsNi40OCA0LjE0LDEyLjc4bDAuNzIsMHExLjk4LC02LjMgMy45NiwtMTIuNzhsMy45NiwtMTIuOTZsMTYuNTYsLTQ5LjY4bDE0LjU4LDBsLTMwLjk2LDg3LjQ4bC0xNy4yOCwwbC0zMS41LC04Ny40OHoiLz4gICA8cGF0aCBpZD0ic3ZnXzEwIiBkPSJtMzYwLDE5Ny41MTVxLTguODIsMCAtMTYuNTYsLTMuMDZxLTcuNTYsLTMuMjQgLTEzLjMyLC05cS01LjU4LC01Ljk0IC04LjgyLC0xNC40dC0zLjI0LC0xOS4yNnEwLC0xMC44IDMuMjQsLTE5LjI2cTMuNDIsLTguNjQgOC44MiwtMTQuNThxNS41OCwtNS45NCAxMi42LC05cTcuMDIsLTMuMjQgMTQuNTgsLTMuMjRxOC4yOCwwIDE0Ljc2LDIuODhxNi42NiwyLjg4IDEwLjk4LDguMjhxNC41LDUuNCA2Ljg0LDEyLjk2cTIuMzQsNy41NiAyLjM0LDE2LjkycTAsMi4zNCAtMC4xOCw0LjY4cTAsMi4xNiAtMC4zNiwzLjc4bC01OS4wNCwwcTAuOSwxNC4wNCA4LjY0LDIyLjMycTcuOTIsOC4xIDIwLjUyLDguMXE2LjMsMCAxMS41MiwtMS44cTUuNCwtMS45OCAxMC4yNiwtNS4wNGw1LjIyLDkuNzJxLTUuNzYsMy42IC0xMi43OCw2LjNxLTcuMDIsMi43IC0xNi4wMiwyLjd6bTE5LjI2LC01Mi45MnEwLC0xMy4zMiAtNS43NiwtMjAuMTZxLTUuNTgsLTcuMDIgLTE1Ljg0LC03LjAycS00LjY4LDAgLTksMS44cS00LjE0LDEuOCAtNy41Niw1LjRxLTMuNDIsMy40MiAtNS43Niw4LjQ2cS0yLjE2LDUuMDQgLTIuODgsMTEuNTJsNDYuOCwweiIvPiAgPC9nPiA8L2c+PC9zdmc+'
    );
}