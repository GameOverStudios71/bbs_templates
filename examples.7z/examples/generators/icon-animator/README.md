# Icon Animator

A Pen created on CodePen.

Original URL: [https://codepen.io/umarcbs/pen/yLJNNdR](https://codepen.io/umarcbs/pen/yLJNNdR).

This pen will animate both text as well as icon. You can also upload images, but choose images with transparent background that works properly.